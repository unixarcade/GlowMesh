#!/usr/bin/env python3
"""Black-box tests. No Tor network connection, external service, or third-party Python packages."""
import http.client
import os
from pathlib import Path
import shlex
import signal
import socket
import subprocess
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
BINARY = Path(os.environ.get("GLOWMESH_BIN", ROOT / "target/debug/glowmesh")).resolve()
HOSTNAME = "pg6mmjiyjmcrsslvykfwnntlaru7p5svn6y2ymmju6nubxndf4pscryd.onion"


def unix_sockets_available():
    # Some execution sandboxes prohibit AF_UNIX binding. Report that precise
    # limitation instead of calling an unexercised socket path a passing test.
    with tempfile.TemporaryDirectory(prefix="gm-probe-") as d:
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.bind(str(Path(d) / "probe.sock"))
            return True
        except PermissionError:
            return False


HAS_UNIX_SOCKETS = unix_sockets_available()


def port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_until(predicate, timeout=5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if predicate():
                return
        except (OSError, http.client.HTTPException):
            pass
        time.sleep(0.03)
    raise AssertionError("Condition did not become true before timeout")


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="gm-")
        self.site = Path(self.tmp.name)
        self.port = port()
        self.procs = []
        self.logs = []
        self.run_cli("init", str(self.site))
        config = self.site / "glowmesh.toml"
        config.write_text(config.read_text().replace("127.0.0.1:8080", f"127.0.0.1:{self.port}").replace("header_timeout_secs = 10", "header_timeout_secs = 1"))

    def tearDown(self):
        for p in self.procs:
            if p.poll() is None:
                p.send_signal(signal.SIGTERM)
                try:
                    p.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    p.kill()
                    p.wait()
        for log in self.logs:
            log.close()
        self.tmp.cleanup()

    def run_cli(self, *args, ok=True):
        result = subprocess.run([str(BINARY), *args], cwd=self.site, capture_output=True, text=True, timeout=15)
        if ok:
            self.assertEqual(result.returncode, 0, result.stderr)
        return result

    def start(self, *args):
        log = tempfile.TemporaryFile(mode="w+")
        self.logs.append(log)
        p = subprocess.Popen([str(BINARY), "serve", *args], cwd=self.site, stdout=log, stderr=log, text=True)
        self.procs.append(p)
        return p

    def request(self, path="/", method="GET", headers=None):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        c.request(method, path, headers=headers or {})
        r = c.getresponse()
        out = r.status, dict(r.getheaders()), r.read()
        c.close()
        return out

    def start_local(self):
        p = self.start()
        wait_until(lambda: self.request()[0] == 200)
        return p

    def raw(self, data):
        with socket.create_connection(("127.0.0.1", self.port), timeout=3) as s:
            s.sendall(data)
            out = b""
            while True:
                part = s.recv(65536)
                if not part:
                    return out
                out += part

    def test_local_site_headers_and_head(self):
        self.start_local()
        status, headers, body = self.request()
        self.assertEqual(status, 200)
        self.assertIn(b"A little light", body)
        self.assertEqual(headers["x-content-type-options"], "nosniff")
        self.assertEqual(headers["referrer-policy"], "no-referrer")
        self.assertNotIn("server", headers)
        self.assertNotIn("set-cookie", headers)
        status, head_headers, head_body = self.request(method="HEAD")
        self.assertEqual(int(head_headers["content-length"]), len(body))
        self.assertEqual(head_body, b"")

    def test_traversal_hidden_files_and_no_directory_listing(self):
        (self.site / "public/.env").write_text("PRIVATE")
        (self.site / "public/empty").mkdir()
        self.start_local()
        for path in ["/../glowmesh.toml", "/%2e%2e/glowmesh.toml", "/%252e%252e/", "/.env", "/%2eenv", "/a%2fb", "/empty/"]:
            self.assertEqual(self.request(path)[0], 404, path)

    def test_host_spoofing_duplicate_host_and_proxy_request(self):
        self.start_local()
        self.assertEqual(self.request(headers={"Host": "evil.test"})[0], 421)
        data = self.raw(f"GET / HTTP/1.1\r\nHost: 127.0.0.1:{self.port}\r\nHost: evil.test\r\n\r\n".encode())
        self.assertIn(b" 400 ", data.split(b"\r\n", 1)[0])
        self.assertIn(b" 400 ", self.raw(f"GET http://example.com/ HTTP/1.1\r\nHost: 127.0.0.1:{self.port}\r\n\r\n".encode()).split(b"\r\n", 1)[0])

    def test_methods_bodies_and_request_smuggling(self):
        self.start_local()
        self.assertEqual(self.request(method="POST")[0], 405)
        for extra in ["Content-Length: 4\r\n", "Transfer-Encoding: chunked\r\n", "Content-Length: 2\r\nContent-Length: 9\r\n"]:
            data = self.raw(f"GET / HTTP/1.1\r\nHost: 127.0.0.1:{self.port}\r\n{extra}\r\n".encode())
            self.assertTrue(b" 400 " in data[:80] or b" 413 " in data[:80], data[:80])

    def test_range_conditional_and_directory_redirect(self):
        (self.site / "public/movie.txt").write_text("0123456789")
        (self.site / "public/a").mkdir()
        (self.site / "public/a/index.html").write_text("nested")
        self.start_local()
        status, headers, body = self.request("/movie.txt", headers={"Range": "bytes=2-5"})
        self.assertEqual((status, body), (206, b"2345"))
        self.assertEqual(headers["content-range"], "bytes 2-5/10")
        self.assertEqual(self.request("/movie.txt", headers={"Range": "bytes=999-"})[0], 416)
        self.assertEqual(self.request("/movie.txt", headers={"If-None-Match": headers["etag"]})[0], 304)
        status, headers, _ = self.request("/a?x=1")
        self.assertEqual((status, headers["location"]), (308, "/a/?x=1"))
        self.assertEqual(self.request("/a/")[2], b"nested")

    def test_atomic_reload_and_rejected_reload_keeps_old_site(self):
        p = self.start_local()
        (self.site / "public/index.html").write_text("NEW SNAPSHOT")
        self.assertNotEqual(self.request()[2], b"NEW SNAPSHOT")
        p.send_signal(signal.SIGHUP)
        wait_until(lambda: self.request()[2] == b"NEW SNAPSHOT")
        (self.site / "public/leak.txt").symlink_to("/etc/passwd")
        (self.site / "public/index.html").write_text("REJECTED")
        p.send_signal(signal.SIGHUP)
        time.sleep(0.15)
        self.assertEqual(self.request()[2], b"NEW SNAPSHOT")

    def test_slow_headers_are_closed(self):
        self.start_local()
        with socket.create_connection(("127.0.0.1", self.port), timeout=4) as s:
            s.sendall(b"GET / HTTP/1.1\r\nHost:")
            started = time.monotonic()
            result = s.recv(65536)
            self.assertTrue(result == b"" or b" 408 " in result)
            self.assertLess(time.monotonic() - started, 3)

    def test_status_lock_permissions_and_shutdown(self):
        p = self.start_local()
        self.assertIn("Running", self.run_cli("status").stdout)
        result = self.run_cli("serve", ok=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("already running", result.stderr)
        self.assertEqual((self.site / ".glowmesh").stat().st_mode & 0o777, 0o700)
        self.assertEqual((self.site / ".glowmesh/server.pid").stat().st_mode & 0o777, 0o600)
        p.send_signal(signal.SIGTERM)
        self.assertEqual(p.wait(timeout=8), 0)
        self.assertNotEqual(self.run_cli("status", ok=False).returncode, 0)

    def test_init_never_overwrites_and_export_excludes_hidden(self):
        old = (self.site / "public/index.html").read_bytes()
        self.assertNotEqual(self.run_cli("init", ".", ok=False).returncode, 0)
        self.assertEqual(old, (self.site / "public/index.html").read_bytes())
        (self.site / "public/.env").write_text("SECRET")
        self.run_cli("export", "exported")
        self.assertFalse((self.site / "exported/.env").exists())
        self.assertEqual((self.site / "exported/index.html").read_bytes(), old)
        self.assertNotEqual(self.run_cli("export", "exported", ok=False).returncode, 0)

    def fake_tor(self):
        script = self.site / "fake-tor.py"
        script.write_text("#!/usr/bin/env python3\n" + f'''
import os, pathlib, shlex, sys, time
if "--version" in sys.argv:
    print("test fixture: no Tor network")
    sys.exit(0)
config = pathlib.Path(sys.argv[sys.argv.index("-f") + 1])
lines = dict((parts[0], parts[1:]) for line in config.read_text().splitlines() if (parts := shlex.split(line, comments=True)))
service = pathlib.Path(lines["HiddenServiceDir"][0])
(service / "hostname").write_text({HOSTNAME!r} + "\\n")
(service / "fixture.pid").write_text(str(os.getpid()))
while True: time.sleep(1)
''')
        script.chmod(0o700)
        config = self.site / "glowmesh.toml"
        config.write_text(config.read_text().replace('tor_binary = "tor"', f'tor_binary = "{script}"'))

    def onion_request(self):
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(3)
            s.connect(str(self.site / ".glowmesh/http.sock"))
            s.sendall(f"GET / HTTP/1.1\r\nHost: {HOSTNAME}\r\n\r\n".encode())
            return s.recv(65536)

    @unittest.skipUnless(HAS_UNIX_SOCKETS, "Execution environment prohibits Unix socket binding")
    def test_onion_socket_no_tcp_child_failure_and_address(self):
        self.fake_tor()
        p = self.start("--onion")
        wait_until(lambda: b" 200 " in self.onion_request())
        self.assertIn(HOSTNAME, self.run_cli("address").stdout)
        self.assertEqual((self.site / ".glowmesh/http.sock").stat().st_mode & 0o777, 0o600)
        with self.assertRaises(OSError):
            socket.create_connection(("127.0.0.1", self.port), timeout=0.5)
        fixture = int((self.site / ".glowmesh/onion/fixture.pid").read_text())
        os.kill(fixture, signal.SIGTERM)
        self.assertNotEqual(p.wait(timeout=8), 0)
        self.assertFalse((self.site / ".glowmesh/http.sock").exists())

    @unittest.skipUnless(HAS_UNIX_SOCKETS, "Execution environment prohibits Unix socket binding")
    def test_onion_parent_shutdown_reaps_child(self):
        self.fake_tor()
        p = self.start("--onion")
        wait_until(lambda: b" 200 " in self.onion_request())
        fixture = int((self.site / ".glowmesh/onion/fixture.pid").read_text())
        p.send_signal(signal.SIGINT)
        self.assertEqual(p.wait(timeout=8), 0)
        with self.assertRaises(ProcessLookupError):
            os.kill(fixture, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
