#!/usr/bin/env python3
"""Black-box control-panel, replication and offline tests. No live Tor required."""
import http.client
import json
import os
from pathlib import Path
import re
import signal
import socket
import struct
import subprocess
import tempfile
import threading
import time
import unittest
from urllib.parse import quote, urlsplit

BINARY = Path(os.environ.get("GLOWMESH_BIN", "target/debug/glowmesh")).resolve()


def get(url):
    u = urlsplit(url)
    c = http.client.HTTPConnection(u.hostname, u.port, timeout=10)
    try:
        c.request("GET", u.path or "/")
        r = c.getresponse()
        return r.status, r.read()
    finally:
        c.close()


class App:
    def __init__(self, path, low_resource=False):
        self.path = path
        path.mkdir(exist_ok=True)
        self.log = tempfile.TemporaryFile()
        # An integration test must never launch the user's real Tor installation.
        env = dict(os.environ, PATH=str(path / "no-programs"))
        self.process = subprocess.Popen(
            [str(BINARY)] + (["--low-resource"] if low_resource else []) + ["app", "--port", "0", "--no-browser"],
            cwd=path, env=env, stdout=self.log, stderr=self.log,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0)
        until = time.monotonic() + 15
        while time.monotonic() < until:
            self.log.seek(0)
            output = self.log.read().decode(errors="replace")
            match = re.search(r"http://(127\.0\.0\.1:\d+)/#([0-9a-f]{64})", output)
            if match:
                self.host, self.token = match.groups()
                self.origin = "http://" + self.host
                self.port = int(self.host.split(":")[1])
                return
            if self.process.poll() is not None:
                raise AssertionError("App failed to start: " + output)
            time.sleep(.03)
        self.stop()
        raise AssertionError("App did not print its control-panel link")

    def request(self, path, method="GET", body=None, auth=True, origin=True, host=None):
        headers = {"Host": host or self.host}
        if auth:
            headers["Authorization"] = "Bearer " + self.token
        if origin:
            headers["Origin"] = self.origin if origin is True else origin
        if isinstance(body, dict):
            headers["Content-Type"] = "application/json"
            body = json.dumps(body).encode()
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=130)
        try:
            c.request(method, path, body=body, headers=headers)
            r = c.getresponse()
            return r.status, dict(r.getheaders()), r.read()
        finally:
            c.close()

    def status(self):
        status, _, body = self.request("/api/status")
        assert status == 200, body
        return json.loads(body)

    @property
    def public(self):
        return next(r["address"] for r in self.status()["routes"] if r["kind"] == "local")

    @property
    def key(self):
        return self.status()["own"]["publisher"]

    def action(self, action, expected=200, **kwargs):
        status, _, data = self.request("/api/action", "POST", {"action": action, **kwargs})
        assert status == expected, (status, data)
        return json.loads(data)

    def upload(self, name, content, expected=200):
        status, _, data = self.request("/api/file?path=" + quote(name, safe=""), "POST", content)
        assert status == expected, (status, data)

    def bundle(self):
        status, _, data = self.request("/api/export?publisher=" + self.key)
        assert status == 200, data
        return data

    def stop(self):
        if self.process.poll() is None:
            self.process.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGTERM)
            try:
                self.process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
                raise AssertionError("App did not shut down cleanly")
        if not self.log.closed:
            self.log.close()


class PanelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="gm-app-")
        self.apps = []

    def tearDown(self):
        for app in reversed(self.apps):
            app.stop()
        self.tmp.cleanup()

    def app(self, name, **kwargs):
        app = App(Path(self.tmp.name) / name, **kwargs)
        self.apps.append(app)
        return app

    def follow(self, reader, source, **kwargs):
        return reader.action("follow", publisher=source.key,
            routes=kwargs.pop("routes", [source.public]),
            auto_sync=kwargs.pop("auto_sync", False), allow_direct=False, **kwargs)

    def test_low_resource_limits_and_manual_updates(self):
        a = self.app("lite", low_resource=True)
        status = a.status()
        self.assertTrue(status["low_resource"])
        self.assertEqual(status["limits"], {"file_mib": 2, "site_mib": 8, "copies": 2, "copy_mib": 32})
        before = a.bundle()
        a.upload("too-big.bin", b"x" * (2 * 1024 * 1024 + 1), expected=400)
        self.assertEqual(a.bundle(), before)
        for name in ["CON", "nul.txt", "COM1.txt", "LPT9", "bad*.txt", "nested/aux.json"]:
            a.upload(name, b"unsafe path", expected=400)
        b, c, d = [self.app(n) for n in ["b", "c", "d"]]
        self.follow(a, b, auto_sync=True, expected=400)
        self.assertEqual(a.status()["copies"], [])
        self.follow(a, b)
        self.follow(a, c)
        self.follow(a, d, expected=400)
        self.assertEqual(len(a.status()["copies"]), 2)
        a.action("auto", publisher=b.key, enabled=True, expected=400)
        b.action("write_page", heading="A new little page", body="Manual update works.")
        b.action("publish", title="A new little page")
        a.action("sync", publisher=b.key)
        copy = next(x for x in a.status()["copies"] if x["publisher"] == b.key)
        self.assertEqual(copy["title"], "A new little page")
        self.assertFalse(copy["peer"]["auto_sync"])
        a.stop()
        restarted = self.app("lite", low_resource=True)
        self.assertEqual(restarted.key, status["own"]["publisher"])
        self.assertEqual(len(restarted.status()["copies"]), 2)

    def test_authentication_origins_and_public_isolation(self):
        a = self.app("a")
        self.assertEqual(a.request("/api/status", auth=False)[0], 401)
        self.assertEqual(a.request("/api/status", host="evil.example")[0], 421)
        self.assertEqual(a.request("/api/status", origin="http://evil.example")[0], 400)
        for origin in [False, a.public.rstrip("/")]:
            self.assertEqual(a.request("/api/action", "POST", {"action": "publish", "title": "bad"}, origin=origin)[0], 400)
        self.assertEqual(a.request("/api/action", "POST", b"x" * 65537)[0], 400)
        a.upload("../escape", b"bad", expected=400)
        a.upload("__glowmesh/manifest.json", b"bad", expected=400)
        for name in ["api/status", "panel.js", ".glowmesh/publisher.key"]:
            self.assertEqual(get(a.public + name)[0], 404)
        code, headers, body = a.request("/", auth=False)
        self.assertEqual(code, 200)
        self.assertIn(b"Your little corner", body)
        self.assertIn("frame-ancestors 'none'", headers["content-security-policy"])
        self.assertEqual(headers["cache-control"], "no-store")
        self.assertNotIn(a.token.encode(), body)

    def test_page_draft_atomic_publish_and_restart(self):
        a = self.app("a")
        original = get(a.public)[1]
        words = "Hello & friends.\n\nSecond paragraph."
        a.action("write_page", heading="Our <bright> corner", body=words)
        self.assertEqual(get(a.public)[1], original)
        a.action("publish", title="Our corner")
        published = get(a.public)[1]
        self.assertIn(b"Our &lt;bright&gt; corner", published)
        self.assertIn(b"Hello &amp; friends.", published)
        self.assertEqual(a.status()["own"]["sequence"], 2)
        a.action("publish", title="", expected=400)
        self.assertEqual(get(a.public)[1], published)
        link = a.path / "public" / "leak.txt"
        link.symlink_to("/etc/passwd")
        a.action("publish", title="bad", expected=400)
        self.assertEqual(get(a.public)[1], published)
        link.unlink()
        a.stop()
        b = self.app("a")
        self.assertEqual(b.status()["editor"]["body"], words)
        self.assertEqual(get(b.public)[1], published)

    def test_replication_update_offline_mirror_restart(self):
        a, b = self.app("a"), self.app("b")
        key, bkey = a.key, b.key
        self.assertEqual(b.action("inspect", address=a.public)["signed"]["manifest"]["publisher"], key)
        self.follow(b, a)
        a.upload("index.html", b"<h1>Version two</h1>")
        a.action("publish", title="Version two")
        b.action("sync", publisher=key)
        b.action("share", publisher=key)
        self.assertEqual(get(b.public)[1], b"<h1>Version two</h1>")
        manifest = json.loads(get(b.public + "__glowmesh/manifest.json")[1])
        self.assertEqual(manifest["manifest"]["publisher"], key)
        a.stop()
        b.action("sync", publisher=key, expected=400)
        preview = b.action("open", publisher=key)["address"]
        self.assertEqual(get(preview)[1], b"<h1>Version two</h1>")
        b.stop()
        c = self.app("b")
        self.assertEqual(c.key, bkey)
        self.assertEqual(c.status()["copies"][0]["sequence"], 2)
        self.assertEqual(get(c.action("open", publisher=key)["address"])[1], b"<h1>Version two</h1>")

    def test_offline_bundle_corruption_confirmation_and_rollback(self):
        a, b = self.app("a"), self.app("b")
        key, old = a.key, a.bundle()
        self.assertNotIn((a.path / ".glowmesh" / "publisher.key").read_bytes(), old)
        a.upload("index.html", b"Offline version two")
        a.action("publish", title="Offline")
        new = a.bundle()
        a.stop()
        for data in [new[:-1], new + b"x", b"BADMAGIC" + new[8:], new[:-1] + bytes([new[-1] ^ 1])]:
            self.assertEqual(b.request("/api/import", "POST", data)[0], 400)
        self.assertEqual(b.request("/api/import", "POST", new)[0], 200)
        self.assertEqual(b.status()["copies"], [])
        b.action("import_confirm", publisher=key)
        self.assertEqual(b.request("/api/import", "POST", old)[0], 400)
        self.assertEqual(get(b.action("open", publisher=key)["address"])[1], b"Offline version two")

    def test_route_fallback_pin_and_connection_failures(self):
        a, b, c = self.app("a"), self.app("b"), self.app("c")
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            dead = "http://127.0.0.1:%s/" % s.getsockname()[1]
        self.follow(b, a, routes=[dead, c.public, a.public])
        old = b.status()["copies"]
        self.follow(b, a, routes=[c.public], expected=400)
        self.assertEqual(b.status()["copies"], old)
        b.action("connection", kind="mesh", enabled=True, address="2001:db8::1", expected=400)
        b.action("connection", kind="onion", enabled=True, address=None, expected=400)
        self.assertEqual(get(b.public)[0], 200)
        b.action("inspect", address="http://" + "a" * 56 + ".onion./", expected=400)

    def test_onion_uses_socks_hostname_and_never_direct_fallback(self):
        a, b = self.app("a"), self.app("b")
        manifest = get(a.public + "__glowmesh/manifest.json")[1]
        seen, failures = [], []
        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        listener.settimeout(10)
        def serve():
            try:
                conn, _ = listener.accept()
                with conn:
                    conn.settimeout(10)
                    def exact(n):
                        data = b""
                        while len(data) < n:
                            chunk = conn.recv(n - len(data))
                            if not chunk:
                                raise AssertionError("SOCKS connection ended")
                            data += chunk
                        return data
                    version, count = exact(2)
                    assert version == 5
                    exact(count)
                    conn.sendall(b"\x05\x00")
                    assert exact(4) == b"\x05\x01\x00\x03"
                    domain = exact(exact(1)[0]).decode()
                    port = struct.unpack("!H", exact(2))[0]
                    seen.append((domain, port))
                    conn.sendall(b"\x05\x00\x00\x01\x7f\x00\x00\x01\x00\x50")
                    request = b""
                    while b"\r\n\r\n" not in request:
                        request += exact(1)
                    conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: " + str(len(manifest)).encode() + b"\r\nConnection: close\r\n\r\n" + manifest)
            except Exception as error:
                failures.append(error)
            finally:
                listener.close()
        thread = threading.Thread(target=serve, daemon=True)
        thread.start()
        b.action("socks", address="127.0.0.1:%s" % listener.getsockname()[1])
        host = "a" * 56 + ".onion"
        self.assertEqual(b.action("inspect", address="http://" + host)["signed"]["manifest"]["publisher"], a.key)
        thread.join(10)
        self.assertEqual(failures, [])
        self.assertEqual(seen, [(host, 80)])
        b.action("socks", address="")
        b.action("inspect", address="http://" + host, expected=400)

    def test_automatic_update(self):
        a, b = self.app("a"), self.app("b")
        key = a.key
        self.follow(b, a, auto_sync=True)
        a.upload("index.html", b"Automatically updated")
        a.action("publish", title="Automatic")
        until = time.monotonic() + 75
        while time.monotonic() < until:
            if b.status()["copies"][0]["sequence"] == 2:
                break
            time.sleep(.25)
        self.assertEqual(b.status()["copies"][0]["sequence"], 2)
        self.assertEqual(get(b.action("open", publisher=key)["address"])[1], b"Automatically updated")

    def test_replication_respects_publisher_rate_limit(self):
        a = self.app("a")
        a.stop()
        config = a.path / "glowmesh.toml"
        config.write_text(config.read_text().replace("requests_per_second = 100", "requests_per_second = 5").replace("burst = 200", "burst = 2"))
        for i in range(9):
            (a.path / "public" / f"part-{i}.txt").write_text(f"Part {i}")
        a = self.app("a")
        a.action("publish", title="Many files")
        b = self.app("b")
        self.follow(b, a)
        self.assertEqual(b.status()["copies"][0]["files"], 11)
        self.assertEqual(get(b.action("open", publisher=a.key)["address"] + "part-8.txt")[1], b"Part 8")


if __name__ == "__main__":
    unittest.main(verbosity=2)
