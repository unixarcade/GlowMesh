// Optional real-browser smoke/layout test. Requires a host that permits Chromium.
'use strict';
const assert = require('node:assert/strict');
const {spawn} = require('node:child_process');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {chromium} = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const binary = path.resolve(process.env.GLOWMESH_BIN || 'target/debug/glowmesh');
const children = [];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function start(folder) {
  await fs.mkdir(folder);
  const child = spawn(binary, ['app', '--port', '0', '--no-browser'], {
    cwd: folder, env: {...process.env, PATH: path.join(folder, 'no-programs')}
  });
  children.push(child);
  let output = '';
  child.stdout.on('data', b => {output += b;});
  child.stderr.on('data', b => {output += b;});
  for (let i = 0; i < 500; i++) {
    const found = output.match(/http:\/\/127\.0\.0\.1:\d+\/#([a-f0-9]{64})/);
    if (found) {
      const link = found[0], origin = new URL(link).origin;
      const state = await (await fetch(origin + '/api/status', {headers: {Authorization: 'Bearer ' + found[1]}})).json();
      return {link, origin, key: state.own.publisher, public: state.routes.find(r => r.kind === 'local').address};
    }
    if (child.exitCode !== null) throw Error('App startup failed');
    await sleep(20);
  }
  throw Error('App startup timed out');
}
async function notice(page, message) {
  await page.waitForFunction(text => document.getElementById('notice').textContent.includes(text) && !document.body.hasAttribute('aria-busy'), message);
}
(async () => {
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'gm-browser-'));
  const out = path.resolve('target/ui-checks');
  await fs.mkdir(out, {recursive: true});
  let browser;
  try {
    const owner = await start(path.join(tmp, 'owner'));
    const friend = await start(path.join(tmp, 'friend'));
    browser = await chromium.launch();
    const page = await browser.newPage({viewport: {width: 1440, height: 1100}});
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(owner.link);
    await page.locator('#workspace').waitFor({state: 'visible'});
    assert.equal(new URL(page.url()).hash, '');
    await page.locator('#heading').fill('Our little corner');
    await page.locator('#body').fill('Hello, many networks.\n\nA page to keep.');
    await page.getByRole('button', {name: 'Save page draft', exact: true}).click();
    await page.locator('#confirm-ok').click();
    await notice(page, 'Draft saved');
    await page.locator('#publish').click();
    await notice(page, 'Published.');
    await page.locator('#file-upload').setInputFiles({name: 'hello.txt', mimeType: 'text/plain', buffer: Buffer.from('Hello from a browser')});
    await notice(page, 'Files added');
    await page.locator('#publish').click();
    await notice(page, 'Published.');
    assert.equal(await (await fetch(owner.public + 'hello.txt')).text(), 'Hello from a browser');
    const downloaded = page.waitForEvent('download');
    await page.locator('#export-own').click();
    const bundle = path.join(out, 'public-test-site.gmb');
    await (await downloaded).saveAs(bundle);
    await notice(page, 'Bundle ready');
    await page.screenshot({path: path.join(out, 'desktop.png'), fullPage: true});
    await page.locator('.nav[data-tab="copies"]').click();
    await page.locator('#add-site').click();
    await page.locator('#peer-routes').fill(friend.public);
    await page.getByRole('button', {name: 'Check publisher'}).click();
    await page.locator('#trust-dialog').waitFor({state: 'visible'});
    assert.equal(await page.locator('#trust-key').textContent(), friend.key);
    assert.equal(await page.locator('#trust-save').isEnabled(), false);
    await page.locator('#trust-check').check();
    await page.locator('#trust-save').click();
    await notice(page, 'Verified copy saved');
    const popupPromise = page.waitForEvent('popup');
    await page.getByRole('button', {name: 'Open saved site'}).click();
    const popup = await popupPromise;
    await popup.waitForURL(url => url.protocol === 'http:');
    await popup.close();
    const other = await browser.newPage();
    await other.goto(friend.link);
    await other.locator('#workspace').waitFor({state: 'visible'});
    await other.locator('.nav[data-tab="copies"]').click();
    await other.locator('#import-file').setInputFiles(bundle);
    await other.locator('#trust-dialog').waitFor({state: 'visible'});
    assert.equal(await other.locator('#trust-key').textContent(), owner.key);
    await other.locator('#trust-check').check();
    await other.locator('#trust-save').click();
    await notice(other, 'Verified copy saved');
    await other.close();
    for (const width of [390, 320]) {
      await page.setViewportSize({width, height: 844});
      for (const tab of ['site', 'connections', 'copies', 'help']) {
        await page.locator(`.nav[data-tab="${tab}"]`).click();
        assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, `Overflow at ${width}px on ${tab}`);
      }
      await page.locator('.nav[data-tab="site"]').click();
      await page.screenshot({path: path.join(out, `mobile-${width}.png`), fullPage: true});
    }
    const locked = await browser.newPage();
    await locked.goto(owner.origin);
    await locked.locator('#locked').waitFor({state: 'visible'});
    assert.equal(await locked.locator('#workspace').isVisible(), false);
    assert.deepEqual(errors, []);
    console.log('PASS: browser UI, uploads, bundles, key confirmation, isolated previews and responsive overflow checks.');
  } finally {
    if (browser) await browser.close();
    for (const child of children.reverse()) {
      if (child.exitCode !== null || child.signalCode !== null) continue;
      const ended = new Promise(resolve => child.once('exit', resolve));
      child.kill('SIGTERM');
      const timer = setTimeout(() => child.kill('SIGKILL'), 8000);
      await ended;
      clearTimeout(timer);
    }
    await fs.rm(tmp, {recursive: true});
  }
})().catch(error => {console.error(error); process.exitCode = 1;});
