// Runs the shipped UI JavaScript against real app processes using a DOM emulator.
// This checks interactions and API integration, not layout or browser CSP enforcement.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {JSDOM, VirtualConsole} = require(process.env.JSDOM_MODULE || 'jsdom');
const binary = path.resolve(process.env.GLOWMESH_BIN || 'target/debug/glowmesh');
const processes = [];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(check, name, timeout = 10000) {
  const end = Date.now() + timeout;
  while (Date.now() < end) {
    if (await check()) return;
    await sleep(20);
  }
  throw Error('Timed out: ' + name);
}
async function start(folder) {
  await fs.mkdir(folder);
  const child = spawn(binary, [...(process.env.GLOWMESH_TEST_LITE ? ['--low-resource'] : []), 'app', '--port', '0', '--no-browser'], {
    cwd: folder, env: {...process.env, PATH: path.join(folder, 'no-programs')}
  });
  processes.push(child);
  let log = '';
  child.stdout.on('data', data => {log += data;});
  child.stderr.on('data', data => {log += data;});
  child.on('error', error => {log += error.message;});
  await waitFor(() => /http:\/\/127\.0\.0\.1:\d+\/#([a-f0-9]{64})/.test(log), 'app startup: ' + folder);
  const link = log.match(/http:\/\/127\.0\.0\.1:\d+\/#([a-f0-9]{64})/)[0];
  const origin = new URL(link).origin, token = new URL(link).hash.slice(1);
  async function api(endpoint, payload) {
    const response = await fetch(origin + endpoint, {
      method: payload ? 'POST' : 'GET',
      headers: {Authorization: 'Bearer ' + token, Origin: origin, 'Content-Type': 'application/json'},
      body: payload ? JSON.stringify(payload) : undefined
    });
    assert.equal(response.status, 200, await response.clone().text());
    return response.json();
  }
  const state = await api('/api/status');
  return {origin, token, link, api, key: state.own.publisher, public: state.routes.find(r => r.kind === 'local').address};
}
async function stop(child) {
  if (child.exitCode !== null || child.signalCode !== null) return;
  const ended = new Promise(resolve => child.once('exit', resolve));
  child.kill('SIGTERM');
  const timer = setTimeout(() => child.kill('SIGKILL'), 8000);
  await ended;
  clearTimeout(timer);
  assert.equal(child.signalCode, null, 'app must shut down gracefully');
}
(async () => {
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'gm-ui-'));
  let dom;
  try {
    const owner = await start(path.join(tmp, 'owner'));
    const friend = await start(path.join(tmp, 'friend'));
    const errors = [], popups = [];
    const console = new VirtualConsole();
    console.on('jsdomError', error => errors.push(error));
    dom = new JSDOM(await (await fetch(owner.origin)).text(), {
      url: owner.link, runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: console
    });
    const w = dom.window, d = w.document, $ = id => d.getElementById(id);
    w.scrollTo = () => {};
    w.HTMLDialogElement.prototype.showModal = function () {this.setAttribute('open', '');};
    w.HTMLDialogElement.prototype.close = function () {this.removeAttribute('open');};
    w.open = () => {
      const popup = {opener: null, closed: false, location: {replace: url => {popup.url = url;}}, close: () => {popup.closed = true;}};
      popups.push(popup);
      return popup;
    };
    w.fetch = async (url, options = {}) => {
      let body = options.body;
      if (body instanceof w.Blob) {
        body = Buffer.from(await new Promise((resolve, reject) => {
          const reader = new w.FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsArrayBuffer(body);
        }));
      }
      return fetch(new URL(url, owner.origin), {...options, body, headers: {...options.headers, Origin: owner.origin}});
    };
    w.eval(await (await fetch(owner.origin + '/panel.js')).text());
    await waitFor(() => !$('workspace').hidden && $('file-count').textContent, 'initial UI');
    assert.equal(w.location.hash, '');
    if (process.env.GLOWMESH_TEST_LITE) {
      assert.match($('profile-label').textContent, /Low Resource/);
      assert.match($('copy-limits').textContent, /Up to 2 sites/);
      assert.match($('upload-limits').textContent, /2 MiB per file/);
    }
    assert.equal(w.sessionStorage.getItem('glowmesh-token'), owner.token);
    const submit = id => $(id).dispatchEvent(new w.Event('submit', {bubbles: true, cancelable: true}));
    async function notice(text) {
      await waitFor(() => $('notice').textContent.includes(text) && !d.body.hasAttribute('aria-busy'), text);
    }
    $('heading').value = 'Luminosity’s little corner';
    $('body').value = 'Hello, many networks.\n\nA page to keep.';
    submit('page-form');
    await waitFor(() => $('confirm-dialog').hasAttribute('open'), 'draft confirmation');
    $('confirm-ok').click();
    await notice('Draft saved');
    $('publish').click();
    await notice('Published.');
    assert.equal((await owner.api('/api/status')).own.title, 'Luminosity’s little corner');
    const file = new w.File(['Hello from a file'], 'hello.txt', {type: 'text/plain'});
    Object.defineProperty($('file-upload'), 'files', {value: [file], configurable: true});
    $('file-upload').dispatchEvent(new w.Event('change'));
    await notice('Files added');
    $('publish').click();
    await notice('Published.');
    assert.equal(await (await fetch(owner.public + 'hello.txt')).text(), 'Hello from a file');
    d.querySelector('.nav[data-tab="copies"]').click();
    assert.equal($('tab-copies').hidden, false);
    $('add-site').click();
    $('peer-routes').value = friend.public;
    submit('save-form');
    await waitFor(() => $('trust-dialog').hasAttribute('open'), 'publisher inspection');
    assert.equal($('trust-key').textContent, friend.key);
    assert.equal($('trust-save').disabled, true);
    if (process.env.GLOWMESH_TEST_LITE) assert.equal($('auto-option').hidden, true);
    $('trust-check').click();
    assert.equal($('trust-save').disabled, false);
    $('trust-save').click();
    await notice('Verified copy saved');
    assert.equal(d.querySelectorAll('.copy-card').length, 1);
    if (process.env.GLOWMESH_TEST_LITE) assert.equal(d.querySelector('.copy-card input[type=checkbox]').disabled, true);
    [...d.querySelectorAll('.copy-card button')].find(b => b.textContent.startsWith('Open saved')).click();
    await waitFor(() => popups[0]?.url, 'saved preview');
    assert.equal((await fetch(popups[0].url)).status, 200);
    await waitFor(() => !d.body.hasAttribute('aria-busy'), 'preview complete');
    d.querySelector('.nav[data-tab="connections"]').click();
    $('socks').value = '127.0.0.1:9050';
    submit('socks-form');
    await notice('Tor download settings saved');
    assert.equal((await owner.api('/api/status')).socks, '127.0.0.1:9050');
    if (!(await owner.api('/api/status')).mesh_addresses.length) {
      $('mesh-toggle').click();
      await notice('No mesh address');
      assert.equal($('notice').className, 'error');
    }
    assert.deepEqual(errors, []);
    process.stdout.write('PASS: real UI scripts + live API: draft, publish, upload, identity confirmation, replication, preview, settings, error handling.\n');
  } finally {
    if (dom) dom.window.close();
    for (const child of processes.reverse()) await stop(child);
    await fs.rm(tmp, {recursive: true});
  }
})().catch(error => {console.error(error); process.exitCode = 1;});
