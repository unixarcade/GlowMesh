@echo off
setlocal DisableDelayedExpansion
set "server_bin=%~dp0bin\windows-x86_64\glowmesh.exe"
if not exist "%server_bin%" goto missing
if not defined LOCALAPPDATA goto nodata
set "site_dir=%LOCALAPPDATA%\Glowmesh\my-site-lite"
if defined GLOWMESH_SITE set "site_dir=%GLOWMESH_SITE%"
echo Your site folder: "%site_dir%"
echo Keep this window open. Press Ctrl-C here to stop Glowmesh.
"%server_bin%" --low-resource --config "%site_dir%\glowmesh.toml" app %*
set "exit_status=%ERRORLEVEL%"
if not "%exit_status%"=="0" pause
exit /b %exit_status%
:missing
echo The Windows executable is missing. Extract the complete ZIP first.
pause
exit /b 1
:nodata
echo Windows LOCALAPPDATA is missing. Run from your normal Windows account.
pause
exit /b 1
