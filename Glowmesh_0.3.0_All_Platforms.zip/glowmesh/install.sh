#!/bin/sh
# Local install; no sudo, remote script execution, or system configuration edits.
set -eu
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
install_prefix=${GLOWMESH_PREFIX:-"$HOME/.local"}
build_mode=${1:-auto}
case "$build_mode" in auto|--source) ;; *) echo "Usage: ./install.sh [--source]" >&2; exit 2;; esac
if [ "$build_mode" = auto ]; then
    . "$project_dir/scripts/select-binary.sh"
    select_binary
    candidate="$server_bin"
    echo "Installing the included $target executable."
else
    command -v cargo >/dev/null 2>&1 || {
        echo "Install current stable Rust from https://rustup.rs, then run this again." >&2
        echo "The supplied Windows, Mac, Linux and Raspberry Pi binaries need no Rust." >&2
        exit 1
    }
    echo "Building from the locked Rust dependencies…"
    (cd "$project_dir" && cargo build --release --locked)
    candidate="$project_dir/target/release/glowmesh"
fi
mkdir -p "$install_prefix/bin"
temp_binary=$(mktemp "$install_prefix/bin/.glowmesh-install.XXXXXX")
trap '[ ! -f "$temp_binary" ] || rm "$temp_binary"' EXIT HUP INT TERM
cp "$candidate" "$temp_binary"
chmod 755 "$temp_binary"
"$temp_binary" --version
mv -f "$temp_binary" "$install_prefix/bin/glowmesh"
echo "Installed: $install_prefix/bin/glowmesh"
echo "If needed, add that bin directory to PATH."
echo "Next: sh ./Start_Glowmesh.sh"
echo "Or:   glowmesh --config /path/to/my-site/glowmesh.toml app"
