//! Offline check of the actual generated configuration against installed Tor.
//! Run: cargo run --locked --example verify-tor -- /usr/bin/tor
use anyhow::{ensure, Result};
use glowmesh::{onion, state};
use std::{fs, process::Command};

fn main() -> Result<()> {
    let binary = std::env::args().nth(1).unwrap_or_else(|| "tor".into());
    let temp = tempfile::tempdir()?;
    let private = temp.path().join("state with spaces");
    state::private_dir(&private)?;
    state::private_dir(&private.join("tor-data"))?;
    state::private_dir(&private.join("onion"))?;
    let config = private.join("torrc");
    let defaults = private.join("tor-defaults");
    fs::write(&defaults, "")?;
    #[cfg(unix)]
    let backend = format!(
        "unix:{}",
        onion::quote(private.join("http.sock").to_str().unwrap())?
    );
    #[cfg(windows)]
    let backend = "127.0.0.1:18080".to_string();
    fs::write(
        &config,
        onion::torrc_target(&private, &backend, std::process::id())?,
    )?;
    let status = Command::new(binary)
        .arg("--defaults-torrc")
        .arg(defaults)
        .arg("-f")
        .arg(config)
        .args(["--DisableNetwork", "1", "--verify-config"])
        .status()?;
    ensure!(status.success(), "Tor rejected the generated configuration");
    println!("Generated onion configuration accepted by Tor; no network service started.");
    Ok(())
}
