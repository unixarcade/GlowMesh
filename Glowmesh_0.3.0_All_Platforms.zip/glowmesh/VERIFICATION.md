# Verification — Glowmesh 0.3.0

Checked on 2026-10-06 in Linux x86_64 / Ubuntu 24.04. Every included executable
was built from this source with Cargo.lock and Rust 1.94.0. The six binaries,
individual sizes and SHA-256 hashes are listed in BINARY_MANIFEST.json.

## Platform coverage

| Platform | Build | Execution checks |
|---|---|---|
| Windows x64 | PE32+; Windows system DLLs only; strict Clippy passed | No native Windows host available |
| Apple silicon Mac | Mach-O arm64, PIE, ad-hoc signature; minimum macOS 11.7.1 | No native Mac host available |
| Intel Mac | Mach-O x86_64, PIE; minimum macOS 11.7.1 | No native Mac host available |
| Linux x64 | Static musl PIE, stripped | Full Rust/HTTP/app suites; UI interactions and launchers |
| Raspberry Pi / ARM64 Linux | Static musl ELF, stripped | Four integration scenarios passed under QEMU 8.2.2 |
| Raspberry Pi / ARMv7 Linux | Static musl ELF, hard-float, stripped | The same four scenarios passed under QEMU 8.2.2 |

The ARM builds are static non-PIE executables. QEMU tests exercise instruction
execution and application behavior on the Linux host; they do not measure real
Pi performance, SD-card behavior, physical networking, or memory requirements.
The Mac builds depend only on libSystem, libiconv and libcharset from macOS.
No Tor/Yggdrasil executable, private site, signing key or panel token is bundled.

## Completed checks

| Check | Result |
|---|---|
| Rust formatting | cargo fmt --all --check passed |
| Linux lint | cargo clippy --locked --all-targets -- -D warnings passed |
| Windows target lint | The same strict Clippy gate passed for x86_64-pc-windows-gnu |
| Rust unit tests | 20 passed |
| Linux legacy HTTP/process tests | 9 passed; 2 explicit Unix-socket environment skips |
| Linux app/replication tests | 9 passed, including the one-minute automatic update test |
| ARM64 app tests | 4 passed under emulation |
| ARMv7 app tests | 4 passed under emulation |
| UI interaction test | Passed in both normal and Low Resource modes using jsdom 26.1.0 and real app/API processes |
| Launchers/installer | Linux user-prefix install; normal/low profile; spaced data paths; protected key modes; clean shutdown passed |
| Shell and JavaScript syntax | Launchers, selection helper, installer, panel and UI test checked |
| Actual Tor config | Tor 0.4.9.11 accepted the generated Unix backend configuration offline |
| Dependency audit | cargo-audit 0.22.2: zero known vulnerabilities and zero warnings |

The audit covered 218 locked dependencies and 1,290 RustSec advisories at commit
`ef6173cbc5c50ec8166f9a5b28f07834144373ee`, last updated
2026-10-03T10:14:03+02:00. Dependency notices cover the union of 170 normal/build
packages across the six targets. Compiler/runtime notices are included separately.

The app scenarios include token/Host/Origin boundaries, upload/path restrictions,
escaped page editing and atomic publication, private identity persistence, signed
replication, route fallback, onion hostname forwarding through mock SOCKS, corrupt
and rollback bundle rejection, offline previews, mirroring under the owner's
signature, manual/automatic update behavior and publisher rate limiting.

Low Resource tests verify its actual API limits, oversized-file rejection,
portable device-name rejection, two-copy budget, refusal of automatic updates,
manual refresh, and preserved identity/copies after restart. Both emulated ARM
targets additionally exercise panel isolation, bundle integrity/rollback and
replication/offline mirroring. Arithmetic checks account for 32-bit bundle sizes.

## Remaining native checks

Windows ACLs, Explorer launch behavior, CTRL-C/close behavior, Tor process
startup and the Windows loopback backend were compiled and reviewed but not
executed on Windows. Mac Finder/Gatekeeper, native signals and Tor startup also
await a native Mac run. Desktop binaries are not publisher-signed or notarized;
first-open prompts are covered in INSTALL.md.

This environment refuses Unix-domain socket binding. Two Unix onion-socket
integration tests skip explicitly; fake-child lifecycle and Tor's offline parser
still ran. A browser cannot start here with its required Unix-socket facilities.
The jsdom check tests script/API interaction, not native layout, CSP enforcement,
file pickers, or browser accessibility. The supplied optional real-browser test
can be run on a normal desktop.

No live onion service was published or visited, no Yggdrasil peers were joined,
and no physical Pi was used. Docker/systemd and hosted CI recipes were not run.
Native Windows/Mac trials and real network reachability checks remain necessary
before treating those integrations as deployment-verified. Security boundaries
and resource limits are described in SECURITY.md.
