use crate::{
    config::Config,
    site::{byte_range, request_path, Site},
};
use bytes::Bytes;
use http_body_util::Full;
use hyper::{
    header::{self, HeaderValue},
    Method, Request, Response, StatusCode,
};
use std::{
    sync::{Arc, Mutex, RwLock},
    time::Instant,
};

pub type Reply = Response<Full<Bytes>>;

pub struct App {
    pub site: RwLock<Arc<Site>>,
    hosts: Vec<String>,
    csp: HeaderValue,
    bucket: Mutex<Bucket>,
}

struct Bucket {
    tokens: f64,
    rate: f64,
    capacity: f64,
    last: Instant,
}
impl Bucket {
    fn take(&mut self) -> bool {
        let now = Instant::now();
        self.tokens = (self.tokens + now.duration_since(self.last).as_secs_f64() * self.rate)
            .min(self.capacity);
        self.last = now;
        if self.tokens < 1.0 {
            return false;
        }
        self.tokens -= 1.0;
        true
    }
}

impl App {
    pub fn new(config: &Config, site: Site, onion_host: Option<&str>) -> Self {
        let mut hosts = config
            .server
            .allowed_hosts
            .iter()
            .map(|h| h.to_ascii_lowercase())
            .collect::<Vec<_>>();
        if let Some(host) = onion_host {
            hosts.extend([host.into(), format!("{host}:80")]);
        } else {
            hosts.push(config.server.bind.to_string());
            if config.server.bind.port() == 80 {
                let h = match config.server.bind.ip() {
                    std::net::IpAddr::V4(ip) => ip.to_string(),
                    std::net::IpAddr::V6(ip) => format!("[{ip}]"),
                };
                hosts.push(h);
            }
            if config.server.bind.ip().is_loopback() {
                hosts.push(format!("localhost:{}", config.server.bind.port()));
                if config.server.bind.port() == 80 {
                    hosts.push("localhost".into());
                }
            }
        }
        Self {
            site: RwLock::new(Arc::new(site)),
            hosts,
            csp: config
                .server
                .content_security_policy
                .parse()
                .expect("validated CSP"),
            bucket: Mutex::new(Bucket {
                tokens: config.limits.burst as f64,
                capacity: config.limits.burst as f64,
                rate: config.limits.requests_per_second as f64,
                last: Instant::now(),
            }),
        }
    }

    pub fn respond<B>(&self, req: &Request<B>) -> Reply {
        let head = req.method() == Method::HEAD;
        let mut reply = if self.bucket.lock().expect("bucket lock").take() {
            self.route(req)
        } else {
            let mut r = message(
                StatusCode::TOO_MANY_REQUESTS,
                "Busy. Please retry shortly.\n",
            );
            r.headers_mut()
                .insert(header::RETRY_AFTER, HeaderValue::from_static("1"));
            r
        };
        let h = reply.headers_mut();
        h.insert(header::CONTENT_SECURITY_POLICY, self.csp.clone());
        h.insert(
            header::X_CONTENT_TYPE_OPTIONS,
            HeaderValue::from_static("nosniff"),
        );
        h.insert(header::X_FRAME_OPTIONS, HeaderValue::from_static("DENY"));
        h.insert(
            header::REFERRER_POLICY,
            HeaderValue::from_static("no-referrer"),
        );
        h.insert(
            "permissions-policy",
            HeaderValue::from_static(
                "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
            ),
        );
        h.insert(
            "cross-origin-resource-policy",
            HeaderValue::from_static("same-origin"),
        );
        h.insert(
            header::CACHE_CONTROL,
            HeaderValue::from_static("private, no-cache"),
        );
        h.insert(header::CONNECTION, HeaderValue::from_static("close"));
        if head {
            *reply.body_mut() = Full::new(Bytes::new());
        }
        reply
    }

    fn route<B>(&self, req: &Request<B>) -> Reply {
        if req.uri().scheme().is_some() || req.uri().authority().is_some() {
            return message(StatusCode::BAD_REQUEST, "Origin-form request required.\n");
        }
        let mut host_values = req.headers().get_all(header::HOST).iter();
        let host = host_values.next().and_then(|h| h.to_str().ok());
        if host_values.next().is_some() || host.is_none() {
            return message(StatusCode::BAD_REQUEST, "One Host header required.\n");
        }
        if !self
            .hosts
            .iter()
            .any(|allowed| allowed.eq_ignore_ascii_case(host.unwrap()))
        {
            return message(StatusCode::MISDIRECTED_REQUEST, "Host not allowed.\n");
        }
        if req.method() != Method::GET && req.method() != Method::HEAD {
            let mut r = message(
                StatusCode::METHOD_NOT_ALLOWED,
                "Read-only site: use GET or HEAD.\n",
            );
            r.headers_mut()
                .insert(header::ALLOW, HeaderValue::from_static("GET, HEAD"));
            return r;
        }
        let length = req
            .headers()
            .get(header::CONTENT_LENGTH)
            .map(|v| v.to_str().ok().and_then(|s| s.parse::<u64>().ok()));
        if req.headers().contains_key(header::TRANSFER_ENCODING)
            || matches!(length, Some(None) | Some(Some(1..)))
        {
            return message(
                StatusCode::PAYLOAD_TOO_LARGE,
                "Request bodies are disabled.\n",
            );
        }
        if req
            .uri()
            .path_and_query()
            .is_some_and(|p| p.as_str().len() > 4096)
        {
            return message(StatusCode::URI_TOO_LONG, "URI too long.\n");
        }
        let Some(path) = request_path(req.uri().path()) else {
            return message(StatusCode::NOT_FOUND, "Not found.\n");
        };
        let site = self.site.read().expect("site lock").clone();
        if site.directories.contains(&path) && !path.ends_with('/') {
            let mut location = format!("{}/", req.uri().path());
            if let Some(q) = req.uri().query() {
                location.push('?');
                location.push_str(q);
            }
            let Ok(location) = HeaderValue::from_str(&location) else {
                return message(StatusCode::BAD_REQUEST, "Invalid location.\n");
            };
            let mut r = message(StatusCode::PERMANENT_REDIRECT, "Directory moved.\n");
            r.headers_mut().insert(header::LOCATION, location);
            return r;
        }
        let key = if path.ends_with('/') {
            format!("{path}index.html")
        } else {
            path
        };
        let Some(asset) = site.assets.get(&key) else {
            return message(StatusCode::NOT_FOUND, "Not found.\n");
        };
        let mut r = Response::new(Full::new(Bytes::new()));
        let h = r.headers_mut();
        h.insert(header::CONTENT_TYPE, asset.mime.parse().expect("MIME"));
        h.insert(header::ETAG, asset.etag.parse().expect("ETag"));
        h.insert(header::ACCEPT_RANGES, HeaderValue::from_static("bytes"));
        if req
            .headers()
            .get(header::IF_NONE_MATCH)
            .and_then(|h| h.to_str().ok())
            .is_some_and(|s| {
                s.split(',')
                    .any(|v| v.trim() == "*" || v.trim().trim_start_matches("W/") == asset.etag)
            })
        {
            *r.status_mut() = StatusCode::NOT_MODIFIED;
            return r;
        }
        let mut bytes = asset.bytes.clone();
        let range_allowed = req
            .headers()
            .get(header::IF_RANGE)
            .is_none_or(|v| v.as_bytes() == asset.etag.as_bytes());
        if req.method() == Method::GET && range_allowed {
            if let Some(range_header) = req.headers().get(header::RANGE) {
                let range = range_header
                    .to_str()
                    .ok()
                    .and_then(|s| byte_range(s, bytes.len()));
                let Some((start, end)) = range else {
                    let mut error = message(
                        StatusCode::RANGE_NOT_SATISFIABLE,
                        "Range not satisfiable.\n",
                    );
                    error.headers_mut().insert(
                        header::CONTENT_RANGE,
                        format!("bytes */{}", bytes.len()).parse().unwrap(),
                    );
                    return error;
                };
                *r.status_mut() = StatusCode::PARTIAL_CONTENT;
                r.headers_mut().insert(
                    header::CONTENT_RANGE,
                    format!("bytes {start}-{end}/{}", bytes.len())
                        .parse()
                        .unwrap(),
                );
                bytes = bytes.slice(start..=end);
            }
        }
        r.headers_mut()
            .insert(header::CONTENT_LENGTH, bytes.len().into());
        *r.body_mut() = Full::new(bytes);
        r
    }
}

fn message(status: StatusCode, text: &'static str) -> Reply {
    let mut r = Response::new(Full::new(Bytes::from_static(text.as_bytes())));
    *r.status_mut() = status;
    r.headers_mut().insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("text/plain; charset=utf-8"),
    );
    r.headers_mut()
        .insert(header::CONTENT_LENGTH, text.len().into());
    r
}

#[cfg(test)]
mod tests {
    use super::*;
    use http_body_util::BodyExt;
    use std::collections::{BTreeMap, BTreeSet};
    fn app() -> App {
        let asset = crate::site::Asset {
            bytes: Bytes::from_static(b"hello world"),
            mime: "text/html".into(),
            etag: "\"test\"".into(),
        };
        App::new(
            &Config::default(),
            Site {
                assets: BTreeMap::from([("/index.html".into(), asset)]),
                directories: BTreeSet::new(),
                bytes: 11,
            },
            None,
        )
    }
    fn request(method: &str, path: &str, host: &str) -> Request<()> {
        Request::builder()
            .method(method)
            .uri(path)
            .header("Host", host)
            .body(())
            .unwrap()
    }
    #[tokio::test]
    async fn head_and_get() {
        let a = app();
        let r = a.respond(&request("GET", "/", "127.0.0.1:8080"));
        assert_eq!(r.status(), StatusCode::OK);
        assert!(r.headers().contains_key("content-security-policy"));
        assert!(!r.headers().contains_key("server"));
        assert_eq!(
            r.into_body().collect().await.unwrap().to_bytes(),
            "hello world"
        );
        let r = a.respond(&request("HEAD", "/", "localhost:8080"));
        assert_eq!(r.headers()["content-length"], "11");
        assert!(r.into_body().collect().await.unwrap().to_bytes().is_empty());
    }
    #[test]
    fn host_method_body_and_proxy_defenses() {
        let a = app();
        assert_eq!(a.respond(&request("GET", "/", "evil.test")).status(), 421);
        assert_eq!(
            a.respond(&request("POST", "/", "localhost:8080")).status(),
            405
        );
        assert_eq!(
            a.respond(&request("GET", "http://evil.test/", "localhost:8080"))
                .status(),
            400
        );
        let mut req = request("GET", "/", "localhost:8080");
        req.headers_mut()
            .insert("content-length", "500".parse().unwrap());
        assert_eq!(a.respond(&req).status(), 413);
        req.headers_mut().remove("content-length");
        req.headers_mut()
            .append("host", "evil.test".parse().unwrap());
        assert_eq!(a.respond(&req).status(), 400);
    }
    #[tokio::test]
    async fn conditional_and_range() {
        let a = app();
        let mut req = request("GET", "/", "localhost:8080");
        req.headers_mut()
            .insert("range", "bytes=6-".parse().unwrap());
        let r = a.respond(&req);
        assert_eq!(r.status(), 206);
        assert_eq!(r.into_body().collect().await.unwrap().to_bytes(), "world");
        req.headers_mut()
            .insert("if-range", "\"old\"".parse().unwrap());
        assert_eq!(a.respond(&req).status(), 200);
        req.headers_mut()
            .insert("if-none-match", "W/\"test\"".parse().unwrap());
        assert_eq!(a.respond(&req).status(), 304);
    }
    #[test]
    fn rate_is_global_and_bounded() {
        let a = app();
        for _ in 0..200 {
            assert_ne!(
                a.respond(&request("GET", "/", "localhost:8080")).status(),
                429
            );
        }
        assert_eq!(
            a.respond(&request("GET", "/", "localhost:8080")).status(),
            429
        );
    }
}
