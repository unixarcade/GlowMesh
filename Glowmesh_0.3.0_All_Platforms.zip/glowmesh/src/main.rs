use anyhow::{bail, ensure, Context, Result};
use clap::{Parser, Subcommand};
use glowmesh::{
    config::{is_yggdrasil, Config},
    http::App,
    onion::{self, OnionProcess},
    platform::{self, Listener, Reload, Shutdown, Stream},
    site::Site,
    state::{self, State},
};
use hyper::{server::conn::http1, service::service_fn};
use hyper_util::rt::{TokioIo, TokioTimer};
use std::{
    convert::Infallible,
    fs::{self, OpenOptions},
    io::Write,
    net::IpAddr,
    path::{Path, PathBuf},
    sync::Arc,
    time::Duration,
};
use tokio::{
    io::{AsyncRead, AsyncWrite},
    net::TcpListener,
    sync::Semaphore,
    task::JoinSet,
};

#[derive(Parser)]
#[command(
    name = "glowmesh",
    version,
    about = "Your little corner of the network. Local, onion, or mesh."
)]
struct Cli {
    #[arg(
        long,
        global = true,
        default_value = "glowmesh.toml",
        help = "Config file; relative settings resolve beside it"
    )]
    config: PathBuf,
    #[arg(
        long,
        global = true,
        help = "Use smaller content/connection budgets and manual updates"
    )]
    low_resource: bool,
    #[command(subcommand)]
    command: Action,
}

#[derive(Subcommand)]
enum Action {
    /// Open the friendly local control panel, creating a starter if needed.
    App {
        #[arg(long, default_value_t = 4880)]
        port: u16,
        #[arg(long)]
        no_browser: bool,
    },
    /// Create a config and a tiny starter website without overwriting files.
    Init {
        #[arg(default_value = ".")]
        directory: PathBuf,
    },
    /// Serve the site; Ctrl-C stops both the web server and its Tor child.
    Serve {
        #[arg(long, conflicts_with_all = ["local", "mesh"], help = "Start a private Tor v3 onion service (no TCP web port)")]
        onion: bool,
        #[arg(
            long,
            conflicts_with = "mesh",
            help = "Force loopback preview, ignoring onion.enabled and network bind"
        )]
        local: bool,
        #[arg(
            long,
            help = "Serve on one Yggdrasil IPv6 address (Yggdrasil must already run)"
        )]
        mesh: Option<IpAddr>,
    },
    /// Validate configuration and public files without starting a listener.
    Check {
        #[arg(long, help = "Also check that the Tor executable works")]
        tor: bool,
    },
    /// Print the persistent onion address; does not prove network reachability.
    Address,
    /// Check the local process lock; does not contact the network.
    Status,
    /// Write a new directory containing only the validated public snapshot.
    Export { directory: PathBuf },
}

fn main() {
    let cli = Cli::parse();
    let mut builder = if cli.low_resource {
        tokio::runtime::Builder::new_current_thread()
    } else {
        let mut b = tokio::runtime::Builder::new_multi_thread();
        b.worker_threads(2);
        b
    };
    let outcome = builder
        .enable_all()
        .build()
        .map_err(anyhow::Error::from)
        .and_then(|runtime| runtime.block_on(run(cli)));
    if let Err(e) = outcome {
        eprintln!("glowmesh: {e:#}");
        std::process::exit(1);
    }
}

async fn run(cli: Cli) -> Result<()> {
    if let Action::Init { directory } = &cli.command {
        return initialize(directory);
    }
    if matches!(cli.command, Action::App { .. }) && !cli.config.exists() {
        ensure!(
            cli.config.file_name().is_some_and(|n| n == "glowmesh.toml"),
            "A new app needs a glowmesh.toml filename"
        );
        initialize(
            cli.config
                .parent()
                .filter(|p| !p.as_os_str().is_empty())
                .unwrap_or(Path::new(".")),
        )?;
    }
    let mut config = Config::load(&cli.config)?;
    if cli.low_resource {
        config.apply_low_resource();
    }
    match cli.command {
        Action::Init { .. } => unreachable!(),
        Action::App { port, no_browser } => glowmesh::panel::run(config, port, no_browser).await,
        Action::Serve { onion, local, mesh } => {
            config.onion.enabled |= onion;
            if local {
                config.onion.enabled = false;
                config.server.bind.set_ip("127.0.0.1".parse().unwrap());
                config.server.allow_network = false;
                config.server.allowed_hosts.clear();
            }
            if let Some(ip) = mesh {
                ensure!(
                    is_yggdrasil(ip),
                    "--mesh requires a Yggdrasil IPv6 address in 0200::/7"
                );
                ensure!(!config.onion.enabled, "Choose one identity per process: disable onion.enabled for mesh mode, or use separate site configurations");
                config.server.bind.set_ip(ip);
                config.server.allow_network = true;
            }
            config.validate_listener()?;
            serve(config).await
        }
        Action::Check { tor } => {
            config.validate_listener()?;
            let site = Site::load(&config)?;
            println!(
                "OK: {} public files, {} bytes; configuration valid.",
                site.assets.len(),
                site.bytes
            );
            if tor || config.onion.enabled {
                onion::version(&config).await?;
            }
            println!(
                "Network reachability is checked by opening the site from a visitor's device."
            );
            Ok(())
        }
        Action::Address => {
            println!("http://{}/", state::address(&config)?);
            Ok(())
        }
        Action::Status => {
            let running = state::running(&config)?;
            println!(
                "{}",
                if running {
                    "Running: this site's process lock is held."
                } else {
                    "Stopped: this site's process lock is free."
                }
            );
            if let Ok(host) = state::address(&config) {
                println!("Saved onion address: http://{host}/");
            }
            println!("A saved address does not mean Tor is connected or this mode is active.");
            if running {
                Ok(())
            } else {
                bail!("Site is not running")
            }
        }
        Action::Export { directory } => {
            let site = Site::load(&config)?;
            site.export(&directory)?;
            println!(
                "Exported {} files to {}",
                site.assets.len(),
                directory.display()
            );
            Ok(())
        }
    }
}

fn initialize(directory: &Path) -> Result<()> {
    let destinations = ["glowmesh.toml", "public/index.html", "public/style.css"];
    for name in destinations {
        ensure!(
            fs::symlink_metadata(directory.join(name)).is_err(),
            "Refusing to overwrite {}",
            directory.join(name).display()
        );
    }
    fs::create_dir_all(directory.join("public"))?;
    let config = format!("# Glowmesh — paths are relative to this file.\n# Put only public content in public/. Keep .glowmesh/ private.\n{}", toml::to_string_pretty(&Config::default())?);
    for (name, contents) in [
        ("glowmesh.toml", config.as_str()),
        ("public/index.html", include_str!("../assets/index.html")),
        ("public/style.css", include_str!("../assets/style.css")),
    ] {
        OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(directory.join(name))?
            .write_all(contents.as_bytes())?;
    }
    println!("Created {}", directory.display());
    println!("Next: cd '{}'", directory.display());
    println!("      glowmesh app            # friendly control panel");
    println!("      glowmesh serve --onion  # publish through Tor");
    Ok(())
}

async fn serve(config: Config) -> Result<()> {
    let mut shutdown = Shutdown::new()?;
    let mut reload = Reload::new()?;
    let site = Site::load(&config)?;
    println!(
        "Loaded {} files, {} bytes. No visitor access logs.",
        site.assets.len(),
        site.bytes
    );
    let state = State::acquire(&config)?;
    let mut tor = None;
    let mut onion_host = None;
    let listener = if config.onion.enabled {
        let (listener, target) = platform::onion_listener(&state).await?;
        let mut child = OnionProcess::start_target(&config, &state, &target)?;
        let host = tokio::select! {
            r = child.wait_for_address(&config) => r?,
            _ = shutdown.recv() => { child.stop().await; return Ok(()); },
        };
        println!("Onion address: http://{host}/");
        println!("Tor may still be bootstrapping/publishing. Test this address in Tor Browser.");
        println!("Local Tor backend: {target}");
        tor = Some(child);
        onion_host = Some(host);
        listener
    } else {
        let listener = TcpListener::bind(config.server.bind).await.context(
            "Cannot bind address; check whether it belongs to this machine or is already in use",
        )?;
        println!("Listening: http://{}/", config.server.bind);
        Listener::Tcp(listener)
    };
    let app = Arc::new(App::new(&config, site, onion_host.as_deref()));
    let semaphore = Arc::new(Semaphore::new(config.limits.max_connections));
    let mut jobs = JoinSet::new();
    let mut tick = tokio::time::interval(Duration::from_secs(1));
    println!(
        "Ctrl-C: stop. SIGHUP: reload public files. PID: {}",
        std::process::id()
    );
    let outcome: Result<()> = loop {
        tokio::select! {
            _ = shutdown.recv() => break Ok(()),
            _ = tick.tick(), if tor.is_some() => {
                if let Err(e) = tor.as_mut().unwrap().check_alive() { break Err(e); }
            }
            _ = reload.recv() => {
                let c = config.clone();
                match tokio::task::spawn_blocking(move || Site::load(&c)).await {
                    Ok(Ok(site)) => {
                        println!("Reloaded {} files, {} bytes.", site.assets.len(), site.bytes);
                        *app.site.write().expect("site lock") = Arc::new(site);
                    }
                    Ok(Err(e)) => eprintln!("Reload rejected; previous snapshot stays live: {e:#}"),
                    Err(e) => eprintln!("Reload worker failed; previous snapshot stays live: {e}"),
                }
            }
            Some(result) = jobs.join_next(), if !jobs.is_empty() => {
                if let Err(e) = result { eprintln!("Connection worker stopped: {e}"); }
            }
            accepted = listener.accept() => {
                let stream = match accepted { Ok(s) => s, Err(e) => break Err(e.into()) };
                if let Ok(permit) = semaphore.clone().try_acquire_owned() {
                    let app = app.clone();
                    let limits = config.limits.clone();
                    jobs.spawn(async move {
                        let _permit = permit;
                        match stream {
                            Stream::Tcp(s) => { let _ = s.set_nodelay(true); connection(s, app, limits).await; }
                            #[cfg(unix)]
                            Stream::Unix(s) => connection(s, app, limits).await,
                        }
                    });
                }
                // At capacity, accepted sockets are dropped immediately.
            }
        }
    };
    drop(listener);
    if let Some(child) = &mut tor {
        child.stop().await;
    }
    if tokio::time::timeout(Duration::from_secs(5), async {
        while jobs.join_next().await.is_some() {}
    })
    .await
    .is_err()
    {
        jobs.abort_all();
        while jobs.join_next().await.is_some() {}
    }
    println!("Stopped.");
    outcome
}

async fn connection<T>(stream: T, app: Arc<App>, limits: glowmesh::config::Limits)
where
    T: AsyncRead + AsyncWrite + Unpin + Send + 'static,
{
    let service = service_fn(move |req| {
        let app = app.clone();
        async move { Ok::<_, Infallible>(app.respond(&req)) }
    });
    let mut builder = http1::Builder::new();
    builder
        .timer(TokioTimer::new())
        .header_read_timeout(Duration::from_secs(limits.header_timeout_secs))
        .max_headers(32)
        .max_buf_size(16_384)
        .keep_alive(false);
    // Do not log malformed requests or peer addresses: hostile input stays out
    // of logs, and no per-visitor state survives the connection.
    let _ = tokio::time::timeout(
        Duration::from_secs(limits.connection_timeout_secs),
        builder.serve_connection(TokioIo::new(stream), service),
    )
    .await;
}
