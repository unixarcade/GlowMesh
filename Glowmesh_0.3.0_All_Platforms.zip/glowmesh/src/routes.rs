//! Independent listeners: an overlay failure leaves the local route alive.
use crate::platform::{self, Stream};
use crate::{config::Config, http::App, onion::OnionProcess, signed::Snapshot, state::State};
use anyhow::{Context, Result};
use hyper::{server::conn::http1, service::service_fn};
use hyper_util::rt::{TokioIo, TokioTimer};
use std::{
    convert::Infallible,
    sync::{Arc, RwLock},
    time::Duration,
};
use tokio::{
    io::{AsyncRead, AsyncWrite},
    net::TcpListener,
    sync::{oneshot, Semaphore},
    task::{JoinHandle, JoinSet},
};
pub struct Route {
    pub app: Arc<App>,
    pub address: String,
    pub failure: Arc<RwLock<Option<String>>>,
    stop: Option<oneshot::Sender<()>>,
    task: JoinHandle<()>,
}
impl Route {
    pub async fn tcp(mut config: Config, snapshot: &Snapshot) -> Result<Self> {
        let listener = TcpListener::bind(config.server.bind)
            .await
            .context("This address is unavailable or already in use")?;
        config.server.bind = listener.local_addr()?;
        let address = format!("http://{}/", config.server.bind);
        let app = Arc::new(App::new(&config, snapshot.web_site()?, None));
        let failure = Arc::new(RwLock::new(None));
        let (stop, mut stopped) = oneshot::channel();
        let a = app.clone();
        let f = failure.clone();
        let task = tokio::spawn(async move {
            let permits = Arc::new(Semaphore::new(config.limits.max_connections));
            let mut jobs = JoinSet::new();
            loop {
                tokio::select! {
                    _=&mut stopped=>break,Some(_)=jobs.join_next(),if !jobs.is_empty()=>{},
                    r=listener.accept()=>match r{Ok((stream,_))=>if let Ok(p)=permits.clone().try_acquire_owned(){let a=a.clone();let t=config.limits.connection_timeout_secs;let h=config.limits.header_timeout_secs;jobs.spawn(async move{let _p=p;connection(stream,a,t,h).await;});},Err(e)=>{*f.write().unwrap()=Some(e.to_string());break;}}
                }
            }
            jobs.abort_all();
            while jobs.join_next().await.is_some() {}
        });
        Ok(Self {
            app,
            address,
            failure,
            stop: Some(stop),
            task,
        })
    }
    pub async fn onion(config: &Config, state: &State, snapshot: &Snapshot) -> Result<Self> {
        let (listener, target) = platform::onion_listener(state).await?;
        let mut tor = OnionProcess::start_target(config, state, &target)?;
        let host = match tor.wait_for_address(config).await {
            Ok(h) => h,
            Err(e) => {
                tor.stop().await;
                return Err(e);
            }
        };
        let address = format!("http://{host}/");
        let app = Arc::new(App::new(config, snapshot.web_site()?, Some(&host)));
        let failure = Arc::new(RwLock::new(None));
        let (stop, mut stopped) = oneshot::channel();
        let a = app.clone();
        let f = failure.clone();
        let config = config.clone();
        let task = tokio::spawn(async move {
            let permits = Arc::new(Semaphore::new(config.limits.max_connections));
            let mut jobs = JoinSet::new();
            let mut tick = tokio::time::interval(Duration::from_secs(1));
            loop {
                tokio::select! {
                    _=&mut stopped=>break,_=tick.tick()=>if let Err(e)=tor.check_alive(){*f.write().unwrap()=Some(e.to_string());break;},Some(_)=jobs.join_next(),if !jobs.is_empty()=>{},
                    r=listener.accept()=>match r{Ok(stream)=>if let Ok(p)=permits.clone().try_acquire_owned(){let a=a.clone();let t=config.limits.connection_timeout_secs;let h=config.limits.header_timeout_secs;jobs.spawn(async move{let _p=p;match stream {Stream::Tcp(s)=>connection(s,a,t,h).await, #[cfg(unix)] Stream::Unix(s)=>connection(s,a,t,h).await}});},Err(e)=>{*f.write().unwrap()=Some(e.to_string());break;}}
                }
            }
            jobs.abort_all();
            while jobs.join_next().await.is_some() {}
            tor.stop().await;
        });
        Ok(Self {
            app,
            address,
            failure,
            stop: Some(stop),
            task,
        })
    }
    pub fn update(&self, snapshot: &Snapshot) -> Result<()> {
        *self.app.site.write().unwrap() = Arc::new(snapshot.web_site()?);
        Ok(())
    }
    pub async fn stop(mut self) {
        if let Some(s) = self.stop.take() {
            let _ = s.send(());
        }
        let _ = (&mut self.task).await;
    }
    pub fn alive(&self) -> bool {
        !self.task.is_finished()
    }
}
impl Drop for Route {
    fn drop(&mut self) {
        if let Some(s) = self.stop.take() {
            let _ = s.send(());
        }
    }
}
async fn connection<S: AsyncRead + AsyncWrite + Unpin + Send + 'static>(
    stream: S,
    app: Arc<App>,
    timeout: u64,
    header_timeout: u64,
) {
    let service = service_fn(move |req| {
        let a = app.clone();
        async move { Ok::<_, Infallible>(a.respond(&req)) }
    });
    let _ = tokio::time::timeout(
        Duration::from_secs(timeout),
        http1::Builder::new()
            .timer(TokioTimer::new())
            .header_read_timeout(Duration::from_secs(header_timeout))
            .max_headers(32)
            .max_buf_size(16 * 1024)
            .keep_alive(false)
            .serve_connection(TokioIo::new(stream), service),
    )
    .await;
}
