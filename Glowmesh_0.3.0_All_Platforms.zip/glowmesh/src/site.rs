use crate::config::Config;
use anyhow::{bail, ensure, Context, Result};
use bytes::Bytes;
use cap_std::{
    ambient_authority,
    fs::{Dir, OpenOptions},
};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::Read,
    path::Path,
};

#[derive(Debug, Clone)]
pub struct Asset {
    pub bytes: Bytes,
    pub mime: String,
    pub etag: String,
}

#[derive(Debug, Clone)]
pub struct Site {
    pub assets: BTreeMap<String, Asset>,
    pub directories: BTreeSet<String>,
    pub bytes: usize,
}

impl Site {
    pub fn load(config: &Config) -> Result<Self> {
        let root = fs::canonicalize(&config.server.root)
            .context("Site folder is missing. Run `glowmesh init` first.")?;
        ensure!(root.is_dir(), "Site root must be a directory");
        let dir = Dir::open_ambient_dir(&root, ambient_authority())?;
        let mut site = Self {
            assets: BTreeMap::new(),
            directories: BTreeSet::new(),
            bytes: 0,
        };
        let mut scanned = 0usize;
        site.walk(&dir, "", 0, &mut scanned, config)?;
        ensure!(
            site.assets.contains_key("/index.html"),
            "Site needs public/index.html"
        );
        Ok(site)
    }

    fn walk(
        &mut self,
        dir: &Dir,
        prefix: &str,
        depth: usize,
        scanned: &mut usize,
        config: &Config,
    ) -> Result<()> {
        ensure!(depth <= 32, "Site directories exceed 32 levels");
        for entry in dir.entries()? {
            let entry = entry?;
            *scanned += 1;
            ensure!(
                *scanned <= config.limits.max_files * 4,
                "Too many directory entries"
            );
            let name = entry
                .file_name()
                .into_string()
                .map_err(|_| anyhow::anyhow!("Site filenames must be UTF-8"))?;
            if !public_component(&name) {
                continue;
            }
            let path = format!("{prefix}/{name}");
            ensure!(path.len() <= 4096, "Site path exceeds 4096 bytes");
            let kind = entry.file_type()?;
            ensure!(!kind.is_symlink(), "Remove the symlink from public: {path}");
            if kind.is_dir() {
                self.directories.insert(path.clone());
                self.walk(&dir.open_dir(&name)?, &path, depth + 1, scanned, config)?;
            } else if kind.is_file() {
                ensure!(
                    self.assets.len() < config.limits.max_files,
                    "Too many public files"
                );
                // Capability-relative opening confines resolution to this directory,
                // including a symlink replacement between enumeration and opening.
                let mut options = OpenOptions::new();
                options.read(true);
                crate::platform::no_follow(&mut options);
                let file = dir.open_with(&name, &options)?;
                let meta = file.metadata()?;
                ensure!(
                    crate::platform::regular_file(&meta),
                    "Not a regular file: {path}"
                );
                let limit = config.limits.max_file_mib * 1024 * 1024;
                ensure!(
                    meta.len() <= limit as u64,
                    "File exceeds max_file_mib: {path}"
                );
                let remaining = config.limits.max_site_mib * 1024 * 1024 - self.bytes;
                let read_limit = limit.min(remaining);
                ensure!(meta.len() <= read_limit as u64, "Site exceeds max_site_mib");
                let mut data = Vec::new();
                file.take((read_limit + 1) as u64).read_to_end(&mut data)?;
                ensure!(
                    data.len() <= read_limit,
                    "File or site grew beyond its size limit: {path}"
                );
                let etag = format!("\"{:x}\"", Sha256::digest(&data));
                let mime = mime_guess::from_path(&name)
                    .first_or_octet_stream()
                    .to_string();
                self.bytes += data.len();
                self.assets.insert(
                    path,
                    Asset {
                        bytes: Bytes::from(data),
                        mime,
                        etag,
                    },
                );
            } else {
                bail!("Only regular files and directories are allowed in public: {path}");
            }
        }
        Ok(())
    }

    /// Export the exact reviewed snapshot, not an unfiltered copy of public/.
    pub fn export(&self, destination: &Path) -> Result<()> {
        fs::create_dir(destination)
            .context("Export destination must be new, with an existing parent")?;
        for (path, asset) in &self.assets {
            let target = destination.join(path.trim_start_matches('/'));
            if let Some(parent) = target.parent() {
                fs::create_dir_all(parent)?;
            }
            fs::write(target, &asset.bytes)?;
        }
        Ok(())
    }
}

pub fn public_component(name: &str) -> bool {
    // Keep snapshots portable: Windows device names and filesystem syntax are
    // never valid content paths, even on a Unix publisher.
    let stem = name.split('.').next().unwrap_or("").to_ascii_uppercase();
    if matches!(
        stem.as_str(),
        "CON" | "PRN" | "AUX" | "NUL" | "CONIN$" | "CONOUT$"
    ) || ["COM", "LPT"].iter().any(|p| {
        stem.strip_prefix(p).is_some_and(|n| {
            matches!(
                n,
                "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "¹" | "²" | "³"
            )
        })
    }) {
        return false;
    }
    !name.is_empty()
        && !name.starts_with('.')
        && !name.ends_with('~')
        && !name.ends_with('.')
        && !name.ends_with(' ')
        && !name.chars().any(|c| {
            c.is_control() || matches!(c, '\\' | ':' | '%' | '?' | '#' | '*' | '<' | '>' | '"')
        })
}

/// Decode once. Reject traversal, encoded separators, ambiguous encodings,
/// dotfiles and platform-specific path syntax before touching the asset map.
pub fn request_path(raw: &str) -> Option<String> {
    if !raw.starts_with('/') || raw.len() > 4096 {
        return None;
    }
    let mut out = Vec::with_capacity(raw.len());
    let b = raw.as_bytes();
    let mut i = 0;
    while i < b.len() {
        if b[i] == b'%' {
            let hi = (*b.get(i + 1)? as char).to_digit(16)?;
            let lo = (*b.get(i + 2)? as char).to_digit(16)?;
            let decoded = (hi * 16 + lo) as u8;
            if matches!(decoded, b'/' | b'\\' | b'%') {
                return None;
            }
            out.push(decoded);
            i += 3;
        } else {
            out.push(b[i]);
            i += 1;
        }
    }
    let path = String::from_utf8(out).ok()?;
    if path == "/" {
        return Some(path);
    }
    let trimmed = path
        .strip_prefix('/')?
        .strip_suffix('/')
        .unwrap_or(&path[1..]);
    if !trimmed.split('/').all(public_component) {
        return None;
    }
    Some(path)
}

/// Single byte range only. Multi-range requests are rejected to bound work.
pub fn byte_range(value: &str, length: usize) -> Option<(usize, usize)> {
    if length == 0 {
        return None;
    }
    let value = value.strip_prefix("bytes=")?;
    let (left, right) = value.split_once('-')?;
    if value.contains(',') {
        return None;
    }
    let parse = |s: &str| -> Option<usize> {
        if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) {
            return None;
        }
        s.parse().ok()
    };
    if left.is_empty() {
        let suffix = parse(right)?;
        if suffix == 0 {
            return None;
        }
        Some((length.saturating_sub(suffix), length - 1))
    } else {
        let start = parse(left)?;
        let end = if right.is_empty() {
            length - 1
        } else {
            parse(right)?.min(length - 1)
        };
        if start >= length || start > end {
            return None;
        }
        Some((start, end))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn traversal_and_ambiguity() {
        for path in [
            "/../secret",
            "/%2e%2e/secret",
            "/.env",
            "/a/.git/config",
            "/a%2fb",
            "/%252e%252e/x",
            "/a\\b",
            "/%00",
            "/a//b",
            "//evil.test",
            "/%ff",
            "/bad%",
            "/a:stream",
            "/./index.html",
            "/x~",
        ] {
            assert_eq!(request_path(path), None, "{path}");
        }
        assert_eq!(
            request_path("/hello%20world.html").as_deref(),
            Some("/hello world.html")
        );
        assert_eq!(request_path("/%E2%98%80/").as_deref(), Some("/☀/"));
    }
    #[test]
    fn ranges() {
        assert_eq!(byte_range("bytes=2-4", 10), Some((2, 4)));
        assert_eq!(byte_range("bytes=8-999", 10), Some((8, 9)));
        assert_eq!(byte_range("bytes=-3", 10), Some((7, 9)));
        assert_eq!(byte_range("bytes=7-", 10), Some((7, 9)));
        for r in [
            "bytes=11-",
            "bytes=4-2",
            "bytes=-0",
            "bytes=0-1,3-4",
            "bytes=+1-2",
            "bytes=-",
            "cats=0-1",
        ] {
            assert_eq!(byte_range(r, 10), None, "{r}");
        }
        assert_eq!(byte_range("bytes=0-", 0), None);
    }
    #[test]
    fn hidden_files_and_symlink_escape() {
        let t = tempfile::tempdir().unwrap();
        let mut c = Config::default();
        c.server.root = t.path().to_owned();
        fs::write(t.path().join("index.html"), "hello").unwrap();
        fs::write(t.path().join(".env"), "SECRET").unwrap();
        assert_eq!(Site::load(&c).unwrap().assets.len(), 1);
        #[cfg(unix)]
        {
            std::os::unix::fs::symlink("/etc/passwd", t.path().join("leak.txt")).unwrap();
            assert!(Site::load(&c).is_err());
        }
    }
    #[test]
    fn limits_are_enforced() {
        let t = tempfile::tempdir().unwrap();
        let mut c = Config::default();
        c.server.root = t.path().to_owned();
        c.limits.max_file_mib = 1;
        fs::write(t.path().join("index.html"), vec![0; 1024 * 1024 + 1]).unwrap();
        assert!(Site::load(&c).is_err());
    }
}
