use crate::config::Config;
use anyhow::{ensure, Context, Result};
use fs2::FileExt;
use std::{
    fs::{self, File},
    io::Write,
    path::{Path, PathBuf},
};

#[cfg(unix)]
use std::fs::OpenOptions;
#[cfg(unix)]
use std::os::unix::fs::{DirBuilderExt, FileTypeExt, MetadataExt, OpenOptionsExt, PermissionsExt};
#[cfg(windows)]
#[path = "windows_state.rs"]
mod windows_state;
#[cfg(windows)]
pub use windows_state::{private_dir, private_file};

pub struct State {
    pub path: PathBuf,
    _lock: File,
}

impl State {
    pub fn acquire(config: &Config) -> Result<Self> {
        private_dir(&config.server.state_dir)?;
        let path = fs::canonicalize(&config.server.state_dir)?;
        let root = fs::canonicalize(&config.server.root)?;
        ensure!(
            !path.starts_with(&root) && !root.starts_with(&path),
            "State and public folders must be separate, with neither inside the other"
        );
        let lock = private_file(&path.join("server.lock"), false)?;
        FileExt::try_lock_exclusive(&lock)
            .context("This site is already running (state directory is locked)")?;
        write_private(
            &path.join("server.pid"),
            format!("{}\n", std::process::id()).as_bytes(),
        )?;
        Ok(Self { path, _lock: lock })
    }

    #[cfg(unix)]
    pub fn socket_path(&self) -> Result<PathBuf> {
        let path = self.path.join("http.sock");
        ensure!(path.as_os_str().len() <= 100, "State path is too long for a Unix socket. Set state_dir to a short absolute path outside public.");
        if let Ok(meta) = fs::symlink_metadata(&path) {
            ensure!(
                meta.file_type().is_socket(),
                "Refusing to replace non-socket http.sock"
            );
            fs::remove_file(&path)?;
        }
        Ok(path)
    }
}

impl Drop for State {
    fn drop(&mut self) {
        #[cfg(unix)]
        let socket = self.path.join("http.sock");
        #[cfg(unix)]
        if fs::symlink_metadata(&socket).is_ok_and(|m| m.file_type().is_socket()) {
            let _ = fs::remove_file(socket);
        }
        let _ = fs::remove_file(self.path.join("server.pid"));
        // The lock file intentionally stays. Unlinking a locked inode permits
        // two different locks for the same pathname during a restart race.
        // Release explicitly: a concurrently spawned child can briefly inherit
        // the open file description before exec closes its CLOEXEC descriptor.
        let _ = FileExt::unlock(&self._lock);
    }
}

#[cfg(unix)]
pub fn private_dir(path: &Path) -> Result<()> {
    match fs::symlink_metadata(path) {
        Ok(meta) => {
            ensure!(
                meta.is_dir() && !meta.file_type().is_symlink(),
                "Private state must be a real directory: {}",
                path.display()
            );
            ensure!(
                meta.uid() == rustix::process::geteuid().as_raw(),
                "Private state must belong to the current user: {}",
                path.display()
            );
            ensure!(
                meta.mode() & 0o077 == 0,
                "Private directory permissions must be 700: chmod 700 '{}'",
                path.display()
            );
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
            fs::DirBuilder::new()
                .recursive(true)
                .mode(0o700)
                .create(path)?;
        }
        Err(e) => return Err(e.into()),
    }
    Ok(())
}

#[cfg(unix)]
pub fn private_file(path: &Path, truncate: bool) -> Result<File> {
    let file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .mode(0o600)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(path)?;
    let meta = file.metadata()?;
    ensure!(
        meta.is_file() && meta.nlink() == 1 && meta.uid() == rustix::process::geteuid().as_raw(),
        "Private file must be a singly-linked regular file owned by this user"
    );
    file.set_permissions(fs::Permissions::from_mode(0o600))?;
    if truncate {
        file.set_len(0)?;
    }
    Ok(file)
}

pub fn write_private(path: &Path, content: &[u8]) -> Result<()> {
    let mut file = private_file(path, true)?;
    file.write_all(content)?;
    file.sync_all()?;
    Ok(())
}

pub fn running(config: &Config) -> Result<bool> {
    let path = config.server.state_dir.join("server.lock");
    if !path.exists() {
        return Ok(false);
    }
    let file = private_file(&path, false)?;
    match FileExt::try_lock_exclusive(&file) {
        Ok(()) => {
            FileExt::unlock(&file)?;
            Ok(false)
        }
        Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => Ok(true),
        Err(e) => Err(e.into()),
    }
}

pub fn address(config: &Config) -> Result<String> {
    let value = fs::read_to_string(config.server.state_dir.join("onion/hostname"))
        .context("No onion address yet. Start `glowmesh serve --onion` first.")?;
    let host = value.trim();
    let label = host
        .strip_suffix(".onion")
        .context("Invalid onion hostname file")?;
    ensure!(
        label.len() == 56
            && label
                .bytes()
                .all(|b| b.is_ascii_lowercase() || (b'2'..=b'7').contains(&b)),
        "Expected a Tor v3 onion hostname"
    );
    Ok(host.into())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn disjoint_state_and_exclusive_lock() {
        let t = tempfile::tempdir().unwrap();
        let mut c = Config::default();
        c.server.root = t.path().join("public");
        c.server.state_dir = t.path().join("state");
        fs::create_dir(&c.server.root).unwrap();
        let lock = State::acquire(&c).unwrap();
        assert!(running(&c).unwrap());
        assert!(State::acquire(&c).is_err());
        drop(lock);
        assert!(!running(&c).unwrap());
        c.server.state_dir = c.server.root.join("private");
        assert!(State::acquire(&c).is_err());
    }
    #[test]
    #[cfg(unix)]
    fn unsafe_state_permissions_and_links() {
        let t = tempfile::tempdir().unwrap();
        let dir = t.path().join("state");
        fs::create_dir(&dir).unwrap();
        fs::set_permissions(&dir, fs::Permissions::from_mode(0o755)).unwrap();
        assert!(private_dir(&dir).is_err());
        fs::set_permissions(&dir, fs::Permissions::from_mode(0o700)).unwrap();
        private_dir(&dir).unwrap();
        let file = dir.join("bad");
        std::os::unix::fs::symlink("/etc/passwd", &file).unwrap();
        assert!(private_file(&file, true).is_err());
    }
}
