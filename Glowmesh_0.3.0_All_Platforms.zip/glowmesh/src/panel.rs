//! Local management. Public pages and saved previews have separate origins.
use crate::{
    config::{is_yggdrasil, Config},
    peers::{self, Peer},
    routes::Route,
    signed::{self, SignedManifest, Snapshot},
    site::Site,
    state::{self, State},
};
use anyhow::{ensure, Context, Result};
use bytes::Bytes;
use cap_std::{
    ambient_authority,
    fs::{Dir, OpenOptions},
};
use http_body_util::{BodyExt, Full, Limited};
use hyper::{
    body::Incoming, header, server::conn::http1, service::service_fn, Method, Request, Response,
    StatusCode,
};
use hyper_util::rt::{TokioIo, TokioTimer};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{
    collections::BTreeMap,
    convert::Infallible,
    fs,
    io::Write,
    net::{IpAddr, SocketAddr},
    path::Path,
    sync::{Arc, RwLock},
    time::Duration,
};
use subtle::ConstantTimeEq;
use tokio::{
    net::TcpListener,
    sync::{Mutex, Semaphore},
    task::JoinSet,
};
#[derive(Default, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
struct Settings {
    title: String,
    socks: Option<SocketAddr>,
    peers: Vec<Peer>,
    page: Option<PageDraft>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PageDraft {
    heading: String,
    body: String,
}
struct Manager {
    config: Config,
    state: State,
    settings: Settings,
    own: Arc<Snapshot>,
    active: Arc<Snapshot>,
    copies: BTreeMap<String, SignedManifest>,
    routes: BTreeMap<String, Route>,
    preview: Option<Route>,
    pending: Option<Snapshot>,
}
impl Manager {
    async fn new(config: Config) -> Result<Self> {
        let state = State::acquire(&config)?;
        state::private_dir(&state.path.join("copies"))?;
        let path = state.path.join("panel.json");
        let settings: Settings = if path.exists() {
            ensure!(
                fs::metadata(&path)?.len() <= 262_144,
                "Panel settings exceed 256 KiB"
            );
            serde_json::from_slice(&fs::read(path)?)?
        } else {
            Settings {
                title: "My little corner".into(),
                ..Settings::default()
            }
        };
        ensure!(
            settings.peers.len() <= config.max_copies(),
            "Too many saved connections"
        );
        if let Some(s) = settings.socks {
            ensure!(
                s.ip().is_loopback() && s.port() != 0,
                "Tor SOCKS must be local"
            );
        }
        for p in &settings.peers {
            signed::unhex::<32>(&p.publisher)?;
            peers::validate_routes(&p.routes, p.allow_direct)?;
        }
        let key = signed::identity(&state.path.join("publisher.key"))?;
        let path = state.path.join("published.gmb");
        let own = if path.exists() {
            Snapshot::load(&path, &config)?
        } else {
            let s = Snapshot::publish(
                Site::load(&config)?,
                &key,
                settings.title.clone(),
                1,
                &config,
            )?;
            signed::atomic_write(&path, &s.bundle()?)?;
            s
        };
        ensure!(
            own.signed.manifest.publisher == signed::hex(key.verifying_key().as_bytes()),
            "Published site and private signing key do not match"
        );
        let mut copies = BTreeMap::new();
        let mut total = 0;
        for entry in fs::read_dir(state.path.join("copies"))? {
            let entry = entry?;
            let name = entry.file_name().to_string_lossy().into_owned();
            if let Some(id) = name.strip_suffix(".gmb") {
                signed::unhex::<32>(id)?;
                ensure!(
                    entry.file_type()?.is_file(),
                    "Saved copy must be a regular file"
                );
                total += entry.metadata()?.len();
                ensure!(
                    total <= config.copy_mib() * 1024 * 1024 && copies.len() < config.max_copies(),
                    "Saved copies exceed quota"
                );
                let s = Snapshot::load(&entry.path(), &config)?;
                ensure!(
                    s.signed.manifest.publisher == id,
                    "Saved copy identity does not match its filename"
                );
                copies.insert(id.into(), s.signed);
            }
        }
        let own = Arc::new(own);
        let mut local = config.clone();
        local.onion.enabled = false;
        local.server.bind = "127.0.0.1:0".parse()?;
        local.server.allowed_hosts.clear();
        let route = Route::tcp(local, &own).await?;
        let m = Self {
            config,
            state,
            settings,
            own: own.clone(),
            active: own,
            copies,
            routes: BTreeMap::from([("local".into(), route)]),
            preview: None,
            pending: None,
        };
        m.persist()?;
        Ok(m)
    }
    fn persist(&self) -> Result<()> {
        let bytes = serde_json::to_vec_pretty(&self.settings)?;
        ensure!(bytes.len() <= 262_144, "Panel settings exceed 256 KiB");
        signed::atomic_write(&self.state.path.join("panel.json"), &bytes)
    }
    fn copy_path(&self, id: &str) -> Result<std::path::PathBuf> {
        signed::unhex::<32>(id)?;
        Ok(self.state.path.join("copies").join(format!("{id}.gmb")))
    }
    fn snapshot(&self, id: &str) -> Result<Arc<Snapshot>> {
        if id == self.own.signed.manifest.publisher {
            return Ok(self.own.clone());
        }
        ensure!(self.copies.contains_key(id), "Saved site not found");
        Ok(Arc::new(Snapshot::load(
            &self.copy_path(id)?,
            &self.config,
        )?))
    }
    fn activate(&mut self, s: Arc<Snapshot>) -> Result<()> {
        for route in self.routes.values() {
            route.update(&s)?;
        }
        self.active = s;
        Ok(())
    }
    fn save_copy(&mut self, s: Snapshot) -> Result<()> {
        let id = s.signed.manifest.publisher.clone();
        ensure!(id!=self.own.signed.manifest.publisher,"This is your own site. Bundles contain public content only; preserve the original private folder for publishing.");
        if let Some(old) = self.copies.get(&id) {
            old.accepts(&s.signed)?;
        } else {
            ensure!(
                self.copies.len() < self.config.max_copies(),
                "Saved-site limit reached. Remove one before adding another."
            );
        }
        let bytes = s.bundle()?;
        let mut total = bytes.len() as u64;
        for other in self.copies.keys().filter(|k| **k != id) {
            total += fs::metadata(self.copy_path(other)?)?.len();
        }
        ensure!(
            total <= self.config.copy_mib() * 1024 * 1024,
            "Saved copies would exceed this profile's storage quota"
        );
        signed::atomic_write(&self.copy_path(&id)?, &bytes)?;
        self.copies.insert(id.clone(), s.signed.clone());
        if self.active.signed.manifest.publisher == id {
            self.activate(Arc::new(s))?;
        }
        Ok(())
    }
    fn status(&self) -> Value {
        let routes=self.routes.iter().map(|(name,r)|json!({"kind":name,"address":r.address,"running":r.alive(),"error":r.failure.read().unwrap().clone()})).collect::<Vec<_>>();
        let copies=self.copies.iter().map(|(id,s)|json!({"publisher":id,"title":s.manifest.title,"sequence":s.manifest.sequence,"files":s.manifest.files.len(),"bytes":s.manifest.files.iter().map(|f|f.size).sum::<u64>(),"peer":self.settings.peers.iter().find(|p|p.publisher==*id)})).collect::<Vec<_>>();
        let meshes = if_addrs::get_if_addrs()
            .unwrap_or_default()
            .into_iter()
            .filter(|a| is_yggdrasil(a.ip()))
            .map(|a| json!({"name":a.name,"ip":a.ip().to_string()}))
            .collect::<Vec<_>>();
        json!({"low_resource":self.config.low_resource,"platform":std::env::consts::OS,"version":env!("CARGO_PKG_VERSION"),"own":self.own.signed.manifest,"editor":self.settings.page,"active":self.active.signed.manifest,"routes":routes,"copies":copies,"socks":self.settings.socks.map(|v|v.to_string()),"mesh_addresses":meshes,"root":self.config.server.root,"limits":{"file_mib":self.config.limits.max_file_mib,"site_mib":self.config.limits.max_site_mib,"copies":self.config.max_copies(),"copy_mib":self.config.copy_mib()}})
    }
    async fn sync(&mut self, id: &str) -> Result<()> {
        let peer = self
            .settings
            .peers
            .iter()
            .find(|p| p.publisher == id)
            .context("Add a connection address for this saved site first")?
            .clone();
        let outcome = match peers::sync(
            &peer,
            self.copies.get(id),
            self.settings.socks,
            &self.config,
        )
        .await
        {
            Ok(s) => self.save_copy(s),
            Err(e) => Err(e),
        };
        let message = match &outcome {
            Ok(()) => "Verified copy is up to date".into(),
            Err(e) => format!("{e:#}"),
        };
        if let Some(p) = self.settings.peers.iter_mut().find(|p| p.publisher == id) {
            p.last_result = message.chars().take(2000).collect();
        }
        self.persist()?;
        outcome
    }
    async fn action(&mut self, a: Action) -> Result<Value> {
        match a {
            Action::WritePage { heading, body } => {
                ensure!(
                    !heading.trim().is_empty() && heading.len() <= 120 && body.len() <= 20_000,
                    "Use a heading up to 120 bytes and page text up to 20,000 bytes"
                );
                let escape = |s: &str| {
                    s.replace('&', "&amp;")
                        .replace('<', "&lt;")
                        .replace('>', "&gt;")
                        .replace('"', "&quot;")
                };
                let paragraphs = body
                    .split("\n\n")
                    .map(|p| format!("<p class=\"intro\">{}</p>", escape(p).replace('\n', "<br>")))
                    .collect::<String>();
                let html=format!("<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{}</title><link rel=\"stylesheet\" href=\"/style.css\"><main><div class=\"orbit\" aria-hidden=\"true\"><span>✦</span></div><p class=\"eyebrow\">A LITTLE LIGHT OF MY OWN</p><h1>{}</h1>{paragraphs}<footer>MADE WITH GLOWMESH · SHARED WITH THE WORLD.</footer></main></html>",escape(&heading),escape(&heading));
                write_draft(
                    &self.config,
                    "style.css",
                    include_bytes!("../assets/style.css"),
                )?;
                write_draft(&self.config, "index.html", html.as_bytes())?;
                self.settings.page = Some(PageDraft { heading, body });
                self.persist()?;
            }
            Action::Publish { title } => {
                let key = signed::identity(&self.state.path.join("publisher.key"))?;
                let sequence = self
                    .own
                    .signed
                    .manifest
                    .sequence
                    .checked_add(1)
                    .context("Sequence exhausted")?;
                let s = Snapshot::publish(
                    Site::load(&self.config)?,
                    &key,
                    title.clone(),
                    sequence,
                    &self.config,
                )?;
                signed::atomic_write(&self.state.path.join("published.gmb"), &s.bundle()?)?;
                self.own = Arc::new(s);
                self.activate(self.own.clone())?;
                self.settings.title = title;
                self.persist()?;
            }
            Action::Connection {
                kind,
                enabled,
                address,
            } => {
                ensure!(kind == "onion" || kind == "mesh", "Choose Tor or mesh");
                if let Some(r) = self.routes.remove(&kind) {
                    r.stop().await;
                }
                if enabled {
                    let r = if kind == "onion" {
                        Route::onion(&self.config, &self.state, &self.active).await?
                    } else {
                        let ip: IpAddr = address.context("Choose your mesh address")?.parse()?;
                        ensure!(
                            is_yggdrasil(ip),
                            "Choose a Yggdrasil IPv6 address (0200::/7)"
                        );
                        let mut c = self.config.clone();
                        c.onion.enabled = false;
                        c.server.bind = SocketAddr::new(ip, 8080);
                        c.server.allow_network = true;
                        c.server.allowed_hosts.clear();
                        Route::tcp(c, &self.active).await?
                    };
                    self.routes.insert(kind, r);
                }
            }
            Action::Socks { address } => {
                self.settings.socks = if address.trim().is_empty() {
                    None
                } else {
                    let s: SocketAddr = address
                        .parse()
                        .context("Use 127.0.0.1:9050 or your Tor Browser SOCKS port")?;
                    ensure!(
                        s.ip().is_loopback() && s.port() != 0,
                        "SOCKS must be on this computer"
                    );
                    Some(s)
                };
                self.persist()?;
            }
            Action::Inspect { address } => {
                return Ok(
                    json!({"signed":peers::inspect(&address,self.settings.socks,&self.config).await?}),
                )
            }
            Action::Follow {
                publisher,
                routes,
                auto_sync,
                allow_direct,
            } => {
                signed::unhex::<32>(&publisher)?;
                peers::validate_routes(&routes, allow_direct)?;
                ensure!(
                    publisher != self.own.signed.manifest.publisher,
                    "You already own this site"
                );
                ensure!(
                    !auto_sync || !self.config.low_resource,
                    "Use manual updates in low-resource mode"
                );
                let peer = Peer {
                    publisher: publisher.clone(),
                    routes,
                    auto_sync,
                    allow_direct,
                    last_result: String::new(),
                };
                let s = peers::sync(
                    &peer,
                    self.copies.get(&publisher),
                    self.settings.socks,
                    &self.config,
                )
                .await?;
                self.save_copy(s)?;
                self.settings.peers.retain(|p| p.publisher != publisher);
                self.settings.peers.push(peer);
                self.persist()?;
            }
            Action::Sync { publisher } => self.sync(&publisher).await?,
            Action::Auto { publisher, enabled } => {
                ensure!(
                    !enabled || !self.config.low_resource,
                    "Automatic updates are off in low-resource mode. Use Update now."
                );
                self.settings
                    .peers
                    .iter_mut()
                    .find(|p| p.publisher == publisher)
                    .context("Add addresses first")?
                    .auto_sync = enabled;
                self.persist()?;
            }
            Action::Open { publisher } => {
                let s = self.snapshot(&publisher)?;
                if let Some(r) = self.preview.take() {
                    r.stop().await;
                }
                let mut c = self.config.clone();
                c.server.bind = "127.0.0.1:0".parse()?;
                c.server.allowed_hosts.clear();
                let r = Route::tcp(c, &s).await?;
                let address = r.address.clone();
                self.preview = Some(r);
                return Ok(json!({"address":address}));
            }
            Action::Share { publisher } => {
                let s = self.snapshot(&publisher)?;
                self.activate(s)?;
            }
            Action::Remove { publisher } => {
                ensure!(self.copies.contains_key(&publisher), "Saved site not found");
                if self.active.signed.manifest.publisher == publisher {
                    self.activate(self.own.clone())?;
                }
                if let Some(r) = self.preview.take() {
                    r.stop().await;
                }
                fs::remove_file(self.copy_path(&publisher)?)?;
                self.copies.remove(&publisher);
                self.settings.peers.retain(|p| p.publisher != publisher);
                self.persist()?;
            }
            Action::ImportConfirm { publisher } => {
                ensure!(
                    self.pending
                        .as_ref()
                        .is_some_and(|s| s.signed.manifest.publisher == publisher),
                    "Inspect the bundle first and confirm its publisher"
                );
                let s = self.pending.take().unwrap();
                self.save_copy(s)?;
            }
            Action::DeleteFile { path } => {
                let path = clean_path(&path)?;
                ensure!(
                    path != "index.html",
                    "Keep index.html; upload a replacement instead"
                );
                Dir::open_ambient_dir(&self.config.server.root, ambient_authority())?
                    .remove_file(path)?;
            }
        }
        Ok(json!({"ok":true}))
    }
}
#[derive(Deserialize)]
#[serde(tag = "action", rename_all = "snake_case", deny_unknown_fields)]
enum Action {
    WritePage {
        heading: String,
        body: String,
    },
    Publish {
        title: String,
    },
    Connection {
        kind: String,
        enabled: bool,
        address: Option<String>,
    },
    Socks {
        address: String,
    },
    Inspect {
        address: String,
    },
    Follow {
        publisher: String,
        routes: Vec<String>,
        auto_sync: bool,
        allow_direct: bool,
    },
    Sync {
        publisher: String,
    },
    Auto {
        publisher: String,
        enabled: bool,
    },
    Open {
        publisher: String,
    },
    Share {
        publisher: String,
    },
    Remove {
        publisher: String,
    },
    ImportConfirm {
        publisher: String,
    },
    DeleteFile {
        path: String,
    },
}
fn clean_path(path: &str) -> Result<String> {
    ensure!(
        signed::valid_path(&format!("/{path}")),
        "Use a public relative filename without hidden folders or traversal"
    );
    Ok(path.into())
}
fn write_draft(config: &Config, path: &str, data: &[u8]) -> Result<()> {
    let path = clean_path(path)?;
    let current = Site::load(config)?;
    let old = current.assets.get(&format!("/{path}"));
    ensure!(
        data.len() <= config.limits.max_file_mib * 1024 * 1024,
        "File exceeds size limit"
    );
    ensure!(
        (current.bytes - old.map_or(0, |a| a.bytes.len()))
            .checked_add(data.len())
            .is_some_and(|total| total <= config.limits.max_site_mib * 1024 * 1024),
        "Draft exceeds site size limit"
    );
    ensure!(
        old.is_some() || current.assets.len() < config.limits.max_files,
        "Too many files"
    );
    let root = Dir::open_ambient_dir(&config.server.root, ambient_authority())?;
    let p = Path::new(&path);
    let parent = p
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    root.create_dir_all(parent)?;
    let dir = root.open_dir(parent)?;
    let name = p.file_name().unwrap();
    let temp = format!(".upload-{}", signed::random_id()?);
    let result = (|| {
        let mut opts = OpenOptions::new();
        opts.write(true).create_new(true);
        crate::platform::no_follow(&mut opts);
        let mut f = dir.open_with(&temp, &opts)?;
        f.write_all(data)?;
        f.sync_all()?;
        dir.rename(&temp, &dir, name)?;
        Ok(())
    })();
    if result.is_err() {
        let _ = dir.remove_file(temp);
    }
    result
}
type Reply = Response<Full<Bytes>>;
struct Panel {
    manager: Mutex<Manager>,
    view: RwLock<Value>,
    token: String,
    host: String,
    origin: String,
    body_limit: usize,
    mutation: Arc<Semaphore>,
}
fn reply(status: StatusCode, mime: &str, data: impl Into<Bytes>) -> Reply {
    let mut r = Response::new(Full::new(data.into()));
    *r.status_mut() = status;
    r.headers_mut()
        .insert(header::CONTENT_TYPE, mime.parse().unwrap());
    r
}
fn json_reply(v: Value) -> Reply {
    reply(
        StatusCode::OK,
        "application/json",
        serde_json::to_vec(&v).unwrap(),
    )
}
impl Panel {
    async fn handle(self: Arc<Self>, req: Request<Incoming>) -> Reply {
        let mut r = match self.inner(req).await {
            Ok(r) => r,
            Err(e) => reply(
                StatusCode::BAD_REQUEST,
                "application/json",
                serde_json::to_vec(&json!({"error":format!("{e:#}")})).unwrap(),
            ),
        };
        for(k,v)in[("content-security-policy","default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"),("x-frame-options","DENY"),("x-content-type-options","nosniff"),("referrer-policy","no-referrer"),("cache-control","no-store"),("cross-origin-resource-policy","same-origin"),("cross-origin-opener-policy","same-origin"),("permissions-policy","camera=(), microphone=(), geolocation=(), payment=(), usb=()"),("connection","close")]{r.headers_mut().insert(k,v.parse().unwrap());}
        r
    }
    async fn inner(&self, req: Request<Incoming>) -> Result<Reply> {
        if req.headers().get_all(header::HOST).iter().count() != 1
            || req
                .headers()
                .get(header::HOST)
                .is_none_or(|h| h.as_bytes() != self.host.as_bytes())
        {
            return Ok(reply(
                StatusCode::MISDIRECTED_REQUEST,
                "text/plain",
                "Use the printed 127.0.0.1 control-panel address.",
            ));
        }
        ensure!(
            req.uri().scheme().is_none() && req.uri().authority().is_none(),
            "Origin-form request required"
        );
        let path = req.uri().path().to_owned();
        if req.method() == Method::GET {
            match path.as_str() {
                "/" => {
                    return Ok(reply(
                        StatusCode::OK,
                        "text/html; charset=utf-8",
                        include_str!("../assets/panel.html"),
                    ))
                }
                "/panel.css" => {
                    return Ok(reply(
                        StatusCode::OK,
                        "text/css",
                        include_str!("../assets/panel.css"),
                    ))
                }
                "/panel.js" => {
                    return Ok(reply(
                        StatusCode::OK,
                        "text/javascript",
                        include_str!("../assets/panel.js"),
                    ))
                }
                _ => {}
            }
        }
        let supplied = req
            .headers()
            .get(header::AUTHORIZATION)
            .and_then(|h| h.to_str().ok())
            .and_then(|h| h.strip_prefix("Bearer "))
            .unwrap_or("");
        if !bool::from(supplied.as_bytes().ct_eq(self.token.as_bytes())) {
            return Ok(reply(
                StatusCode::UNAUTHORIZED,
                "application/json",
                r#"{"error":"Open the private control-panel link printed by Glowmesh."}"#,
            ));
        }
        if let Some(o) = req.headers().get(header::ORIGIN) {
            ensure!(
                o.as_bytes() == self.origin.as_bytes(),
                "Request came from another website"
            );
        }
        if req.method() == Method::GET {
            if path == "/api/status" {
                if let Ok(m) = self.manager.try_lock() {
                    *self.view.write().unwrap() = m.status();
                }
                let mut v = self.view.read().unwrap().clone();
                v["busy"] = json!(self.mutation.available_permits() == 0);
                return Ok(json_reply(v));
            }
            let m = self.manager.lock().await;
            return match path.as_str() {
                "/api/files" => {
                    let s = Site::load(&m.config)?;
                    Ok(json_reply(
                        json!({"files":s.assets.iter().map(|(p,a)|json!({"path":p.trim_start_matches('/'),"bytes":a.bytes.len()})).collect::<Vec<_>>()}),
                    ))
                }
                "/api/export" => {
                    let s = m.snapshot(&query(&req, "publisher")?)?;
                    let mut r = reply(StatusCode::OK, "application/octet-stream", s.bundle()?);
                    r.headers_mut().insert(
                        header::CONTENT_DISPOSITION,
                        "attachment; filename=site.gmb".parse()?,
                    );
                    Ok(r)
                }
                _ => Ok(reply(StatusCode::NOT_FOUND, "text/plain", "Not found")),
            };
        }
        ensure!(req.method() == Method::POST, "Use GET or POST");
        ensure!(
            req.headers()
                .get(header::ORIGIN)
                .is_some_and(|o| o.as_bytes() == self.origin.as_bytes()),
            "A same-origin request is required"
        );
        let Ok(_permit) = self.mutation.clone().try_acquire_owned() else {
            return Ok(reply(
                StatusCode::CONFLICT,
                "application/json",
                r#"{"error":"Another change is still running. Please wait."}"#,
            ));
        };
        let limit = if path == "/api/import" {
            self.body_limit
        } else if path == "/api/file" {
            self.manager.lock().await.config.limits.max_file_mib * 1024 * 1024
        } else {
            65_536
        };
        let file_path = if path == "/api/file" {
            Some(query(&req, "path")?)
        } else {
            None
        };
        let body = tokio::time::timeout(
            Duration::from_secs(120),
            Limited::new(req.into_body(), limit).collect(),
        )
        .await
        .context("Upload timed out")?
        .map_err(|e| anyhow::anyhow!("Upload failed or exceeded its limit: {e}"))?
        .to_bytes();
        let mut m = self.manager.lock().await;
        let result = match path.as_str() {
            "/api/action" => m
                .action(serde_json::from_slice(&body)?)
                .await
                .map(json_reply),
            "/api/file" => {
                write_draft(&m.config, file_path.as_deref().unwrap(), &body)?;
                Ok(json_reply(json!({"ok":true})))
            }
            "/api/import" => {
                let s = Snapshot::from_bundle(body, &m.config)?;
                if let Some(old) = m.copies.get(&s.signed.manifest.publisher) {
                    old.accepts(&s.signed)?;
                }
                let v = json!({"signed":s.signed});
                m.pending = Some(s);
                Ok(json_reply(v))
            }
            _ => Ok(reply(StatusCode::NOT_FOUND, "text/plain", "Not found")),
        };
        *self.view.write().unwrap() = m.status();
        result
    }
}
fn query(req: &Request<Incoming>, name: &str) -> Result<String> {
    ensure!(
        req.uri().to_string().len() <= 8192,
        "Request address too long"
    );
    reqwest::Url::parse(&format!("http://localhost{}", req.uri()))?
        .query_pairs()
        .find(|(k, _)| k == name)
        .map(|(_, v)| v.into_owned())
        .context("Missing request parameter")
}
pub async fn run(config: Config, port: u16, no_browser: bool) -> Result<()> {
    let listener = TcpListener::bind((std::net::Ipv4Addr::LOCALHOST, port))
        .await
        .context("Control-panel port is busy. Choose another with --port or use --port 0")?;
    let host = listener.local_addr()?.to_string();
    let origin = format!("http://{host}");
    let token = signed::random_id()?;
    let url = format!("{origin}/#{token}");
    let body_limit = config.limits.max_site_mib * 1024 * 1024 + signed::MANIFEST_LIMIT + 12;
    let manager = Manager::new(config).await?;
    let view = RwLock::new(manager.status());
    let panel = Arc::new(Panel {
        manager: Mutex::new(manager),
        view,
        token,
        host,
        origin,
        body_limit,
        mutation: Arc::new(Semaphore::new(1)),
    });
    println!("Glowmesh control panel (private link): {url}");
    println!("Keep this window running. Ctrl-C stops the app and every connection.");
    if !no_browser {
        open_browser(&url);
    }
    let mut shutdown = crate::platform::Shutdown::new()?;
    let admin_connections = if panel.manager.lock().await.config.low_resource {
        4
    } else {
        16
    };
    let permits = Arc::new(Semaphore::new(admin_connections));
    let mut jobs = JoinSet::new();
    let auto = panel.clone();
    let sync_job = tokio::spawn(async move {
        if auto.manager.lock().await.config.low_resource {
            return;
        }
        let mut tick = tokio::time::interval(Duration::from_secs(60));
        tick.tick().await;
        loop {
            tick.tick().await;
            let Ok(_permit) = auto.mutation.clone().try_acquire_owned() else {
                continue;
            };
            let mut m = auto.manager.lock().await;
            let ids = m
                .settings
                .peers
                .iter()
                .filter(|p| p.auto_sync)
                .map(|p| p.publisher.clone())
                .collect::<Vec<_>>();
            for id in ids {
                let _ = m.sync(&id).await;
                *auto.view.write().unwrap() = m.status();
            }
        }
    });
    loop {
        tokio::select! {_=shutdown.recv()=>break,Some(_)=jobs.join_next(),if !jobs.is_empty()=>{},accepted=listener.accept()=>{let(stream,_)=accepted?;if let Ok(permit)=permits.clone().try_acquire_owned(){let p=panel.clone();jobs.spawn(async move{let _permit=permit;let service=service_fn(move|req|{let p=p.clone();async move{Ok::<_,Infallible>(p.handle(req).await)}});let _=tokio::time::timeout(Duration::from_secs(850),http1::Builder::new().timer(TokioTimer::new()).header_read_timeout(Duration::from_secs(10)).max_headers(24).max_buf_size(16*1024).keep_alive(false).serve_connection(TokioIo::new(stream),service)).await;});}}}
    }
    sync_job.abort();
    let _ = sync_job.await;
    jobs.abort_all();
    while jobs.join_next().await.is_some() {}
    let mut m = panel.manager.lock().await;
    for (_, r) in std::mem::take(&mut m.routes) {
        r.stop().await;
    }
    if let Some(r) = m.preview.take() {
        r.stop().await;
    }
    Ok(())
}
fn open_browser(url: &str) {
    let url = url.to_owned();
    tokio::spawn(async move {
        #[cfg(windows)]
        let mut command = {
            let mut c = tokio::process::Command::new(crate::platform::windows_system_program(
                "rundll32.exe",
            ));
            c.arg("url.dll,FileProtocolHandler");
            c
        };
        #[cfg(not(windows))]
        let mut command = tokio::process::Command::new(if cfg!(target_os = "macos") {
            "open"
        } else {
            "xdg-open"
        });
        if let Ok(mut child) = command
            .arg(url)
            .stdin(std::process::Stdio::null())
            .stdout(std::process::Stdio::null())
            .stderr(std::process::Stdio::null())
            .kill_on_drop(true)
            .spawn()
        {
            let _ = tokio::time::timeout(Duration::from_secs(15), child.wait()).await;
        }
    });
}
