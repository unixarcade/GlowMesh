use crate::{
    config::Config,
    signed::{SignedManifest, Snapshot, MANIFEST_LIMIT},
};
use anyhow::{bail, ensure, Context, Result};
use bytes::Bytes;
use reqwest::{Client, Url};
use serde::{Deserialize, Serialize};
use std::{
    net::{IpAddr, SocketAddr},
    time::Duration,
};
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Peer {
    pub publisher: String,
    pub routes: Vec<String>,
    pub auto_sync: bool,
    pub allow_direct: bool,
    #[serde(default)]
    pub last_result: String,
}
pub fn route(value: &str) -> Result<Url> {
    ensure!(value.len() <= 2048, "Address is too long");
    let u = Url::parse(value.trim()).context("Use a full http:// or https:// site address")?;
    ensure!(
        matches!(u.scheme(), "http" | "https") && u.host_str().is_some(),
        "Use an HTTP or HTTPS address"
    );
    ensure!(
        u.username().is_empty()
            && u.password().is_none()
            && u.query().is_none()
            && u.fragment().is_none()
            && u.path() == "/",
        "Use the site's home address, without login, path, query, or fragment"
    );
    let host = u.host_str().unwrap();
    ensure!(
        !host.ends_with('.'),
        "Use the site address without a trailing dot"
    );
    if let Some(label) = host.strip_suffix(".onion") {
        ensure!(
            label.len() == 56
                && label
                    .bytes()
                    .all(|b| b.is_ascii_lowercase() || (b'2'..=b'7').contains(&b)),
            "Use a Tor v3 onion address"
        );
    }
    if let Ok(ip) = host.trim_matches(['[', ']']).parse::<IpAddr>() {
        ensure!(
            !ip.is_unspecified() && !ip.is_multicast(),
            "Use a specific host address"
        );
    }
    Ok(u)
}
pub fn validate_routes(routes: &[String], allow_direct: bool) -> Result<()> {
    ensure!(
        !routes.is_empty() && routes.len() <= 6,
        "Add between one and six addresses"
    );
    let urls = routes
        .iter()
        .map(|r| route(r))
        .collect::<Result<Vec<_>>>()?;
    let onion = urls
        .iter()
        .any(|u| u.host_str().unwrap().ends_with(".onion"));
    let direct = urls
        .iter()
        .any(|u| !u.host_str().unwrap().ends_with(".onion"));
    ensure!(
        !(onion && direct) || allow_direct,
        "Mixed Tor and direct routes require explicit direct-connection permission"
    );
    Ok(())
}
fn client(url: &Url, socks: Option<SocketAddr>) -> Result<Client> {
    let mut b = Client::builder()
        .no_proxy()
        .redirect(reqwest::redirect::Policy::none())
        .connect_timeout(Duration::from_secs(12))
        .timeout(Duration::from_secs(45));
    if url.host_str().unwrap().ends_with(".onion") {
        let s=socks.context("Set a local Tor SOCKS connection in Connections: usually 127.0.0.1:9050 or Tor Browser's 127.0.0.1:9150")?;
        ensure!(
            s.ip().is_loopback() && s.port() != 0,
            "Tor SOCKS must be on this computer"
        );
        b = b.proxy(reqwest::Proxy::all(format!("socks5h://{s}"))?);
    }
    Ok(b.build()?)
}
async fn fetch(c: &Client, url: Url, limit: usize) -> Result<Bytes> {
    // A fast local replica can exhaust the publisher's shared request budget.
    // Respect short rate-limit pauses instead of discarding a healthy transfer.
    // Both retries and waits remain bounded by the route's overall deadline.
    let mut attempts = 0;
    let mut r = loop {
        let response = c
            .get(url.clone())
            .header("Accept-Encoding", "identity")
            .send()
            .await?;
        if response.status() != reqwest::StatusCode::TOO_MANY_REQUESTS || attempts == 3 {
            break response;
        }
        let pause = response
            .headers()
            .get("retry-after")
            .and_then(|h| h.to_str().ok())
            .and_then(|s| s.parse::<u64>().ok())
            .unwrap_or(1)
            .clamp(1, 5);
        drop(response);
        attempts += 1;
        tokio::time::sleep(Duration::from_secs(pause)).await;
    };
    ensure!(
        r.status() == reqwest::StatusCode::OK,
        "Site returned HTTP {}",
        r.status()
    );
    ensure!(
        r.content_length().is_none_or(|n| n <= limit as u64),
        "Download exceeds size limit"
    );
    ensure!(
        r.headers()
            .get("content-encoding")
            .is_none_or(|v| v == "identity"),
        "Compressed transfers are not accepted"
    );
    let mut out = Vec::new();
    while let Some(chunk) = r.chunk().await? {
        ensure!(
            chunk.len() <= limit.saturating_sub(out.len()),
            "Download exceeds size limit"
        );
        out.extend(&chunk);
    }
    Ok(out.into())
}
pub async fn inspect(
    address: &str,
    socks: Option<SocketAddr>,
    config: &Config,
) -> Result<SignedManifest> {
    let u = route(address)?;
    let c = client(&u, socks)?;
    SignedManifest::parse(
        &fetch(&c, u.join("__glowmesh/manifest.json")?, MANIFEST_LIMIT).await?,
        config,
    )
}
pub async fn sync(
    peer: &Peer,
    previous: Option<&SignedManifest>,
    socks: Option<SocketAddr>,
    config: &Config,
) -> Result<Snapshot> {
    validate_routes(&peer.routes, peer.allow_direct)?;
    let mut errors = Vec::new();
    for address in &peer.routes {
        let attempt = async {
            let u = route(address)?;
            let c = client(&u, socks)?;
            let s = SignedManifest::parse(
                &fetch(&c, u.join("__glowmesh/manifest.json")?, MANIFEST_LIMIT).await?,
                config,
            )?;
            ensure!(
                s.manifest.publisher == peer.publisher,
                "Publisher key does not match your pinned identity"
            );
            if let Some(old) = previous {
                old.accepts(&s)?;
            }
            let mut content = Vec::new();
            for f in &s.manifest.files {
                content.push(
                    fetch(
                        &c,
                        u.join(&format!("__glowmesh/blob/{}", f.sha256))?,
                        usize::try_from(f.size)?,
                    )
                    .await?,
                );
            }
            Snapshot::assemble(s, content, config)
        };
        match tokio::time::timeout(Duration::from_secs(120), attempt).await {
            Ok(Ok(s)) => return Ok(s),
            Ok(Err(e)) => errors.push(format!("{address}: {e:#}")),
            Err(_) => errors.push(format!("{address}: transfer timed out")),
        }
    }
    bail!(
        "No verified update arrived. Your saved copy stays available. {}",
        errors.join(" | ")
    )
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn routes_do_not_silently_downgrade_tor() {
        let onion = format!("http://{}.onion/", "a".repeat(56));
        assert!(validate_routes(&[onion.clone(), "http://127.0.0.1:8080/".into()], false).is_err());
        assert!(validate_routes(&[onion, "http://127.0.0.1:8080/".into()], true).is_ok());
        for u in [
            "file:///etc/passwd",
            "http://user:pass@site/",
            "http://site/path",
            "http://site/?q=x",
            "http://0.0.0.0/",
            "http://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.onion./",
        ] {
            assert!(route(u).is_err());
        }
    }
}
