//! Windows private-state implementation. No shell scripts or unchecked FFI.
use anyhow::{ensure, Context, Result};
use std::{
    fs::{self, File, OpenOptions},
    os::windows::fs::{MetadataExt, OpenOptionsExt},
    path::Path,
    sync::OnceLock,
};
use windows_permissions::{
    constants::{SeObjectType, SecurityInformation},
    wrappers::{GetSecurityInfo, SetSecurityInfo},
    LocalBox, SecurityDescriptor, Sid,
};

const REPARSE: u32 = 0x400;
const OPEN_REPARSE: u32 = 0x0020_0000;
const BACKUP_SEMANTICS: u32 = 0x0200_0000;
const READ_CONTROL: u32 = 0x0002_0000;
const WRITE_DAC: u32 = 0x0004_0000;

fn current_sid() -> Result<String> {
    static SID: OnceLock<String> = OnceLock::new();
    if let Some(s) = SID.get() {
        return Ok(s.clone());
    }
    let out = std::process::Command::new(crate::platform::windows_system_program("whoami.exe"))
        .args(["/user", "/fo", "csv", "/nh"])
        .output()
        .context("Cannot determine the Windows user SID")?;
    ensure!(
        out.status.success(),
        "Windows could not identify the current user"
    );
    let output = String::from_utf8_lossy(&out.stdout);
    let sid = output
        .split('"')
        .find(|s| {
            s.starts_with("S-1-")
                && s.bytes()
                    .all(|b| b.is_ascii_digit() || b == b'-' || b == b'S')
        })
        .context("Windows user SID was missing")?
        .to_string();
    let _: LocalBox<Sid> = sid.parse()?;
    let _ = SID.set(sid.clone());
    Ok(sid)
}
fn protect(file: &mut File, directory: bool) -> Result<()> {
    let sid = current_sid()?;
    let expected: LocalBox<Sid> = sid.parse()?;
    let existing = GetSecurityInfo(
        file,
        SeObjectType::SE_FILE_OBJECT,
        SecurityInformation::Owner,
    )?;
    ensure!(existing.owner()==Some(&*expected),"Private state must belong to your Windows account. Run Glowmesh as your normal user in a private NTFS folder.");
    let flags = if directory { "OICI" } else { "" };
    let policy: LocalBox<SecurityDescriptor> =
        format!("D:P(A;{flags};FA;;;{sid})(A;{flags};FA;;;SY)").parse()?;
    SetSecurityInfo(
        file,
        SeObjectType::SE_FILE_OBJECT,
        SecurityInformation::Dacl | SecurityInformation::ProtectedDacl,
        None,
        None,
        policy.dacl(),
        None,
    )
    .context("Cannot protect Windows state. Use a private NTFS folder in your user profile.")?;
    Ok(())
}
pub fn private_dir(path: &Path) -> Result<()> {
    if !path.exists() {
        fs::create_dir_all(path)?;
    }
    let meta = fs::symlink_metadata(path)?;
    ensure!(
        meta.is_dir() && meta.file_attributes() & REPARSE == 0,
        "Private state cannot be a junction, symlink or reparse point"
    );
    let mut file = OpenOptions::new()
        .access_mode(READ_CONTROL | WRITE_DAC)
        .custom_flags(OPEN_REPARSE | BACKUP_SEMANTICS)
        .open(path)?;
    ensure!(
        file.metadata()?.file_attributes() & REPARSE == 0,
        "Private state changed into a reparse point"
    );
    protect(&mut file, true)
}
pub fn private_file(path: &Path, truncate: bool) -> Result<File> {
    let mut file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .access_mode(0x8000_0000 | 0x4000_0000 | WRITE_DAC)
        .custom_flags(OPEN_REPARSE)
        .open(path)?;
    let meta = file.metadata()?;
    ensure!(
        meta.is_file()
            && meta.file_attributes() & REPARSE == 0
            && winapi_util::file::information(&file)?.number_of_links() == 1,
        "Private files must be regular files without links or reparse points"
    );
    protect(&mut file, false)?;
    if truncate {
        file.set_len(0)?;
    }
    Ok(file)
}
