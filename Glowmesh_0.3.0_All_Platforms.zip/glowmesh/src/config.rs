use anyhow::{bail, ensure, Context, Result};
use serde::{Deserialize, Serialize};
use std::{
    fs,
    net::{IpAddr, SocketAddr},
    path::{Path, PathBuf},
};

#[derive(Debug, Clone, Default, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct Config {
    #[serde(skip)]
    pub low_resource: bool,
    pub server: Server,
    pub onion: Onion,
    pub limits: Limits,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct Server {
    pub root: PathBuf,
    pub state_dir: PathBuf,
    pub bind: SocketAddr,
    pub allow_network: bool,
    /// Additional exact Host authorities, including port when needed.
    pub allowed_hosts: Vec<String>,
    pub content_security_policy: String,
}

impl Default for Server {
    fn default() -> Self {
        Self {
            root: "public".into(),
            state_dir: ".glowmesh".into(),
            bind: "127.0.0.1:8080".parse().unwrap(),
            allow_network: false,
            allowed_hosts: Vec::new(),
            content_security_policy: "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'".into(),
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct Onion {
    pub enabled: bool,
    pub tor_binary: PathBuf,
    pub startup_timeout_secs: u64,
}

impl Default for Onion {
    fn default() -> Self {
        Self {
            enabled: false,
            tor_binary: "tor".into(),
            startup_timeout_secs: 90,
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct Limits {
    pub max_file_mib: usize,
    pub max_site_mib: usize,
    pub max_files: usize,
    pub max_connections: usize,
    pub requests_per_second: u32,
    pub burst: u32,
    pub header_timeout_secs: u64,
    pub connection_timeout_secs: u64,
}

impl Default for Limits {
    fn default() -> Self {
        Self {
            max_file_mib: 32,
            max_site_mib: 256,
            max_files: 10_000,
            max_connections: 128,
            requests_per_second: 100,
            burst: 200,
            header_timeout_secs: 10,
            connection_timeout_secs: 120,
        }
    }
}

impl Config {
    pub fn apply_low_resource(&mut self) {
        self.low_resource = true;
        self.limits.max_file_mib = self.limits.max_file_mib.min(2);
        self.limits.max_site_mib = self.limits.max_site_mib.min(8);
        self.limits.max_files = self.limits.max_files.min(512);
        self.limits.max_connections = self.limits.max_connections.min(16);
        self.limits.requests_per_second = self.limits.requests_per_second.min(20);
        self.limits.burst = self.limits.burst.min(40);
    }
    pub fn max_copies(&self) -> usize {
        if self.low_resource {
            2
        } else {
            8
        }
    }
    pub fn copy_mib(&self) -> u64 {
        if self.low_resource {
            32
        } else {
            512
        }
    }

    pub fn load(path: &Path) -> Result<Self> {
        ensure!(
            fs::metadata(path)
                .with_context(|| format!(
                    "Cannot read {}. Run `glowmesh init` first.",
                    path.display()
                ))?
                .len()
                <= 65_536,
            "Configuration exceeds 64 KiB"
        );
        let mut config: Self = toml::from_str(&fs::read_to_string(path)?)
            .context("Invalid configuration (unknown fields are rejected)")?;
        let base = fs::canonicalize(path)?
            .parent()
            .context("Configuration has no parent")?
            .to_owned();
        config.server.root = base.join(&config.server.root);
        config.server.state_dir = base.join(&config.server.state_dir);
        if config.onion.tor_binary.components().count() > 1 {
            config.onion.tor_binary = base.join(&config.onion.tor_binary);
        }
        config.validate()?;
        Ok(config)
    }

    pub fn validate(&self) -> Result<()> {
        let l = &self.limits;
        ensure!(
            (1..=2048).contains(&l.max_file_mib),
            "max_file_mib must be 1..2048"
        );
        ensure!(
            (1..=4096).contains(&l.max_site_mib) && l.max_site_mib >= l.max_file_mib,
            "max_site_mib must be max_file_mib..4096"
        );
        ensure!(
            l.max_site_mib
                .checked_mul(1024 * 1024)
                .and_then(|n| n.checked_add(crate::signed::MANIFEST_LIMIT + 13))
                .is_some(),
            "max_site_mib is too large for this CPU architecture"
        );
        ensure!(
            (1..=100_000).contains(&l.max_files),
            "max_files must be 1..100000"
        );
        ensure!(
            (1..=4096).contains(&l.max_connections),
            "max_connections must be 1..4096"
        );
        ensure!(
            (1..=100_000).contains(&l.requests_per_second) && (1..=100_000).contains(&l.burst),
            "Rate and burst must be 1..100000"
        );
        ensure!(
            (1..=120).contains(&l.header_timeout_secs),
            "header_timeout_secs must be 1..120"
        );
        ensure!(
            (1..=3600).contains(&l.connection_timeout_secs),
            "connection_timeout_secs must be 1..3600"
        );
        ensure!(
            (1..=600).contains(&self.onion.startup_timeout_secs),
            "startup_timeout_secs must be 1..600"
        );
        ensure!(self.server.bind.port() != 0, "Choose a fixed nonzero port");
        ensure!(
            self.server.allowed_hosts.len() <= 64,
            "At most 64 allowed_hosts"
        );
        for host in &self.server.allowed_hosts {
            ensure!(
                !host.is_empty()
                    && host.len() <= 255
                    && host.is_ascii()
                    && !host.contains('@')
                    && !host.contains('/')
                    && !host.contains('*'),
                "allowed_hosts requires exact host[:port] authorities"
            );
            host.parse::<hyper::http::uri::Authority>()
                .context("Invalid allowed_hosts authority")?;
        }
        ensure!(
            !self.server.content_security_policy.is_empty()
                && self.server.content_security_policy.len() <= 4096,
            "Provide a Content-Security-Policy of 1..4096 bytes"
        );
        self.server
            .content_security_policy
            .parse::<hyper::header::HeaderValue>()
            .context("Invalid Content-Security-Policy")?;
        Ok(())
    }

    pub fn validate_listener(&self) -> Result<()> {
        if self.onion.enabled {
            return Ok(());
        }
        let ip = self.server.bind.ip();
        ensure!(
            !ip.is_unspecified() && !ip.is_multicast(),
            "Bind to one explicit interface address; wildcard/multicast binding is disabled"
        );
        if !ip.is_loopback() && !self.server.allow_network {
            bail!("Network binding requires allow_network = true, or use `serve --mesh YOUR_YGGDRASIL_IPV6`");
        }
        Ok(())
    }
}

pub fn is_yggdrasil(ip: IpAddr) -> bool {
    matches!(ip, IpAddr::V6(v6) if (v6.segments()[0] & 0xfe00) == 0x0200)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn low_resource_preserves_stricter_limits() {
        let mut c = Config::default();
        c.limits.max_file_mib = 1;
        c.limits.max_connections = 3;
        c.apply_low_resource();
        c.validate().unwrap();
        assert_eq!(c.limits.max_file_mib, 1);
        assert_eq!(c.limits.max_site_mib, 8);
        assert_eq!(c.limits.max_connections, 3);
        assert_eq!(c.max_copies(), 2);
        assert_eq!(c.copy_mib(), 32);
    }
    #[test]
    fn fail_closed_listener() {
        let mut c = Config::default();
        c.validate_listener().unwrap();
        c.server.bind = "0.0.0.0:8080".parse().unwrap();
        c.server.allow_network = true;
        assert!(c.validate_listener().is_err());
        c.server.bind = "192.0.2.1:8080".parse().unwrap();
        c.server.allow_network = false;
        assert!(c.validate_listener().is_err());
        assert!(is_yggdrasil("200::1".parse().unwrap()));
        assert!(is_yggdrasil("300::1".parse().unwrap()));
        assert!(!is_yggdrasil("2001:db8::1".parse().unwrap()));
    }
    #[test]
    fn config_typo_and_header_injection_rejected() {
        assert!(toml::from_str::<Config>("[server]\nbnid='0.0.0.0:80'").is_err());
        let mut c = Config::default();
        c.server.content_security_policy = "ok\r\nInjected: x".into();
        assert!(c.validate().is_err());
    }
}
