//! Small OS boundary: shutdown events, read-only transports and file flags.
use crate::state::State;
use anyhow::Result;
#[cfg(unix)]
use std::os::unix::fs::PermissionsExt;
use std::path::Path;
use tokio::net::{TcpListener, TcpStream};
#[cfg(unix)]
use tokio::net::{UnixListener, UnixStream};
#[cfg(unix)]
use {crate::onion, anyhow::Context, std::fs};

pub enum Listener {
    Tcp(TcpListener),
    #[cfg(unix)]
    Unix(UnixListener),
}
pub enum Stream {
    Tcp(TcpStream),
    #[cfg(unix)]
    Unix(UnixStream),
}
impl Listener {
    pub async fn accept(&self) -> std::io::Result<Stream> {
        match self {
            Self::Tcp(l) => l.accept().await.map(|(s, _)| Stream::Tcp(s)),
            #[cfg(unix)]
            Self::Unix(l) => l.accept().await.map(|(s, _)| Stream::Unix(s)),
        }
    }
}
pub async fn onion_listener(state: &State) -> Result<(Listener, String)> {
    #[cfg(unix)]
    {
        let path = state.socket_path()?;
        let listener =
            UnixListener::bind(&path).context("Cannot bind Tor's private Unix socket")?;
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600))?;
        Ok((
            Listener::Unix(listener),
            format!(
                "unix:{}",
                onion::quote(path.to_str().context("Tor path must be UTF-8")?)?
            ),
        ))
    }
    #[cfg(windows)]
    {
        let _ = state;
        let listener = TcpListener::bind((std::net::Ipv4Addr::LOCALHOST, 0)).await?;
        let target = listener.local_addr()?.to_string();
        Ok((Listener::Tcp(listener), target))
    }
}

#[cfg(unix)]
pub struct Shutdown {
    interrupt: tokio::signal::unix::Signal,
    terminate: tokio::signal::unix::Signal,
}
#[cfg(windows)]
pub struct Shutdown {
    interrupt: tokio::signal::windows::CtrlC,
    close: tokio::signal::windows::CtrlClose,
    stop: tokio::signal::windows::CtrlBreak,
    shutdown: tokio::signal::windows::CtrlShutdown,
}
impl Shutdown {
    pub fn new() -> Result<Self> {
        #[cfg(unix)]
        {
            use tokio::signal::unix::{signal, SignalKind};
            Ok(Self {
                interrupt: signal(SignalKind::interrupt())?,
                terminate: signal(SignalKind::terminate())?,
            })
        }
        #[cfg(windows)]
        {
            use tokio::signal::windows::*;
            Ok(Self {
                interrupt: ctrl_c()?,
                close: ctrl_close()?,
                stop: ctrl_break()?,
                shutdown: ctrl_shutdown()?,
            })
        }
    }
    pub async fn recv(&mut self) {
        #[cfg(unix)]
        tokio::select! {_=self.interrupt.recv()=>{},_=self.terminate.recv()=>{}}
        #[cfg(windows)]
        tokio::select! {_=self.interrupt.recv()=>{},_=self.close.recv()=>{},_=self.stop.recv()=>{},_=self.shutdown.recv()=>{}}
    }
}
pub struct Reload {
    #[cfg(unix)]
    signal: tokio::signal::unix::Signal,
}
impl Reload {
    pub fn new() -> Result<Self> {
        Ok(Self {
            #[cfg(unix)]
            signal: tokio::signal::unix::signal(tokio::signal::unix::SignalKind::hangup())?,
        })
    }
    pub async fn recv(&mut self) {
        #[cfg(unix)]
        {
            self.signal.recv().await;
        }
        #[cfg(windows)]
        std::future::pending::<()>().await;
    }
}

/// Reject final-component links even if a file changes after enumeration.
pub fn no_follow(options: &mut cap_std::fs::OpenOptions) {
    use cap_std::fs::OpenOptionsExt;
    #[cfg(unix)]
    options.custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK);
    #[cfg(windows)]
    options.custom_flags(0x0020_0000); // FILE_FLAG_OPEN_REPARSE_POINT
}

pub fn regular_file(meta: &cap_std::fs::Metadata) -> bool {
    #[cfg(windows)]
    {
        use cap_std::fs::MetadataExt;
        meta.is_file() && meta.file_attributes() & 0x400 == 0
    }
    #[cfg(unix)]
    meta.is_file()
}

pub fn sync_directory(path: &Path) -> Result<()> {
    #[cfg(unix)]
    fs::File::open(path)?.sync_all()?;
    #[cfg(windows)]
    let _ = path; // Windows does not support the Unix directory fsync operation.
    Ok(())
}

pub fn windows_system_program(name: &str) -> std::path::PathBuf {
    std::env::var_os("SystemRoot")
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| "C:\\Windows".into())
        .join("System32")
        .join(name)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[tokio::test]
    async fn event_handlers_can_be_installed() {
        let _ = Shutdown::new().unwrap();
        let _ = Reload::new().unwrap();
    }
}
