//! Versioned public snapshots. Secret keys never enter a snapshot or bundle.
use crate::{
    config::Config,
    site::{public_component, Asset, Site},
    state,
};
use anyhow::{ensure, Context, Result};
use bytes::Bytes;
use ed25519_dalek::{Signature, Signer, SigningKey, VerifyingKey};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::{Read, Write},
    path::Path,
};
pub const MANIFEST_LIMIT: usize = 4 * 1024 * 1024;
const MAGIC: &[u8; 8] = b"GLOWMB01";
const DOMAIN: &[u8] = b"Glowmesh signed snapshot v1\0";
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct FileRecord {
    pub path: String,
    pub size: u64,
    pub sha256: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub format: String,
    pub publisher: String,
    pub title: String,
    pub sequence: u64,
    pub files: Vec<FileRecord>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct SignedManifest {
    pub manifest: Manifest,
    pub signature: String,
}
#[derive(Clone, Debug)]
pub struct Snapshot {
    pub signed: SignedManifest,
    pub site: Site,
}
pub fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}
pub fn unhex<const N: usize>(s: &str) -> Result<[u8; N]> {
    ensure!(
        s.len() == N * 2
            && s.bytes()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)),
        "Invalid lowercase hexadecimal value"
    );
    let mut out = [0u8; N];
    for (i, byte) in out.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&s[i * 2..i * 2 + 2], 16)?;
    }
    Ok(out)
}
pub fn random_id() -> Result<String> {
    let mut bytes = [0u8; 32];
    getrandom::fill(&mut bytes)
        .map_err(|e| anyhow::anyhow!("System randomness unavailable: {e}"))?;
    Ok(hex(&bytes))
}
pub fn identity(path: &Path) -> Result<SigningKey> {
    if fs::symlink_metadata(path).is_ok() {
        let mut key = Vec::new();
        state::private_file(path, false)?
            .take(33)
            .read_to_end(&mut key)?;
        ensure!(
            key.len() == 32,
            "Signing key is damaged. Restore your private backup; a new key changes your identity."
        );
        return Ok(SigningKey::from_bytes(key.as_slice().try_into()?));
    }
    let bytes = unhex::<32>(&random_id()?)?;
    atomic_write(path, &bytes)?;
    Ok(SigningKey::from_bytes(&bytes))
}
pub fn atomic_write(path: &Path, bytes: &[u8]) -> Result<()> {
    let parent = path.parent().context("Missing parent folder")?;
    let temp = parent.join(format!(".pending-{}", random_id()?));
    let result = (|| {
        let mut file = state::private_file(&temp, false)?;
        file.write_all(bytes)?;
        file.sync_all()?;
        fs::rename(&temp, path)?;
        crate::platform::sync_directory(parent)?;
        Ok(())
    })();
    if result.is_err() {
        let _ = fs::remove_file(temp);
    }
    result
}
pub fn valid_path(path: &str) -> bool {
    path.starts_with('/')
        && path.len() <= 4096
        && !path.starts_with("/__glowmesh/")
        && path != "/__glowmesh"
        && path[1..].split('/').count() <= 33
        && path[1..].split('/').all(public_component)
}
impl SignedManifest {
    fn message(&self) -> Result<Vec<u8>> {
        let mut data = DOMAIN.to_vec();
        data.extend(serde_json::to_vec(&self.manifest)?);
        Ok(data)
    }
    pub fn verify(&self, config: &Config) -> Result<()> {
        let m = &self.manifest;
        ensure!(
            m.format == "glowmesh-snapshot-v1",
            "Unsupported snapshot format"
        );
        ensure!(
            !m.title.trim().is_empty()
                && m.title.len() <= 120
                && !m.title.chars().any(char::is_control),
            "Site title must be 1–120 bytes of plain text"
        );
        ensure!(m.sequence > 0, "Snapshot sequence must be positive");
        ensure!(
            !m.files.is_empty() && m.files.len() <= config.limits.max_files,
            "Too many or no files"
        );
        let mut previous = "";
        let mut total = 0u64;
        let mut index = false;
        for f in &m.files {
            ensure!(
                valid_path(&f.path) && f.path.as_str() > previous,
                "Unsafe, duplicate, or unsorted file path"
            );
            ensure!(
                f.size <= (config.limits.max_file_mib * 1024 * 1024) as u64,
                "File exceeds size limit"
            );
            total = total.checked_add(f.size).context("Size overflow")?;
            ensure!(
                total <= (config.limits.max_site_mib * 1024 * 1024) as u64,
                "Site exceeds size limit"
            );
            unhex::<32>(&f.sha256)?;
            previous = &f.path;
            index |= f.path == "/index.html";
        }
        ensure!(index, "Snapshot needs index.html");
        VerifyingKey::from_bytes(&unhex::<32>(&m.publisher)?)?
            .verify_strict(
                &self.message()?,
                &Signature::from_bytes(&unhex::<64>(&self.signature)?),
            )
            .context("Signature does not match this publisher")?;
        ensure!(
            serde_json::to_vec(self)?.len() <= MANIFEST_LIMIT,
            "Manifest exceeds 4 MiB"
        );
        Ok(())
    }
    pub fn parse(data: &[u8], config: &Config) -> Result<Self> {
        ensure!(data.len() <= MANIFEST_LIMIT, "Manifest exceeds 4 MiB");
        let signed: Self = serde_json::from_slice(data).context("Invalid signed manifest")?;
        signed.verify(config)?;
        Ok(signed)
    }
    pub fn accepts(&self, next: &Self) -> Result<()> {
        ensure!(
            next.manifest.publisher == self.manifest.publisher,
            "Publisher identity changed; update refused"
        );
        ensure!(
            next.manifest.sequence >= self.manifest.sequence,
            "Older snapshot refused; your saved copy is newer"
        );
        ensure!(
            next.manifest.sequence != self.manifest.sequence || next.manifest == self.manifest,
            "Conflicting snapshot at the same sequence; update refused"
        );
        Ok(())
    }
}
impl Snapshot {
    pub fn publish(
        site: Site,
        key: &SigningKey,
        title: String,
        sequence: u64,
        config: &Config,
    ) -> Result<Self> {
        let files = site
            .assets
            .iter()
            .map(|(path, asset)| FileRecord {
                path: path.clone(),
                size: asset.bytes.len() as u64,
                sha256: hex(&Sha256::digest(&asset.bytes)),
            })
            .collect();
        let mut signed = SignedManifest {
            manifest: Manifest {
                format: "glowmesh-snapshot-v1".into(),
                publisher: hex(key.verifying_key().as_bytes()),
                title,
                sequence,
                files,
            },
            signature: String::new(),
        };
        signed.signature = hex(&key.sign(&signed.message()?).to_bytes());
        signed.verify(config)?;
        Ok(Self { signed, site })
    }
    pub fn assemble(signed: SignedManifest, content: Vec<Bytes>, config: &Config) -> Result<Self> {
        signed.verify(config)?;
        ensure!(
            content.len() == signed.manifest.files.len(),
            "Missing files"
        );
        let mut site = Site {
            assets: BTreeMap::new(),
            directories: BTreeSet::new(),
            bytes: 0,
        };
        for (f, bytes) in signed.manifest.files.iter().zip(content) {
            ensure!(
                bytes.len() as u64 == f.size && hex(&Sha256::digest(&bytes)) == f.sha256,
                "File verification failed: {}",
                f.path
            );
            let mut dir = Path::new(&f.path).parent();
            while let Some(d) = dir {
                if d != Path::new("/") {
                    site.directories.insert(d.to_string_lossy().into_owned());
                }
                dir = d.parent();
            }
            site.bytes += bytes.len();
            site.assets.insert(
                f.path.clone(),
                Asset {
                    bytes,
                    mime: mime_guess::from_path(&f.path)
                        .first_or_octet_stream()
                        .to_string(),
                    etag: format!("\"{}\"", f.sha256),
                },
            );
        }
        ensure!(
            site.directories
                .iter()
                .all(|p| !site.assets.contains_key(p)),
            "A path is both a file and a folder"
        );
        Ok(Self { signed, site })
    }
    pub fn bundle(&self) -> Result<Vec<u8>> {
        let json = serde_json::to_vec(&self.signed)?;
        let mut out = Vec::with_capacity(12 + json.len() + self.site.bytes);
        out.extend(MAGIC);
        out.extend((json.len() as u32).to_be_bytes());
        out.extend(json);
        for f in &self.signed.manifest.files {
            out.extend(&self.site.assets[&f.path].bytes);
        }
        Ok(out)
    }
    pub fn from_bundle(data: Bytes, config: &Config) -> Result<Self> {
        ensure!(
            data.len() >= 12 && &data[..8] == MAGIC,
            "Choose a Glowmesh .gmb bundle"
        );
        let n = u32::from_be_bytes(data[8..12].try_into()?) as usize;
        ensure!(
            n <= MANIFEST_LIMIT && data.len() >= 12 + n,
            "Truncated or oversized manifest"
        );
        let signed = SignedManifest::parse(&data[12..12 + n], config)?;
        let mut pos = 12 + n;
        let mut content = Vec::new();
        for f in &signed.manifest.files {
            let end = pos
                .checked_add(usize::try_from(f.size)?)
                .context("Size overflow")?;
            ensure!(end <= data.len(), "Bundle ended before all files arrived");
            content.push(data.slice(pos..end));
            pos = end;
        }
        ensure!(pos == data.len(), "Unexpected bytes after bundle");
        Self::assemble(signed, content, config)
    }
    pub fn load(path: &Path, config: &Config) -> Result<Self> {
        let limit = config.limits.max_site_mib * 1024 * 1024 + MANIFEST_LIMIT + 12;
        let mut data = Vec::new();
        fs::File::open(path)?
            .take((limit + 1) as u64)
            .read_to_end(&mut data)?;
        ensure!(data.len() <= limit, "Bundle exceeds size limit");
        Self::from_bundle(data.into(), config)
    }
    pub fn web_site(&self) -> Result<Site> {
        let mut site = self.site.clone();
        let data = Bytes::from(serde_json::to_vec(&self.signed)?);
        site.assets.insert(
            "/__glowmesh/manifest.json".into(),
            Asset {
                etag: format!("\"{:x}\"", Sha256::digest(&data)),
                bytes: data,
                mime: "application/json".into(),
            },
        );
        for f in &self.signed.manifest.files {
            let mut asset = self.site.assets[&f.path].clone();
            asset.mime = "application/octet-stream".into();
            site.assets
                .insert(format!("/__glowmesh/blob/{}", f.sha256), asset);
        }
        Ok(site)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn sample() -> (Config, Snapshot) {
        let c = Config::default();
        let mut site = Site {
            assets: BTreeMap::new(),
            directories: BTreeSet::new(),
            bytes: 5,
        };
        site.assets.insert(
            "/index.html".into(),
            Asset {
                bytes: Bytes::from_static(b"hello"),
                mime: "text/html".into(),
                etag: "test".into(),
            },
        );
        let s = Snapshot::publish(
            site,
            &SigningKey::from_bytes(&[7; 32]),
            "Hello".into(),
            1,
            &c,
        )
        .unwrap();
        (c, s)
    }
    #[test]
    fn bundle_roundtrip_and_corruption() {
        let (c, s) = sample();
        let bytes = s.bundle().unwrap();
        assert_eq!(
            Snapshot::from_bundle(bytes.clone().into(), &c)
                .unwrap()
                .signed,
            s.signed
        );
        let mut bad = bytes.clone();
        *bad.last_mut().unwrap() ^= 1;
        assert!(Snapshot::from_bundle(bad.into(), &c).is_err());
        assert!(Snapshot::from_bundle(bytes[..bytes.len() - 1].to_vec().into(), &c).is_err());
        let mut bad = bytes;
        bad.push(0);
        assert!(Snapshot::from_bundle(bad.into(), &c).is_err());
    }
    #[test]
    fn signature_pin_rollback_and_paths() {
        let (c, s) = sample();
        let mut next = s.signed.clone();
        next.manifest.title = "tampered".into();
        assert!(next.verify(&c).is_err());
        assert!(s.signed.accepts(&next).is_err());
        next.manifest.sequence = 0;
        assert!(s.signed.accepts(&next).is_err());
        next.manifest.sequence = 2;
        next.manifest.publisher = "00".repeat(32);
        assert!(s.signed.accepts(&next).is_err());
        for p in [
            "/../secret",
            "/a//b",
            "/.secret",
            "/__glowmesh/blob/x",
            "/a%2fb",
            "relative",
            "/a/",
        ] {
            assert!(!valid_path(p), "{p}");
        }
    }
}
