# Glowmesh 0.3.0

- Prebuilt executables for Windows x64, Apple silicon Mac, Intel Mac, Linux x64,
  Raspberry Pi / ARM64 Linux and ARMv7 32-bit Linux, in one portable ZIP.
- Matching normal and Low Resource launchers, with data outside the release folder.
- Low Resource keeps the same interface and security checks with one runtime
  thread, smaller file/site/copy budgets, fewer connections and manual updates.
- Native Windows private state uses protected user/SYSTEM ACLs and rejects
  reparse points and hard links. Windows Tor publishing uses loopback TCP.
- Shutdown events and file operations are adapted to Windows, Mac and Linux.
- Portable filename checks reject Windows device names on every platform.
- Bundled WebPKI roots replace platform certificate-store validation for HTTPS
  downloads; custom OS/enterprise roots are not automatically used.
- Beginner quick start, platform installation, Pi/headless and low-resource guides.

Version-1 signatures and bundles remain compatible for valid portable paths.
Keep a private backup before upgrading. Test scope and platform limits are in
VERIFICATION.md.
