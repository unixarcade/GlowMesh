#!/bin/sh
# Sourced by the launchers and installer. Requires project_dir.
select_binary() {
    system=$(uname -s)
    machine=$(uname -m)
    case "$system:$machine" in
        Darwin:arm64) target=macos-arm64 ;;
        Darwin:x86_64) target=macos-x86_64 ;;
        Linux:x86_64) target=linux-x86_64 ;;
        Linux:aarch64|Linux:arm64)
            if [ "$(getconf LONG_BIT 2>/dev/null || echo 64)" = 32 ]; then
                target=raspberry-pi-armv7
            else
                target=raspberry-pi-arm64
            fi ;;
        Linux:armv7l|Linux:armv8l) target=raspberry-pi-armv7 ;;
        *) echo "No included binary for $system / $machine. See docs/INSTALL.md for source builds." >&2; return 1 ;;
    esac
    server_bin="$project_dir/bin/$target/glowmesh"
    if [ ! -f "$server_bin" ]; then
        echo "The $target executable is missing. Extract the complete ZIP again." >&2
        return 1
    fi
}
