#!/bin/sh
# Installs one systemd USER service called glowmesh. Run after install.sh.
set -eu
[ "$#" -eq 1 ] || { echo "Usage: scripts/install-service.sh /absolute/path/to/my-site" >&2; exit 2; }
site_dir=$(CDPATH= cd -- "$1" && pwd -P)
server_bin=$(command -v glowmesh) || { echo "Install Glowmesh and add it to PATH first." >&2; exit 1; }
case "$server_bin" in /*) ;; *) echo "glowmesh must resolve to an absolute executable path" >&2; exit 1;; esac
# Keep unit-file interpolation deliberately simple and reject control syntax.
carriage_return=$(printf '\r')
case "$site_dir$server_bin" in *'"'*|*'\'*|*'%'*|*'$'*|*'
'*|*"$carriage_return"*) echo 'Use paths without quotes, backslashes, percent/dollar signs, or newlines.' >&2; exit 1;; esac
"$server_bin" --config "$site_dir/glowmesh.toml" check --tor
unit_dir=${XDG_CONFIG_HOME:-"$HOME/.config"}/systemd/user
mkdir -p "$unit_dir"
temp_unit=$(mktemp "$unit_dir/.glowmesh.XXXXXX")
trap 'rm -f "$temp_unit"' EXIT HUP INT TERM
cat > "$temp_unit" <<EOF
[Unit]
Description=Glowmesh onion website

[Service]
Type=simple
WorkingDirectory="$site_dir"
ExecStart="$server_bin" --config "$site_dir/glowmesh.toml" serve --onion
ExecReload=/bin/kill -HUP \$MAINPID
Restart=on-failure
RestartSec=5
TimeoutStopSec=10
KillMode=control-group
UMask=0077
NoNewPrivileges=true
RestrictSUIDSGID=true
LockPersonality=true
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6

[Install]
WantedBy=default.target
EOF
chmod 600 "$temp_unit"
mv -f "$temp_unit" "$unit_dir/glowmesh.service"
systemctl --user daemon-reload
systemctl --user enable --now glowmesh.service
echo "Installed and started the user service."
echo "Logs:   journalctl --user -u glowmesh -f"
echo "Stop:   systemctl --user stop glowmesh"
echo "Reload: systemctl --user reload glowmesh"

