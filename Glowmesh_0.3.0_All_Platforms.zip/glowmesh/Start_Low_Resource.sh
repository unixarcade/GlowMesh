#!/bin/sh
set -eu
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
export GLOWMESH_PROFILE=low
exec sh "$project_dir/Start_Glowmesh.sh" "$@"
