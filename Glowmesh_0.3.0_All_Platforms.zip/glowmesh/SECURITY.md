# Security design

Glowmesh 0.3 is a static publisher and local management app with conservative
defaults. The model covers hostile public HTTP clients, malicious snapshot
sources, ordinary web pages attempting to reach the panel, and accidental
exposure of common private files. The operator, executable, configuration,
site directory ancestors and other processes running as that user are trusted.
This release has not received an independent security audit.

## Public serving

- Public listeners accept GET/HEAD only, reject bodies, use immutable in-memory
  snapshots, and offer no public edit, upload, CGI, proxy, or admin endpoint.
- Default access is loopback. The app explicitly enables Tor and mesh separately.
  Tor's HTTP backend is a mode-600 Unix socket inside mode-700 state on Mac/Linux.
  On Windows it is a dynamically assigned loopback TCP port, accessible to other
  local users as a public-content endpoint. The
  publishing Tor process has no SOCKS or control listener. Mesh binds one
  selected Yggdrasil IPv6 address. Legacy TCP serving also requires network
  opt-in; wildcard addresses are rejected.
- Hyper parses HTTP/1. Exact Host checks, origin-form URLs, bounded headers,
  one response per connection, deadlines, a connection semaphore and a global
  rate budget per listener constrain resource use and parsing ambiguity.
- Public paths are decoded once. Traversal, dotfiles, ambiguous encodings,
  encoded separators, invalid UTF-8 and platform-specific syntax are rejected.
  There is no directory listing. Capability-relative snapshot loading rejects
  symlinks/special files and bounds size, count, depth and path length.
- Public content and private state must be disjoint. State must belong to the
  current user and have private directory permissions. Key writes use private
  regular files with no-follow behavior and reject hard-linked private files.
  Windows uses protected DACLs granting the current user and SYSTEM full access;
  private files/directories reject reparse points. Normal user ownership and an
  ACL-capable local filesystem are required. Local administrators remain trusted.
- Browser headers set a restrictive CSP, no-referrer, nosniff, frame denial,
  same-origin resource policy and disabled sensitive permissions. These reduce
  ambient exposure; a saved publisher can still author JavaScript in its page.

## Local control panel

The panel binds only `127.0.0.1`. Its port is separate from every public site
and saved preview. There is no remote-admin mode. A fresh 256-bit random bearer
token is printed as a URL fragment each launch. It is not embedded in HTML or
sent in an HTTP URL. The UI moves it to tab sessionStorage and removes the
fragment. Restart invalidates the token. Possession of the private link grants
local publishing, route management, file edits and outbound fetches; protect it.

API calls require constant-time token comparison, exact numeric Host matching,
and matching Origin when present. Writes require an exact same-origin header.
There is no CORS enablement, cookie authentication or cross-origin form endpoint.
The panel uses only bundled scripts/styles, a fixed restrictive CSP, no-store,
no-referrer, frame denial and same-origin opener/resource policies. Untrusted
names, keys, titles and errors are rendered with DOM textContent.

An imported page runs on a different origin and receives no panel token. The
browser's same-origin policy remains part of this boundary. Browser compromise,
malicious extensions, same-user malware or somebody reading the terminal link
are outside this model. Other local users may reach loopback public previews;
loopback binding alone is not authorization.

Panel writes are serialized; conflicting writes get 409. Its server caps active
connections at 16 (4 in Low Resource), headers at 24, header buffer at 16 KiB, header read at 10
seconds, JSON at 64 KiB, and upload reading at 120 seconds. File and bundle
bodies have size caps. A complete admin connection is bounded to 850 seconds
to permit six sequential network attempts. Status can return a cached view
while a mutation is running. Disk operations/signing can still consume CPU and
block a runtime worker; this is a small-site app, not a hard real-time service.

## Signed copies and outbound requests

Every accepted manifest is strictly verified using Ed25519. Every file must
match its signed length and SHA-256 hash. Paths are unique, sorted and validated;
private/control namespace paths cannot be supplied as content. Bundles have no
compression or filesystem extraction. A complete copy is verified before an
atomic file replacement; an individual listener swaps a complete snapshot.
Failed downloads or verification keep the old copy. Current signatures and
version rules are in [the protocol](docs/PROTOCOL.md).

The user confirms a full publisher key initially. Subsequent updates must keep
that identity and cannot lower the saved sequence or change content at the
same sequence. A signature proves authorization by the key, not benign content,
real-world identity, freshness, or freedom from browser exploits. Compare keys
through a trusted channel. Removal erases the pin and anti-rollback history.
There is no key rotation, revocation, expiration, or distributed consensus.

Fetching is a privileged panel operation. An authorized operator may intentionally
reach private-network and loopback addresses; this is not an internet-facing
URL-fetch service. The client uses only explicit HTTP(S) root URLs, ignores
proxy environment variables, follows no redirects, accepts no credentials,
requests no compression, and bounds streamed bodies and time. TLS uses rustls
with bundled WebPKI/Mozilla certificate roots. The OS trust store and custom
enterprise roots are not automatically imported. Certificate and hostname checks
remain enabled; update Glowmesh to refresh its bundled roots.

Onion URLs require a local SOCKS5h proxy and pass the destination hostname to
Tor. There is no direct retry for that URL. Trailing-dot hosts are rejected to
avoid onion-name ambiguity. Mixing onion and direct routes requires explicit
permission; ordinary hostname routes use ordinary DNS. Direct routes expose
their normal source network address. Sharing the same key/content across
transports links those public identities. Tor and Yggdrasil still need their
own maintenance and appropriate peer/network configuration.

## Storage, processes and logs

The app holds one exclusive state lock shared with the CLI. Persistent lock
files are not unlinked during shutdown. Tor is invoked without a shell, with
quoted configuration paths and process ownership; managed shutdown stops and
reaps the child. Tor watches its owning PID as an additional lifecycle measure.
A failed Tor listener does not stop app local/mesh listeners.

Publishing, settings and saved bundles use temporary files, fsync, rename and
parent fsync on Unix. Windows flushes file data and uses replacement rename,
without Unix directory fsync; equal power-loss durability is not claimed. Settings and content are separate commits. Draft file writes are
atomic per file; a multi-file upload or page draft is not one transaction.
A failed publication leaves the prior site available, but operator edits can
still alter draft files. Keep backups and do not edit the draft concurrently
with publishing if multi-file consistency matters.

No visitor access logs or telemetry are implemented. Startup/errors and Tor's
own messages are visible to the operator. The terminal contains the private
panel link. Peer addresses and last errors are stored privately in panel.json;
they are operational history, not visitor logs.

## Operator responsibilities and limits

Every ordinary file in `public/` is public. Filters cannot recognize secrets
in notes, image metadata, downloaded archives or JavaScript. Public hard links
are ordinary files; do not link private files there. A bundle exports those
public assets as-is and is not encrypted. Private backups contain the signing
seed and onion keys; stop the app before backing up the entire site folder.
Preserve the latest published sequence with its signing key.

Defaults cap file bytes at 32 MiB, site bytes at 256 MiB and saved bundles at
512 MiB across 8 publishers. Active, preview, pending, old and new snapshots
may coexist in memory, and slow responses can retain older buffers. These are
not total RAM limits or protection against every denial of service. Reduce
limits for smaller devices and avoid repeated large publications to slow clients.
Low Resource caps files/sites at 2/8 MiB, saved bundles at 32 MiB across two
publishers, and public connections at 16 per listener; automatic copying is off.
It keeps the same authentication/signature checks and still has no hard RAM cap.

Host checks are not visitor authentication. Anyone who reaches a public
endpoint can construct its allowed Host header. There is no public TLS server,
Tor client-authorization UI, bridge setup UI, user-account system or promise of
universal censorship resistance. Use an appropriate TLS frontend for deliberate
ordinary-internet hosting; never expose the panel. Keep the OS, Tor, Yggdrasil,
Rust dependencies and browser updated, and run without root.

See [VERIFICATION.md](VERIFICATION.md) for actual test results and environmental
limits. Automated tests and RustSec checks do not establish absence of defects.
Report the version, reproduction and impact of a problem without live keys.
