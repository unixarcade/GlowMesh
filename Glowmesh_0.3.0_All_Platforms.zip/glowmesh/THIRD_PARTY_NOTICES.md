# Third-party notices — Glowmesh 0.3

This index covers the union of normal/build dependencies for all six included
executable targets, resolved from Cargo.lock. Dev-only dependencies are not
linked into the server. Upstream license and notice files are included under
`licenses/`. A few additional texts from previous releases are retained.
These do not imply those old packages are still linked into this release.

| Package | Version | Declared license | Included texts |
|---|---|---|---|
| ambient-authority | 0.0.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [ambient-authority-0.0.2](licenses/ambient-authority-0.0.2/) |
| anstream | 1.0.0 | MIT OR Apache-2.0 | [anstream-1.0.0](licenses/anstream-1.0.0/) |
| anstyle | 1.0.14 | MIT OR Apache-2.0 | [anstyle-1.0.14](licenses/anstyle-1.0.14/) |
| anstyle-parse | 1.0.0 | MIT OR Apache-2.0 | [anstyle-parse-1.0.0](licenses/anstyle-parse-1.0.0/) |
| anstyle-query | 1.1.5 | MIT OR Apache-2.0 | [anstyle-query-1.1.5](licenses/anstyle-query-1.1.5/) |
| anstyle-wincon | 3.0.11 | MIT OR Apache-2.0 | [anstyle-wincon-3.0.11](licenses/anstyle-wincon-3.0.11/) |
| anyhow | 1.0.104 | MIT OR Apache-2.0 | [anyhow-1.0.104](licenses/anyhow-1.0.104/) |
| atomic-waker | 1.1.2 | Apache-2.0 OR MIT | [atomic-waker-1.1.2](licenses/atomic-waker-1.1.2/) |
| base64 | 0.22.1 | MIT OR Apache-2.0 | [base64-0.22.1](licenses/base64-0.22.1/) |
| base64 | 0.23.1 | MIT OR Apache-2.0 | [base64-0.23.1](licenses/base64-0.23.1/) |
| bitflags | 1.3.2 | MIT/Apache-2.0 | [bitflags-1.3.2](licenses/bitflags-1.3.2/) |
| bitflags | 2.13.2 | MIT OR Apache-2.0 | [bitflags-2.13.2](licenses/bitflags-2.13.2/) |
| block-buffer | 0.10.4 | MIT OR Apache-2.0 | [block-buffer-0.10.4](licenses/block-buffer-0.10.4/) |
| block-buffer | 0.12.1 | MIT OR Apache-2.0 | [block-buffer-0.12.1](licenses/block-buffer-0.12.1/) |
| bytes | 1.12.1 | MIT | [bytes-1.12.1](licenses/bytes-1.12.1/) |
| cap-primitives | 4.0.3 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [cap-primitives-4.0.3](licenses/cap-primitives-4.0.3/) |
| cap-std | 4.0.3 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [cap-std-4.0.3](licenses/cap-std-4.0.3/) |
| cc | 1.6.0 | MIT OR Apache-2.0 | [cc-1.6.0](licenses/cc-1.6.0/) |
| cfg-if | 1.0.5 | MIT OR Apache-2.0 | [cfg-if-1.0.5](licenses/cfg-if-1.0.5/) |
| clap | 4.6.7 | MIT OR Apache-2.0 | [clap-4.6.7](licenses/clap-4.6.7/) |
| clap_builder | 4.6.7 | MIT OR Apache-2.0 | [clap_builder-4.6.7](licenses/clap_builder-4.6.7/) |
| clap_derive | 4.6.7 | MIT OR Apache-2.0 | [clap_derive-4.6.7](licenses/clap_derive-4.6.7/) |
| clap_lex | 1.1.1 | MIT OR Apache-2.0 | [clap_lex-1.1.1](licenses/clap_lex-1.1.1/) |
| colorchoice | 1.0.5 | MIT OR Apache-2.0 | [colorchoice-1.0.5](licenses/colorchoice-1.0.5/) |
| cpufeatures | 0.2.17 | MIT OR Apache-2.0 | [cpufeatures-0.2.17](licenses/cpufeatures-0.2.17/) |
| cpufeatures | 0.3.1 | MIT OR Apache-2.0 | [cpufeatures-0.3.1](licenses/cpufeatures-0.3.1/) |
| crypto-common | 0.1.7 | MIT OR Apache-2.0 | [crypto-common-0.1.7](licenses/crypto-common-0.1.7/) |
| crypto-common | 0.2.2 | MIT OR Apache-2.0 | [crypto-common-0.2.2](licenses/crypto-common-0.2.2/) |
| curve25519-dalek | 5.0.0 | BSD-3-Clause | [curve25519-dalek-5.0.0](licenses/curve25519-dalek-5.0.0/) |
| curve25519-dalek-derive | 0.1.1 | MIT/Apache-2.0 | [curve25519-dalek-derive-0.1.1](licenses/curve25519-dalek-derive-0.1.1/) |
| digest | 0.10.7 | MIT OR Apache-2.0 | [digest-0.10.7](licenses/digest-0.10.7/) |
| digest | 0.11.3 | MIT OR Apache-2.0 | [digest-0.11.3](licenses/digest-0.11.3/) |
| displaydoc | 0.2.7 | MIT OR Apache-2.0 | [displaydoc-0.2.7](licenses/displaydoc-0.2.7/) |
| ed25519 | 3.0.0 | Apache-2.0 OR MIT | [ed25519-3.0.0](licenses/ed25519-3.0.0/) |
| ed25519-dalek | 3.0.0 | BSD-3-Clause | [ed25519-dalek-3.0.0](licenses/ed25519-dalek-3.0.0/) |
| errno | 0.3.14 | MIT OR Apache-2.0 | [errno-0.3.14](licenses/errno-0.3.14/) |
| find-msvc-tools | 0.1.14 | MIT OR Apache-2.0 | [find-msvc-tools-0.1.14](licenses/find-msvc-tools-0.1.14/) |
| form_urlencoded | 1.2.2 | MIT OR Apache-2.0 | [form_urlencoded-1.2.2](licenses/form_urlencoded-1.2.2/) |
| fs-set-times | 0.20.3 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [fs-set-times-0.20.3](licenses/fs-set-times-0.20.3/) |
| fs2 | 0.4.3 | MIT/Apache-2.0 | [fs2-0.4.3](licenses/fs2-0.4.3/) |
| futures-channel | 0.3.34 | MIT OR Apache-2.0 | [futures-channel-0.3.34](licenses/futures-channel-0.3.34/) |
| futures-core | 0.3.34 | MIT OR Apache-2.0 | [futures-core-0.3.34](licenses/futures-core-0.3.34/) |
| futures-task | 0.3.34 | MIT OR Apache-2.0 | [futures-task-0.3.34](licenses/futures-task-0.3.34/) |
| futures-util | 0.3.34 | MIT OR Apache-2.0 | [futures-util-0.3.34](licenses/futures-util-0.3.34/) |
| generic-array | 0.14.7 | MIT | [generic-array-0.14.7](licenses/generic-array-0.14.7/) |
| getrandom | 0.2.17 | MIT OR Apache-2.0 | [getrandom-0.2.17](licenses/getrandom-0.2.17/) |
| getrandom | 0.4.3 | MIT OR Apache-2.0 | [getrandom-0.4.3](licenses/getrandom-0.4.3/) |
| heck | 0.5.0 | MIT OR Apache-2.0 | [heck-0.5.0](licenses/heck-0.5.0/) |
| http | 1.5.0 | MIT OR Apache-2.0 | [http-1.5.0](licenses/http-1.5.0/) |
| http-body | 1.1.0 | MIT | [http-body-1.1.0](licenses/http-body-1.1.0/) |
| http-body-util | 0.1.5 | MIT | [http-body-util-0.1.5](licenses/http-body-util-0.1.5/) |
| httparse | 1.10.1 | MIT OR Apache-2.0 | [httparse-1.10.1](licenses/httparse-1.10.1/) |
| httpdate | 1.0.3 | MIT OR Apache-2.0 | [httpdate-1.0.3](licenses/httpdate-1.0.3/) |
| hybrid-array | 0.4.15 | MIT OR Apache-2.0 | [hybrid-array-0.4.15](licenses/hybrid-array-0.4.15/) |
| hyper | 1.11.1 | MIT | [hyper-1.11.1](licenses/hyper-1.11.1/) |
| hyper-rustls | 0.27.10 | Apache-2.0 OR ISC OR MIT | [hyper-rustls-0.27.10](licenses/hyper-rustls-0.27.10/) |
| hyper-util | 0.1.21 | MIT | [hyper-util-0.1.21](licenses/hyper-util-0.1.21/) |
| icu_collections | 2.3.0 | Unicode-3.0 | [icu_collections-2.3.0](licenses/icu_collections-2.3.0/) |
| icu_locale_core | 2.3.0 | Unicode-3.0 | [icu_locale_core-2.3.0](licenses/icu_locale_core-2.3.0/) |
| icu_normalizer | 2.3.0 | Unicode-3.0 | [icu_normalizer-2.3.0](licenses/icu_normalizer-2.3.0/) |
| icu_normalizer_data | 2.3.0 | Unicode-3.0 | [icu_normalizer_data-2.3.0](licenses/icu_normalizer_data-2.3.0/) |
| icu_properties | 2.3.0 | Unicode-3.0 | [icu_properties-2.3.0](licenses/icu_properties-2.3.0/) |
| icu_properties_data | 2.3.0 | Unicode-3.0 | [icu_properties_data-2.3.0](licenses/icu_properties_data-2.3.0/) |
| icu_provider | 2.3.1 | Unicode-3.0 | [icu_provider-2.3.1](licenses/icu_provider-2.3.1/) |
| idna | 1.1.0 | MIT OR Apache-2.0 | [idna-1.1.0](licenses/idna-1.1.0/) |
| idna_adapter | 1.2.2 | Apache-2.0 OR MIT | [idna_adapter-1.2.2](licenses/idna_adapter-1.2.2/) |
| if-addrs | 0.14.0 | MIT OR BSD-3-Clause | [if-addrs-0.14.0](licenses/if-addrs-0.14.0/) |
| io-extras | 0.19.0 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [io-extras-0.19.0](licenses/io-extras-0.19.0/) |
| io-lifetimes | 2.0.4 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [io-lifetimes-2.0.4](licenses/io-lifetimes-2.0.4/) |
| io-lifetimes | 3.0.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [io-lifetimes-3.0.1](licenses/io-lifetimes-3.0.1/) |
| ipnet | 2.12.2 | MIT OR Apache-2.0 | [ipnet-2.12.2](licenses/ipnet-2.12.2/) |
| is_terminal_polyfill | 1.70.2 | MIT OR Apache-2.0 | [is_terminal_polyfill-1.70.2](licenses/is_terminal_polyfill-1.70.2/) |
| itoa | 1.0.18 | MIT OR Apache-2.0 | [itoa-1.0.18](licenses/itoa-1.0.18/) |
| libc | 0.2.190 | MIT OR Apache-2.0 | [libc-0.2.190](licenses/libc-0.2.190/) |
| linux-raw-sys | 0.12.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [linux-raw-sys-0.12.1](licenses/linux-raw-sys-0.12.1/) |
| litemap | 0.8.3 | Unicode-3.0 | [litemap-0.8.3](licenses/litemap-0.8.3/) |
| log | 0.4.34 | MIT OR Apache-2.0 | [log-0.4.34](licenses/log-0.4.34/) |
| maybe-owned | 0.3.4 | MIT OR Apache-2.0 | [maybe-owned-0.3.4](licenses/maybe-owned-0.3.4/) |
| memchr | 2.8.3 | Unlicense OR MIT | [memchr-2.8.3](licenses/memchr-2.8.3/) |
| mime | 0.3.17 | MIT OR Apache-2.0 | [mime-0.3.17](licenses/mime-0.3.17/) |
| mime_guess | 2.0.5 | MIT | [mime_guess-2.0.5](licenses/mime_guess-2.0.5/) |
| mio | 1.2.4 | MIT | [mio-1.2.4](licenses/mio-1.2.4/) |
| once_cell | 1.21.4 | MIT OR Apache-2.0 | [once_cell-1.21.4](licenses/once_cell-1.21.4/) |
| once_cell_polyfill | 1.70.2 | MIT OR Apache-2.0 | [once_cell_polyfill-1.70.2](licenses/once_cell_polyfill-1.70.2/) |
| percent-encoding | 2.3.2 | MIT OR Apache-2.0 | [percent-encoding-2.3.2](licenses/percent-encoding-2.3.2/) |
| pin-project-lite | 0.2.17 | Apache-2.0 OR MIT | [pin-project-lite-0.2.17](licenses/pin-project-lite-0.2.17/) |
| potential_utf | 0.1.6 | Unicode-3.0 | [potential_utf-0.1.6](licenses/potential_utf-0.1.6/) |
| proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | [proc-macro2-1.0.107](licenses/proc-macro2-1.0.107/) |
| quote | 1.0.47 | MIT OR Apache-2.0 | [quote-1.0.47](licenses/quote-1.0.47/) |
| reqwest | 0.12.28 | MIT OR Apache-2.0 | [reqwest-0.12.28](licenses/reqwest-0.12.28/) |
| ring | 0.17.14 | Apache-2.0 AND ISC | [ring-0.17.14](licenses/ring-0.17.14/) |
| rustc_version | 0.4.1 | MIT OR Apache-2.0 | [rustc_version-0.4.1](licenses/rustc_version-0.4.1/) |
| rustix | 1.1.5 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [rustix-1.1.5](licenses/rustix-1.1.5/) |
| rustix-linux-procfs | 0.1.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | [rustix-linux-procfs-0.1.1](licenses/rustix-linux-procfs-0.1.1/) |
| rustls | 0.23.45 | Apache-2.0 OR ISC OR MIT | [rustls-0.23.45](licenses/rustls-0.23.45/) |
| rustls-pki-types | 1.15.1 | MIT OR Apache-2.0 | [rustls-pki-types-1.15.1](licenses/rustls-pki-types-1.15.1/) |
| rustls-webpki | 0.103.15 | ISC | [rustls-webpki-0.103.15](licenses/rustls-webpki-0.103.15/) |
| ryu | 1.0.23 | Apache-2.0 OR BSL-1.0 | [ryu-1.0.23](licenses/ryu-1.0.23/) |
| semver | 1.0.28 | MIT OR Apache-2.0 | [semver-1.0.28](licenses/semver-1.0.28/) |
| serde | 1.0.229 | MIT OR Apache-2.0 | [serde-1.0.229](licenses/serde-1.0.229/) |
| serde_core | 1.0.229 | MIT OR Apache-2.0 | [serde_core-1.0.229](licenses/serde_core-1.0.229/) |
| serde_derive | 1.0.229 | MIT OR Apache-2.0 | [serde_derive-1.0.229](licenses/serde_derive-1.0.229/) |
| serde_json | 1.0.151 | MIT OR Apache-2.0 | [serde_json-1.0.151](licenses/serde_json-1.0.151/) |
| serde_spanned | 1.1.1 | MIT OR Apache-2.0 | [serde_spanned-1.1.1](licenses/serde_spanned-1.1.1/) |
| serde_urlencoded | 0.7.1 | MIT/Apache-2.0 | [serde_urlencoded-0.7.1](licenses/serde_urlencoded-0.7.1/) |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | [sha2-0.10.9](licenses/sha2-0.10.9/) |
| sha2 | 0.11.0 | MIT OR Apache-2.0 | [sha2-0.11.0](licenses/sha2-0.11.0/) |
| shlex | 2.0.1 | MIT OR Apache-2.0 | [shlex-2.0.1](licenses/shlex-2.0.1/) |
| signal-hook-registry | 1.4.8 | MIT OR Apache-2.0 | [signal-hook-registry-1.4.8](licenses/signal-hook-registry-1.4.8/) |
| signature | 3.0.0 | Apache-2.0 OR MIT | [signature-3.0.0](licenses/signature-3.0.0/) |
| slab | 0.4.12 | MIT | [slab-0.4.12](licenses/slab-0.4.12/) |
| smallvec | 1.16.2 | MIT OR Apache-2.0 | [smallvec-1.16.2](licenses/smallvec-1.16.2/) |
| socket2 | 0.6.5 | MIT OR Apache-2.0 | [socket2-0.6.5](licenses/socket2-0.6.5/) |
| stable_deref_trait | 1.2.1 | MIT OR Apache-2.0 | [stable_deref_trait-1.2.1](licenses/stable_deref_trait-1.2.1/) |
| strsim | 0.11.1 | MIT | [strsim-0.11.1](licenses/strsim-0.11.1/) |
| subtle | 2.6.1 | BSD-3-Clause | [subtle-2.6.1](licenses/subtle-2.6.1/) |
| syn | 2.0.119 | MIT OR Apache-2.0 | [syn-2.0.119](licenses/syn-2.0.119/) |
| syn | 3.0.6 | MIT OR Apache-2.0 | [syn-3.0.6](licenses/syn-3.0.6/) |
| sync_wrapper | 1.0.2 | Apache-2.0 | [sync_wrapper-1.0.2](licenses/sync_wrapper-1.0.2/) |
| synstructure | 0.14.0 | MIT | [synstructure-0.14.0](licenses/synstructure-0.14.0/) |
| tinystr | 0.8.4 | Unicode-3.0 | [tinystr-0.8.4](licenses/tinystr-0.8.4/) |
| tokio | 1.53.2 | MIT | [tokio-1.53.2](licenses/tokio-1.53.2/) |
| tokio-macros | 2.7.2 | MIT | [tokio-macros-2.7.2](licenses/tokio-macros-2.7.2/) |
| tokio-rustls | 0.26.6 | MIT OR Apache-2.0 | [tokio-rustls-0.26.6](licenses/tokio-rustls-0.26.6/) |
| toml | 0.9.12+spec-1.1.0 | MIT OR Apache-2.0 | [toml-0.9.12+spec-1.1.0](licenses/toml-0.9.12+spec-1.1.0/) |
| toml_datetime | 0.7.5+spec-1.1.0 | MIT OR Apache-2.0 | [toml_datetime-0.7.5+spec-1.1.0](licenses/toml_datetime-0.7.5+spec-1.1.0/) |
| toml_parser | 1.1.3+spec-1.1.0 | MIT OR Apache-2.0 | [toml_parser-1.1.3+spec-1.1.0](licenses/toml_parser-1.1.3+spec-1.1.0/) |
| toml_writer | 1.1.2+spec-1.1.0 | MIT OR Apache-2.0 | [toml_writer-1.1.2+spec-1.1.0](licenses/toml_writer-1.1.2+spec-1.1.0/) |
| tower | 0.5.3 | MIT | [tower-0.5.3](licenses/tower-0.5.3/) |
| tower-http | 0.6.11 | MIT | [tower-http-0.6.11](licenses/tower-http-0.6.11/) |
| tower-layer | 0.3.3 | MIT | [tower-layer-0.3.3](licenses/tower-layer-0.3.3/) |
| tower-service | 0.3.3 | MIT | [tower-service-0.3.3](licenses/tower-service-0.3.3/) |
| tracing | 0.1.44 | MIT | [tracing-0.1.44](licenses/tracing-0.1.44/) |
| tracing-core | 0.1.36 | MIT | [tracing-core-0.1.36](licenses/tracing-core-0.1.36/) |
| try-lock | 0.2.5 | MIT | [try-lock-0.2.5](licenses/try-lock-0.2.5/) |
| typenum | 1.20.1 | MIT OR Apache-2.0 | [typenum-1.20.1](licenses/typenum-1.20.1/) |
| unicase | 2.9.0 | MIT OR Apache-2.0 | [unicase-2.9.0](licenses/unicase-2.9.0/) |
| unicode-ident | 1.0.26 | (MIT OR Apache-2.0) AND Unicode-3.0 | [unicode-ident-1.0.26](licenses/unicode-ident-1.0.26/) |
| untrusted | 0.9.0 | ISC | [untrusted-0.9.0](licenses/untrusted-0.9.0/) |
| url | 2.5.8 | MIT OR Apache-2.0 | [url-2.5.8](licenses/url-2.5.8/) |
| utf8_iter | 1.0.4 | Apache-2.0 OR MIT | [utf8_iter-1.0.4](licenses/utf8_iter-1.0.4/) |
| utf8parse | 0.2.2 | Apache-2.0 OR MIT | [utf8parse-0.2.2](licenses/utf8parse-0.2.2/) |
| version_check | 0.9.5 | MIT/Apache-2.0 | [version_check-0.9.5](licenses/version_check-0.9.5/) |
| want | 0.3.1 | MIT | [want-0.3.1](licenses/want-0.3.1/) |
| webpki-roots | 1.0.9 | CDLA-Permissive-2.0 | [webpki-roots-1.0.9](licenses/webpki-roots-1.0.9/) |
| winapi | 0.3.9 | MIT/Apache-2.0 | [winapi-0.3.9](licenses/winapi-0.3.9/) |
| winapi-util | 0.1.11 | Unlicense OR MIT | [winapi-util-0.1.11](licenses/winapi-util-0.1.11/) |
| winapi-x86_64-pc-windows-gnu | 0.4.0 | MIT/Apache-2.0 | [winapi-x86_64-pc-windows-gnu-0.4.0](licenses/winapi-x86_64-pc-windows-gnu-0.4.0/) |
| windows-link | 0.2.1 | MIT OR Apache-2.0 | [windows-link-0.2.1](licenses/windows-link-0.2.1/) |
| windows-permissions | 0.2.4 | MIT | [windows-permissions-0.2.4](licenses/windows-permissions-0.2.4/) |
| windows-sys | 0.59.0 | MIT OR Apache-2.0 | [windows-sys-0.59.0](licenses/windows-sys-0.59.0/) |
| windows-sys | 0.60.2 | MIT OR Apache-2.0 | [windows-sys-0.60.2](licenses/windows-sys-0.60.2/) |
| windows-sys | 0.61.2 | MIT OR Apache-2.0 | [windows-sys-0.61.2](licenses/windows-sys-0.61.2/) |
| windows-targets | 0.52.6 | MIT OR Apache-2.0 | [windows-targets-0.52.6](licenses/windows-targets-0.52.6/) |
| windows-targets | 0.53.5 | MIT OR Apache-2.0 | [windows-targets-0.53.5](licenses/windows-targets-0.53.5/) |
| windows_x86_64_gnu | 0.52.6 | MIT OR Apache-2.0 | [windows_x86_64_gnu-0.52.6](licenses/windows_x86_64_gnu-0.52.6/) |
| windows_x86_64_gnu | 0.53.1 | MIT OR Apache-2.0 | [windows_x86_64_gnu-0.53.1](licenses/windows_x86_64_gnu-0.53.1/) |
| winnow | 0.7.15 | MIT | [winnow-0.7.15](licenses/winnow-0.7.15/) |
| winnow | 1.0.4 | MIT | [winnow-1.0.4](licenses/winnow-1.0.4/) |
| winx | 0.36.4 | Apache-2.0 WITH LLVM-exception | [winx-0.36.4](licenses/winx-0.36.4/) |
| writeable | 0.6.4 | Unicode-3.0 | [writeable-0.6.4](licenses/writeable-0.6.4/) |
| yoke | 0.8.3 | Unicode-3.0 | [yoke-0.8.3](licenses/yoke-0.8.3/) |
| yoke-derive | 0.8.4 | Unicode-3.0 | [yoke-derive-0.8.4](licenses/yoke-derive-0.8.4/) |
| zerofrom | 0.1.8 | Unicode-3.0 | [zerofrom-0.1.8](licenses/zerofrom-0.1.8/) |
| zerofrom-derive | 0.1.8 | Unicode-3.0 | [zerofrom-derive-0.1.8](licenses/zerofrom-derive-0.1.8/) |
| zeroize | 1.9.0 | Apache-2.0 OR MIT | [zeroize-1.9.0](licenses/zeroize-1.9.0/) |
| zerotrie | 0.2.5 | Unicode-3.0 | [zerotrie-0.2.5](licenses/zerotrie-0.2.5/) |
| zerovec | 0.11.8 | Unicode-3.0 | [zerovec-0.11.8](licenses/zerovec-0.11.8/) |
| zerovec-derive | 0.11.6 | Unicode-3.0 | [zerovec-derive-0.11.6](licenses/zerovec-derive-0.11.6/) |
| zmij | 1.0.23 | MIT | [zmij-1.0.23](licenses/zmij-1.0.23/) |

## Compiler/runtime components

The Rust standard library license texts are included under `licenses/rust-runtime/`.
Linux executables include musl; see `licenses/musl/`. The Windows executable
links MinGW-w64 runtime support and GCC runtime support. Their copyright,
license notices and GCC Runtime Library Exception are included under
`licenses/mingw-w64/` and `licenses/gcc-runtime/`.

Tor, Tor Browser and Yggdrasil are separate installations, not redistributed
inside this ZIP. Keep their own license notices with any installation.
The Mac executables use operating-system dynamic libraries.
