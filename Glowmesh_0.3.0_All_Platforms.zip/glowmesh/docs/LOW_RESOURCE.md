# Small computers and Raspberry Pi

## Start simply

Extract the ZIP, open its `glowmesh` folder in a terminal, then run:

```sh
sh ./Start_Low_Resource.sh
```

On Windows use `Start_Low_Resource.cmd`; on Mac use `Start_Low_Resource.command`.
The normal and low-resource launchers have separate default starter folders.
Use `GLOWMESH_SITE` if you deliberately want to open the same site in either mode.
An existing site must fit the smaller limits before it can load in Low Resource.
The app never silently discards oversized copies or content.

## Which Pi?

| Raspberry Pi setup | Included executable |
|---|---|
| 64-bit Raspberry Pi OS on a compatible ARM64 Pi | `bin/raspberry-pi-arm64/glowmesh` |
| ARMv7-capable Pi with 32-bit Raspberry Pi OS | `bin/raspberry-pi-armv7/glowmesh` |
| Original Pi 1 / original Pi Zero / Zero W, ARMv6 | No matching executable in this release |

Pi 3, 4, 5 and Zero 2 W have ARM64-capable processors. Choose the operating
system first: a 32-bit installation uses the ARMv7 executable even if the CPU
can run 64-bit software. The launcher detects userspace word size on ARM64
kernels. The original Pi Zero and Zero 2 W are different devices.

These are static Linux executables, also useful on compatible ARM Linux machines.
They are not SD-card images or operating systems. Start with a working, updated
OS. See VERIFICATION.md for emulation versus physical-device testing.

## What Low Resource changes

- One async runtime thread; blocking-helper threads may still be created as needed.
- At most 2 MiB per file, 8 MiB per site, and 512 files per site.
- At most 2 saved sites and 32 MiB of stored bundles.
- At most 16 public connections per listener and 4 panel connections.
- At most 20 public requests/second, burst 40, per listener.
- No automatic background copy synchronization. Use **Update now** when needed.

Stricter settings in your configuration remain stricter. Defaults apply at runtime
with `--low-resource`; the flag does not rewrite your saved TOML. Existing automatic
update preferences are ignored in this mode and remain available in standard mode.
The control panel still refreshes visible status every ten seconds while its tab
is open. It pauses polling when hidden.

The same signatures, authentication, path checks, encryption for HTTPS downloads,
and transport rules apply. The executable is shared with normal mode: this is a
resource profile, not a stripped-down security build.

Site snapshots, pending downloads, and old responses can coexist in memory.
There is no hard process-memory limit, and using all three listeners costs more
than one. Browser, Tor and Yggdrasil memory is separate. Keep sites small, avoid
large repeated publishes to slow readers, and enable only the connections you use.

## A Pi without a screen

On the Pi:

```sh
sh ./Start_Low_Resource.sh --no-browser
```

Keep the private panel bound to localhost. On your own computer, forward its port:

```sh
ssh -N -L 4880:127.0.0.1:4880 pi-user@your-pi-address
```

Then open the private `http://127.0.0.1:4880/#...` link printed on the Pi in your
computer's browser. Substitute your actual SSH account/address. The normal panel
port is 4880. Public preview links use separate dynamically chosen ports: to open
a preview through SSH, forward its printed port too. Do not expose the panel
through your router, a public proxy, or a wildcard bind.

For an unattended local-only static server, use the CLI with the same profile:

```sh
./bin/raspberry-pi-arm64/glowmesh --config /home/you/my-site/glowmesh.toml --low-resource serve
```

Use the ARMv7 path for 32-bit OS installations. `serve` has no panel, signed-copy
endpoints, or automatic synchronization. The provided systemd recipe is documented
in OPERATIONS.md; app mode should normally run as your logged-in user.

## Keep SD-card work modest

Glowmesh does not write visitor access logs. Publishing, importing, changing
settings and explicitly updating copies write private state. Back up that state
with the app stopped. Automatic copying is disabled in Low Resource mode; your
OS and any Tor/Yggdrasil processes may still write their own files.
