# Onion, mesh, and distributed names

Glowmesh separates **content**, **transport**, and **naming**. This lets you use
established transports and a small signed-content format. It does not invent
new cryptographic primitives or claim to replace physical connectivity.

## Start with the app

`glowmesh app` keeps a local site available and lets you independently enable
Tor and Yggdrasil in Connections. Each listener serves the selected signed
snapshot. A Tor failure leaves other connections alive. Saved sites retain
verified content, try several pinned-publisher addresses for updates, and can
be shared through your own connections. Bundles can move by USB without any
network. See [the app guide](APP.md) and [snapshot protocol](PROTOCOL.md).

This offers multiple paths and copies. It provides no central directory,
automatic peer discovery, DHT, universal friendly names, or guarantee against
all censorship. Ordinary DNS alone is not the only point where a network can
be blocked; links, routing and reachable peers still matter. Numeric Yggdrasil
URLs and onion identities do not require conventional DNS for those routes.
The IPNS instructions below are a separate Kubo workflow, not a panel toggle.

## 1. Tor: the easiest public address without ordinary DNS

```sh
glowmesh serve --onion
```

Your visitor's Tor Browser reaches Tor's onion-service rendezvous. Your managed
Tor process forwards the stream to Glowmesh's private Unix socket on Mac/Linux,
or its loopback-only TCP backend on Windows. The Rust
server reads its in-memory public snapshot and sends the response back.

The v3 address is derived from the onion service's public key, checksum, and
version. You do not register it in conventional DNS. Resolution and routing
happen inside Tor; changing the machine's DNS settings is unnecessary.

The owner of the corresponding private key controls that service identity.
Back up the full private state as described in OPERATIONS.md. There is no
password reset service that can restore a deleted onion key.

### Defaults that matter

- Mac/Linux: a Unix web socket at mode 600 inside mode-700 state.
- Windows: a dynamic loopback TCP backend; no external interface bind.
- Tor has `SocksPort 0` and `ControlPort 0`; it does not become a public proxy.
- The generated torrc and Tor data are separate from any system Tor service.
- Glowmesh checks its Tor child: in `app` only the onion route stops on failure;
  in legacy `serve --onion` the single-mode server exits.
- Graceful shutdown reaps the owned Tor process. Tor also receives the owning
  process ID so it can stop if the parent disappears.
- The onion URL is available before bootstrap necessarily finishes. The
  program deliberately does not call that a successful global reachability test.

An onion site is public to anyone who can discover its address. Tor client
authorization is a separate feature of Tor; this release does not include a
client-key management interface. For a private group, consult the official
client-authorization guide and manage that access explicitly.

Tor avoids domain registrars for `.onion` identities, but still relies on its
network's directory/bootstrap design and the software you run. It does not
guarantee availability against every censor or adversary.

### Tor installed but connections blocked

The managed mode intentionally has a small fixed configuration surface.
If you require bridges, pluggable transports, or existing Tor administration,
use an externally managed Tor instance and Glowmesh's local HTTP mode:

```sh
# Set onion.enabled = false, server.bind = "127.0.0.1:8080" in glowmesh.toml.
glowmesh serve
```

Do not use `--local` here: that flag deliberately clears the aliases added below.
This external Tor recipe uses legacy `serve`; it has no app signed-copy endpoints.
Then configure the external instance with a separate onion-service directory
and `HiddenServicePort 80 127.0.0.1:8080`, following the Tor Project setup guide.
Add the resulting **exact** onion hostname and `hostname:80` to Glowmesh's
`server.allowed_hosts` and restart Glowmesh. No wildcard is needed. This
advanced setup uses a loopback TCP backend instead of managed mode's private
socket; other local users can reach that loopback endpoint.

## 2. Yggdrasil: the mesh-shaped option

Yggdrasil gives a node an IPv6 address derived from its cryptographic identity
and routes traffic through peers. Nodes can connect over LAN links and/or
internet links. Glowmesh uses that existing IPv6 interface; it does not bundle
or start a Yggdrasil router.

1. Install Yggdrasil on the server and visitor devices using its official
   platform instructions: https://yggdrasil-network.github.io/installation.html
2. Use a **persistent configuration**, preserving its private key. Configure
   the peers you want, or use local discovery for an isolated LAN mesh.
3. Find your node address:

   ```sh
   yggdrasilctl getSelf
   ```

4. Inside your Glowmesh site, start on that exact IPv6 address:

   ```sh
   glowmesh serve --mesh 200:YOUR:REAL:ADDRESS
   ```

   Replace the entire example with the actual address from step 3. The CLI
   accepts addresses in Yggdrasil's `0200::/7` range and uses the configured
   HTTP port, default 8080. The address must already belong to your machine.

5. A visitor connected to the mesh opens:

   ```text
   http://[YOUR_REAL_YGGDRASIL_IPV6]:8080/
   ```

For a saved configuration, adapt `examples/mesh.toml` and run
`glowmesh --config mesh.toml serve`. IPv6 literals in URLs and socket addresses
need square brackets. Prefer the full node address; routed subnets have
different identity properties.

Yggdrasil supplies network transport and cryptographic addressing, not ordinary
browser DNS. Share the numeric URL, or let each visitor maintain their own
local naming choices. There is no universal friendly-name registry in Glowmesh.
The upstream project remains experimental and does not aim to provide anonymity.
Peers and network observers can have different visibility from Tor.

Publishing the same site or public key through Tor, mesh and IPFS links those
public identities. Enable the routes you intend to associate. In `app`, Tor and
mesh can run together explicitly. The legacy `serve --mesh` and `serve --onion`
flags remain mutually exclusive; use `app` for simultaneous listeners.

## 3. IPNS: distributed names for a replicated public snapshot

This is a separate, optional publishing workflow with **Kubo**, the IPFS
implementation. Glowmesh exports safe public files; Kubo publishes them.
The running web server is not itself a DHT node or an IPNS resolver.

An IPNS name is based on a public key and points to signed, updateable records.
Those records can identify an immutable IPFS content snapshot. Your private
key authorizes future updates, so you can publish a new site while keeping
the same IPNS name.

Install Kubo from https://docs.ipfs.tech/install/command-line/ and initialize
it once (`ipfs init`) if you have no existing repository. Keep `ipfs daemon`
running. Its API should remain on loopback; do not expose the administration
API publicly.

Create a publishing identity **once**:

```sh
ipfs key gen --type=ed25519 glowmesh-site
```

Then, inside your Glowmesh site:

```sh
glowmesh check
glowmesh export ../glowmesh-snapshot-001
site_cid=$(ipfs add -Qr --cid-version=1 ../glowmesh-snapshot-001)
ipfs name publish --key=glowmesh-site "/ipfs/$site_cid"
ipfs key list -l
```

Use a new snapshot directory for each update. `export` refuses to overwrite an
existing directory, excludes dotfiles/editor backup names, and rejects symlinks.
**Do not run `ipfs add` on the whole site/project directory**, which could
include onion keys, configuration, backups, and unpublished source files.

Visitors using their own local Kubo node can resolve the name and retrieve
the content through their node:

```sh
ipfs name resolve /ipns/YOUR_KEY_ID
```

The local gateway can also serve
`http://127.0.0.1:8080/ipns/YOUR_KEY_ID/`. Kubo and Glowmesh's local preview both
default to port 8080; stop the preview or choose a different Glowmesh port if
they run on the same machine. Managed onion mode uses no TCP web port, so it
does not have this collision.

Use relative asset links in sites intended for path gateways; the supplied
starter page does. The app's simple text writer uses root-relative assets;
change those to relative paths before exporting that page to a path gateway. Gateway response headers are controlled by the gateway,
not by Glowmesh's CSP or request limits.

Keeping the publishing node online lets it republish IPNS records. Arrange
pinning/replication with other nodes if you want content to survive that one
machine going offline. A public gateway is convenient but becomes a gateway
operator dependency; using your own node avoids relying on one public gateway.
IPFS content is public and can be retained by other peers after you remove
your copy. This workflow does not provide anonymity.

## Primary references

Checked while building this release:

- Tor setup and private Unix sockets: https://community.torproject.org/onion-services/setup/
- Onion address encoding: https://spec.torproject.org/rend-spec/encoding-onion-addresses.html
- Tor client authorization: https://community.torproject.org/onion-services/advanced/client-auth/
- Tor control/ownership mechanisms: https://spec.torproject.org/control-spec/commands.html
- Yggdrasil design: https://yggdrasil-network.github.io/about.html
- Persistent Yggdrasil configuration and addressing: https://yggdrasil-network.github.io/configuration.html
- IPNS design: https://docs.ipfs.tech/concepts/ipns/
- Kubo commands: https://docs.ipfs.tech/reference/kubo/cli/

