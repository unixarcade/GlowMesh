# The Glowmesh app

Run `sh ./Start_Glowmesh.sh`, or `glowmesh --config /path/to/my-site/glowmesh.toml app`.
The default control-panel port is 4880; `app --port 0` chooses a free port.
Keep the terminal running. Closing a tab leaves the server running; Ctrl-C
in the terminal stops every connection and the managed Tor process.

## Your private link

The printed link opens your local controls. It contains a random secret after
`#`. The UI stores that secret in this tab's session storage and removes it
from the address bar. Do not share the printed link or terminal logs containing
it. Restarting invalidates it. Use the newly printed link to unlock a fresh tab.

**Open site** opens a different local port with the public content. Share a
Tor or mesh address with visitors, never the private control-panel link. A
127.0.0.1 address works only on the computer running Glowmesh.

## Make and publish a page

1. Enter a heading and your words. Blank lines make paragraphs.
2. **Save page draft** asks before replacing `index.html` and `style.css`.
3. **Publish changes** validates every file, signs a new version, and switches
   active connections to that complete version.

Typing and saving do not change the live site. Invalid titles, unsafe paths,
symlinks, or exceeded limits leave the last published version available.
The simple writer remembers the text it created; it is not an HTML round-trip
editor for an uploaded website. The heading field also supplies the title
when publishing a custom site. Saving the simple page replaces that custom
home page and stylesheet only after confirmation.

Use **Choose files** to add files to the root of your draft, or **choose a
folder** to preserve that folder's internal structure. The selected outer
folder itself is stripped. Existing filenames are replaced. Folder selection
requires a browser that supports directory uploads. Uploads happen one file
at a time: an error can leave some files in the draft. Review Draft files before
publishing; the published version remains unchanged until Publish succeeds.

Keep an `index.html` home page. Draft files shows the folder on disk, file
sizes, and removal controls. You can edit files there with your own tools too.
Coordinate those edits with publishing; scanning a changing folder is not a
filesystem-wide transaction. Restarting restores the last published version,
not unreviewed draft changes.

Same-origin external scripts and styles work. Inline scripts/styles, external
CDNs, and form submissions are blocked by the default browser policy. See
[configuration](CONFIGURATION.md) for deliberate changes to your public site's policy.
The panel's own policy is fixed.

## Connections

**This computer** is always available while the app runs. Its port is chosen
automatically and can change on restart.

**Tor onion** starts your installed Tor executable. It publishes through a
private Unix socket on Mac/Linux or loopback TCP on Windows, and uses persistent
keys in the site's private folder.
The appearance of an address means its identity is ready; Tor may still be
bootstrapping. Test it using Tor Browser on another device. Tor's absence or
failure leaves your local and mesh connections running. A failed route can be
started again with its button.

**Yggdrasil mesh** lists this computer's detected Yggdrasil addresses. Install
and connect Yggdrasil first, choose the address, and turn mesh on. This listener
uses port 8080. Both peers need a working route; a numeric address alone does
not connect disconnected networks. Tor and mesh can run together deliberately.
Publishing the same content/key makes the shared identity visible across them.

Tor and mesh start off each launch. This release does not install routers or
change system networking from the control panel. See [network setup](NETWORKS.md)
for details and the externally managed Tor option for bridges.

### Reading onion copies

The managed publishing process has no SOCKS listener. To fetch onion updates,
set a **local Tor SOCKS address** in Connections, usually `127.0.0.1:9050` for
system Tor or `127.0.0.1:9150` with Tor Browser open. Verify your installation's
actual port. Empty means onion downloads are disabled.

Onion destinations are sent as hostnames through SOCKS5h. They are never retried
directly. If a saved site mixes onion and non-onion addresses, you must explicitly
allow direct connections. Those direct routes can reveal your ordinary network
address; signing verifies content without concealing the connection.

## Saved sites

1. Choose **Save a site**. Paste the root address of a Glowmesh **app** site.
   Ordinary websites and legacy `serve` do not expose the required signed manifest.
2. Optionally put up to six addresses for that publisher on separate lines.
   Use an available address first: Check publisher inspects the first address.
3. Compare the full public key with the owner through a channel you trust.
   Check the confirmation box, then **Save verified copy**.

The initial signature proves that the files came from the displayed key. Your
out-of-band comparison connects that key to the person you intend to trust.
An attractive title does not prove ownership. Titles and filenames are treated
as text in the panel.

Saving and updating try the configured addresses in order. Each attempt has
a 120-second total budget; individual HTTP requests have a 45-second deadline
and 12-second connection deadline. HTTP 429 responses receive up to three
short retries with a 1–5 second pause, within the route's total budget. Six unavailable routes can therefore take
several minutes. Redirects and compressed responses are rejected. The first
complete valid snapshot wins; this does not prove it is the newest snapshot
anywhere on the network. Wrong publishers, damaged files, lower versions, and
conflicting content at the same version are refused. The previous copy remains
available if no verified replacement arrives.

**Update now** checks immediately. **Keep this copy updated automatically**
checks on a one-minute timer while the app runs; long transfers delay later
checks. Background updates and edits share one change queue. If it is busy,
wait for the change to finish. The panel can still read cached status.

**Open saved site** starts a separate local preview. It requires no connection
to the original site. Opening another saved preview replaces the previous
preview listener. A preview keeps its snapshot until opened again; updating
an actively shared copy also updates the public sharing listeners.

Under **Sharing & connections**:

- **Share this copy** serves the saved publisher's signed snapshot through your
  active connections. Your own page remains saved.
- **Share my site** (shown when sharing another site) or **Publish changes**
  returns the connections to your own page. Restart also returns to your own page.
- **Edit addresses** changes the pinned publisher's routes only after checking
  the key again. Changing to a different key requires adding a separate site.
- **Remove copy** deletes the copy, its pin and update history. This also removes
  the remembered version used to reject older content. Removal asks first.

## Carry a bundle offline

**Save offline bundle** or **Export bundle** downloads `.gmb` public content.
Move it using a USB drive or your chosen file transfer. On the destination app,
choose **Import bundle**, compare the publisher key, and confirm. The server
verifies the signature and every file before offering confirmation, and checks
again against saved version history when committing. No archive extraction or
connection to the publisher is involved.

Bundles are not encrypted and do not contain Glowmesh's private signing or Tor
keys. Anything you deliberately put in a public asset remains public, including
secrets accidentally embedded in an ordinary file. Export is not an identity
backup. Importing your own public bundle cannot recover your publishing key.

## Limits and recovery

Defaults are 32 MiB per file and 256 MiB per site, with 10,000 files. There are
at most 8 saved publishers and 512 MiB of saved bundles in total. Bundle JSON
has an additional 4 MiB limit. The app holds active, preview, pending-import and
transfer data in memory; several snapshots can coexist. Reduce content limits
on small machines. There is no compressed-bundle support or total RAM ceiling.

Privately back up the whole site folder with the app stopped. A damaged signing
key is never silently replaced. A damaged published/saved bundle stops startup
so it can be restored from backup. Preserve `.glowmesh/publisher.key` and
`.glowmesh/published.gmb` together; restoring an old version can leave your
version counter behind copies held by others. See [operations](OPERATIONS.md).

| Problem | Next step |
|---|---|
| Control-panel port busy | Stop your earlier instance, or use `app --port 0` |
| Controls locked | Reopen the current private link printed by the running app |
| Another change is running | Let the current transfer finish; it has bounded deadlines |
| No mesh address | Start Yggdrasil; wait for the panel's next refresh |
| Onion download needs SOCKS | Configure the local Tor SOCKS address in Connections |
| Publisher mismatch | Verify the address with the owner; the old pinned copy stays |
| Older snapshot refused | Find a route carrying a newer version; removal erases the old pin/history |
| Files saved but site unchanged | Choose Publish changes and read any validation error |
| Tor address ready but unreachable | Read bootstrap output and test in Tor Browser; address creation is not connectivity |
| Startup reports a damaged bundle | Stop and restore the affected file from your private backup |

## Windows, Mac and small computers

The ZIP includes Start_Glowmesh and Start_Low_Resource launchers: `.cmd` for
Windows, `.command` for Mac, and `.sh` for Linux/Pi. All use this same interface.
Low Resource displays its active profile and reduced content limits. Saved sites
use manual **Update now** actions; automatic-update controls are disabled.
See INSTALL.md for platform requirements and LOW_RESOURCE.md for exact limits.
