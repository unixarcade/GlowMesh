# Signed snapshots and replication, version 1

Glowmesh 0.3 separates a publisher's identity from the addresses serving its
content. This is a small application protocol, not a DNS service or a routing
protocol. Tor and Yggdrasil handle their own transport cryptography.

## Identity and signed message

`publisher.key` is a private, random 32-byte Ed25519 seed. The public identity
is the 32-byte verifying key encoded as 64 lowercase hexadecimal characters.
The onion key is separate. Never synchronize private keys to make replicas.

A manifest has these fields, in this serialization order:

```json
{
  "format": "glowmesh-snapshot-v1",
  "publisher": "64 lowercase hex characters",
  "title": "A plain-text title",
  "sequence": 1,
  "files": [
    {"path": "/index.html", "size": 123, "sha256": "64 lowercase hex characters"}
  ]
}
```

This is a schema illustration, not a valid signed example. `sequence` and
`size` are unsigned 64-bit integers. The signed envelope is an object with
`manifest` followed by `signature`; the signature is 64 bytes encoded as 128
lowercase hexadecimal characters.

The signed bytes are the ASCII domain string `Glowmesh signed snapshot v1`,
then one zero byte, then the compact JSON serialization of the typed Manifest
using `serde_json`. Struct field order is as above, including file-record fields;
files are sorted lexicographically by their UTF-8 paths. No insignificant
whitespace is emitted. Strings use serde_json's escaping and UTF-8 behavior.
This typed serialization is **not** RFC 8785/JCS. An interoperable implementation
must match these bytes, including escapes and integer spelling. The verifier
parses the envelope, rejects unknown/duplicate fields, reserializes the typed
manifest and performs strict Ed25519 verification. Input JSON field order and
whitespace need not match the signed serialization.

## Validation

- Format exactly `glowmesh-snapshot-v1`; title is nonempty after trimming,
  at most 120 UTF-8 bytes and has no control characters; sequence is positive.
- At least one file, including `/index.html`; configured count/size limits.
- Strictly increasing paths, no duplicates; absolute paths with ordinary UTF-8
  components, at most 4096 bytes and 33 components (32 directory levels).
- No dot components, hidden components, trailing spaces/dots/`~`, controls,
  backslashes, colons, percent signs, question marks, or hash signs.
- `/__glowmesh` and all its descendants are reserved.
- No path may be both a file and a directory. File size and SHA-256 must match
  the supplied bytes exactly. All hashes/keys/signatures use lowercase hex.
- Envelope no larger than 4 MiB; public size quotas apply independently.

A saved identity accepts the same publisher with a greater sequence, or the
same sequence with an identical typed manifest. A lower sequence or differing
manifest at the same sequence is rejected. Routes cannot change the pinned key.

There is no expiry, revocation, key rotation, consensus, latest-version proof,
or multi-writer merge. A malicious initial source can offer an old valid version
before the recipient has version history. Removing a copy removes that history.
A publisher restoring an old backup must publish a version higher than those
already held by its readers; preserve the most recent key and bundle together.

## HTTP endpoints

Every `app` public listener, including saved previews, exposes:

| Endpoint | Response |
|---|---|
| `GET /__glowmesh/manifest.json` | Signed envelope, `application/json` |
| `GET /__glowmesh/blob/<sha256>` | Raw signed file bytes, `application/octet-stream` |
| Ordinary public paths | Site content, with static-server browser policies |

GET and HEAD use the static server's host, rate, size, header and time budgets.
No endpoint accepts public writes. Legacy `serve` does not expose this protocol.

A recipient inspects a manifest, confirms the publisher, then saves it. For
updates, it tries at most six explicit root HTTP(S) URLs sequentially. For each
route it verifies the manifest, the existing key/version policy, and every
file before installing a replacement. A site's publication can change between
requests; missing old blobs make the attempt fail safely and try the next route.
Identical-content blobs share a hash within a snapshot. There is no old-blob
retention, resumable transfer, or delta download in version 1.

HTTPS uses rustls with bundled WebPKI roots and hostname/certificate verification. Environment proxy
settings are disabled. A rate-limited HTTP 429 request can be retried three
times with a bounded 1–5 second pause; the 120-second route deadline still
applies. Redirects, URL credentials, non-root paths, fragments,
queries, and compressed responses are refused. Numeric unspecified/multicast
hosts and trailing-dot hosts are rejected. Onion hosts require v3 label syntax
and a local SOCKS5h endpoint; Tor handles destination resolution. No direct
fallback is made for an onion URL. Mixed onion/direct route lists need an
explicit `allow_direct` opt-in. Ordinary DNS is used for other hostname URLs.

## Offline bundle format

| Bytes | Meaning |
|---|---|
| 0–7 | ASCII `GLOWMB01` |
| 8–11 | Big-endian unsigned 32-bit envelope byte length |
| Next length bytes | UTF-8 JSON signed envelope |
| Remaining bytes | Raw file contents concatenated in manifest order |

The manifest provides every file length. A parser must reject truncation,
trailing bytes, oversized fields, bad signatures/hashes and invalid paths.
The bundle has no compression, timestamps, filesystem metadata, encryption,
symlinks, executable extraction, or private identity material. Glowmesh parses
it into an in-memory snapshot and stores the original logical content as a
private `.gmb` file; it does not unpack paths into the filesystem.

## Commit behavior

A complete verified bundle is written to a randomly named private temporary
file, synced, renamed over its destination, and its parent directory synced.
No in-place overwrite of a saved snapshot occurs. Each listener swaps an Arc
to a complete immutable site; an individual response sees complete old or new
bytes. The listener swaps are sequential, not a cross-listener transaction.
Existing responses may finish with older data. Settings are a separate atomic
file, so a machine crash can leave content committed before its settings entry.

One app holds the state's exclusive process lock. Changes and background
updates are serialized. Saved publishers are limited to eight, with a 512 MiB
aggregate bundle quota. The upload body is bounded before bundle parsing, and
network bodies are bounded while streaming. Pending/old/new snapshots can
coexist in RAM; quotas are not an allocator-level memory guarantee.

## Portable filenames in 0.3

Version 0.3 keeps the version-1 signed format. It additionally rejects Windows
device names such as CON, NUL, AUX, PRN, COM1–COM9 and LPT1–LPT9 (including
extensions and Windows' superscript-digit aliases), plus `*`, `<`, `>` and `"`.
Existing rejections of hidden names, trailing dots/spaces and reserved control
paths remain. The rules apply on all platforms so a publisher cannot introduce
Windows device paths through a signed bundle. If a 0.2 snapshot used these names,
rename the files and publish a newer valid version with 0.2 before importing it.
Prefer simple filenames and avoid names differing only by case when moving
drafts between case-sensitive and case-insensitive filesystems.
