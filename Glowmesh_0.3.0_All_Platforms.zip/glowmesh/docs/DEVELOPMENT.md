# Development

## Layout

| File | Responsibility |
|---|---|
| `src/main.rs` | CLI, initialization, legacy single-listener mode |
| `src/config.rs` | TOML validation, defaults and network opt-in |
| `src/site.rs` | Capability-relative loading, path/range parsing, public export |
| `src/http.rs` | Read-only responses, Host/browser policies, rate limits |
| `src/platform.rs`, `src/windows_state.rs` | OS listeners, signals, file flags and Windows ACL protection |
| `src/state.rs` | Private files, ownership, exclusive process lock |
| `src/onion.rs` | Tor configuration and child lifecycle |
| `src/signed.rs` | Identities, signatures, manifests, bundles, atomic persistence |
| `src/peers.rs` | Explicit routes, SOCKS5h, bounded fetching and verification |
| `src/routes.rs` | Independent public listeners and snapshot swaps |
| `src/panel.rs` | Local authenticated API, draft edits, saved copies, background updates |
| `assets/panel.*` | Embedded vanilla HTML/CSS/JS control panel |
| `assets/index.html`, `style.css` | Embedded starter website |
| `tests/integration.py` | Legacy black-box HTTP/process tests |
| `tests/panel_integration.py` | Authentication, replication, offline, SOCKS and automatic-update tests |
| `tests/ui-dom.cjs` | Shipped UI JavaScript interacting with real app processes in jsdom |
| `tests/ui.cjs` | Optional real-browser smoke/layout checks on a normal host |

Rust owns the runtime; Node is not needed to run Glowmesh. Public responses use
shared immutable Bytes in an Arc site map. Each listener has bounded connection
tasks and a token bucket. App state mutations share one semaphore/manager;
status has a cached view so it stays responsive during network operations.
The active site, previews and own published site are separate snapshots.

Tor, Yggdrasil and IPFS/IPNS remain external networking components. Glowmesh
implements a signed application content format; it is not a DHT node, DNS
resolver, Tor circuit implementation or Yggdrasil router.

## Build and test

Use Rust 1.94+ (release compiler: 1.94.0) and a C toolchain. HTTPS uses
rustls/ring and bundled WebPKI roots; no runtime OpenSSL or OS root store is
required. Cargo.toml declares a 1.88 source floor, which this release did not test.

```sh
cargo fmt --all --check
cargo clippy --locked --all-targets -- -D warnings
cargo test --locked --all-targets
cargo build --locked
python3 tests/integration.py  # Unix-only signal/socket suite
python3 tests/panel_integration.py
```

The Python suites use only the standard library. The automatic-update check
takes about a minute. Use a packaged executable instead with:

```sh
GLOWMESH_BIN="$PWD/bin/linux-x86_64/glowmesh" python3 tests/panel_integration.py
```

No routine test publishes a public onion service. Fake Tor processes exercise
child startup/discovery/failure/reaping. Unix-socket integration tests explicitly
skip when the host disallows that socket type. Run the complete suite on a normal
host before deploying. The SOCKS test uses a local mock and verifies hostname
forwarding; it is not a live Tor circuit test.

Validate the actual generated configuration with installed Tor offline:

```sh
cargo run --locked --example verify-tor -- /usr/bin/tor
```

The example passes `--DisableNetwork 1 --verify-config`, including a path with
spaces. A real deployment check additionally opens the onion URL using Tor
Browser on another device and tests the desired Yggdrasil route.

## UI checks

The optional developer tools should be installed in a separate local directory:

```sh
npm install --prefix /tmp/glowmesh-ui-qa jsdom@26.1.0
JSDOM_MODULE=/tmp/glowmesh-ui-qa/node_modules/jsdom node tests/ui-dom.cjs
```

This executes the real UI scripts and API but emulates dialogs/popups. It does
not validate CSS layout, native file-picker behavior or browser security headers.
For a real browser on an unrestricted desktop:

```sh
npm install --prefix /tmp/glowmesh-browser-qa playwright
/tmp/glowmesh-browser-qa/node_modules/.bin/playwright install chromium
PLAYWRIGHT_MODULE=/tmp/glowmesh-browser-qa/node_modules/playwright node tests/ui.cjs
```

Screenshots, if produced, are placed in `target/ui-checks/` for human inspection.
See VERIFICATION.md for which checks ran successfully for this release.

## Static Linux executable

Install a musl C compiler (for example `musl-tools` on Debian/Ubuntu) and the
Rust target. The compiler is necessary for the native TLS dependency.

```sh
rustup target add x86_64-unknown-linux-musl
CC_x86_64_unknown_linux_musl=musl-gcc RUSTFLAGS='-C linker=rust-lld' \
  cargo build --release --locked --target x86_64-unknown-linux-musl
```

The included x86_64 executable is static PIE and stripped, with thin LTO.
It embeds no Tor/Yggdrasil executable and no private identities. Keep Cargo.lock
and review dependency changes deliberately. This archive is not a vendored,
air-gapped source build; first compilation needs crate downloads.

```sh
cargo install cargo-audit --locked
cargo audit
```

Advisory scans describe a particular lockfile/database snapshot, not all possible
defects. The included CI runs format, lint, Rust/Python tests and dependency
auditing when placed in a GitHub repository; that hosted workflow was not run
as part of creating this download.

## Boundaries

Automatic HTTPS, bridge configuration, Tor client-auth keys,
universal names, automatic discovery, multi-writer publishing, key rotation and
resumable/delta downloads are not implemented. Changes to protocol serialization
need careful compatibility review; see PROTOCOL.md and SECURITY.md.

## Included platform targets

| Folder under bin | Rust target | Link toolchain used here |
|---|---|---|
| windows-x86_64 | x86_64-pc-windows-gnu | MinGW-w64 GCC 13, static GCC/pthread support |
| macos-arm64 | aarch64-apple-darwin | cargo-zigbuild 0.23.4, Zig 0.13.0 |
| macos-x86_64 | x86_64-apple-darwin | cargo-zigbuild 0.23.4, Zig 0.13.0 |
| linux-x86_64 | x86_64-unknown-linux-musl | rust-lld; Zig 0.13.0 for ring's C files |
| raspberry-pi-arm64 | aarch64-unknown-linux-musl | rust-lld; Zig 0.13.0 for ring's C files |
| raspberry-pi-armv7 | armv7-unknown-linux-musleabihf | rust-lld; Zig 0.13.0 ARMv7/VFPv3-D16 for ring |

All use the same Cargo.lock, thin LTO, one codegen unit, and stripped release
output. The Mac build environment set MACOSX_DEPLOYMENT_TARGET=11.0; the linked output
records macOS 11.7.1 as its minimum (checked in both Mach-O headers). No third-party dynamic
libraries are needed. The Linux targets use Rust's self-contained musl runtime.
The GNU Windows executable needs Windows system DLLs only.

Native builds are simpler: install Rust and the platform's C toolchain, then run
`cargo build --release --locked`. Windows users can use the standard MSVC target.
For Linux cross builds, set `CC_<target>` to the appropriate C cross-compiler,
`AR_<target>` to its archiver, and `CARGO_TARGET_<TARGET>_LINKER=rust-lld` (uppercase
and underscores). A Zig C wrapper must translate cc-rs's `--target` into Zig's
target spelling; the Rust link step uses rust-lld, avoiding duplicate CRT objects.

The Python app suite is prepared to use CTRL_BREAK and a new process group on
Windows. Its native run remains a release follow-up; Unix tests use SIGTERM/HUP.
Use `GLOWMESH_TEST_LITE=1` with the jsdom test to exercise the Low Resource UI.
Native Windows file ACLs and Mac first-open behavior need platform testing;
cross-compilation alone does not check those behaviors.
