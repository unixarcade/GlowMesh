# Configuration reference

`glowmesh init` writes a complete `glowmesh.toml` with defaults. Settings are
optional, but unknown keys are errors to catch typos. The file is limited to
64 KiB. Relative filesystem paths resolve beside the configuration file,
not the shell's current directory. Configuration changes require a restart.

## App-specific behavior

The table below describes `serve`. In `app`, network exposure is controlled by
the UI: its public local listener chooses a free IPv4 loopback port; Tor and
mesh start off regardless of `onion.enabled`. The mesh button binds the selected
Yggdrasil IP at port 8080. The panel itself always uses `127.0.0.1`, default
port 4880, controlled by `app --port` (`0` chooses a free port).

App local/preview/mesh listeners clear additional Host aliases and accept their
own exact addresses. Managed onion accepts the onion host and configured
aliases. `root`, `state_dir`, public browser policy, file limits and per-listener
HTTP budgets still apply. Tor binary and startup timeout still apply when the
button enables it. Private `panel.json` stores UI preferences; edit through the
panel. The `.glowmesh` folder is not configuration intended for public sharing.

Additional app limits: 8 saved publishers, 512 MiB aggregate bundles, six routes
per publisher, 4 MiB signed manifest, 64 KiB action JSON, 16 control-panel
connections, 24 panel headers and a 16 KiB header buffer. Panel uploads have
a 120-second body deadline; panel connections are bounded to 850 seconds to
allow sequential route attempts. Changes are serialized; competing writes get
409. The local panel requires its private token and same-origin writes.

## `[server]`

| Key | Default | Meaning |
|---|---|---|
| `root` | `"public"` | Folder containing the public site; must have `index.html` |
| `state_dir` | `".glowmesh"` | Private state; separate from public, neither nested inside the other |
| `bind` | `"127.0.0.1:8080"` | One exact IP and nonzero port for TCP mode |
| `allow_network` | `false` | Required for a non-loopback TCP bind; `--mesh` explicitly sets it |
| `allowed_hosts` | `[]` | Additional exact Host authorities; include the port when browsers send one |
| `content_security_policy` | See below | Browser policy, between 1 and 4096 bytes, no header control characters |

The configured TCP address/port is automatically allowed. `localhost:PORT` is
also allowed for loopback mode. The generated onion host, with and without
`:80`, is automatically allowed in managed onion mode. `--local` always forces
IPv4 loopback and clears additional host aliases for that process.

No wildcard address (`0.0.0.0` or `::`) or multicast address is accepted, even
when `allow_network` is true. Managed onion mode ignores `bind` and opens only
its private Unix web socket. That socket path must fit within 100 bytes.

An intentional local hostname or reverse-proxy hostname can be added:

```toml
[server]
allowed_hosts = ["example.test:8080", "www.example.org"]
```

These are exact authorities, not DNS records. This setting does not register
or resolve the names, enable TLS, or authorize clients. Request Host values
must match one allowed value, case-insensitively.

Default browser policy:

```text
default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'
```

Use external same-origin `.js` and `.css` files for the easiest fit. Inline
scripts, inline styles, external CDNs, embedded objects, and form submissions
are blocked by default. If your artwork is a single HTML file with embedded
JavaScript/CSS, split those into files or add the appropriate CSP hashes for
the exact inline blocks. You can configure a different policy deliberately;
adding `'unsafe-inline'` or broad external sources weakens this default.

## `[onion]`

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `false` | Make `serve` use managed Tor by default |
| `tor_binary` | `"tor"` | Executable on PATH, or an explicit path; paths with directory components resolve beside the config |
| `startup_timeout_secs` | `90` | Time to wait for Tor to create/read its hostname, 1–600 seconds |

`serve --onion` enables Tor for that run. `serve --local` forces local preview.
The hostname timeout is not a network bootstrap deadline. The process keeps
serving as Tor finishes connecting, and the address is not advertised as
end-to-end verified by Glowmesh itself.

Glowmesh regenerates `torrc` at each start. Store changes in supported config
fields, not that generated file. More advanced Tor configurations belong in
an externally managed Tor instance; see NETWORKS.md.

## `[limits]`

| Key | Default | Allowed values / effect |
|---|---:|---|
| `max_file_mib` | 32 | 1–2048; maximum bytes read for one asset |
| `max_site_mib` | 256 | At least max_file_mib, at most 4096; total asset bytes in a snapshot |
| `max_files` | 10000 | 1–100000; also caps scanned entries to four times this count |
| `max_connections` | 128 | 1–4096; excess accepted sockets are immediately closed |
| `requests_per_second` | 100 | 1–100000; global token-bucket refill |
| `burst` | 200 | 1–100000; global token-bucket capacity |
| `header_timeout_secs` | 10 | 1–120; maximum time to receive request headers |
| `connection_timeout_secs` | 120 | 1–3600; total lifetime of one connection/response |

One MiB means 1,048,576 bytes. The memory limit counts file contents, not every
allocator, parser, task, Tor, or filesystem overhead. Reloading builds a new
snapshot before releasing the old one; in-flight replies can retain old bytes.
Allow at least two snapshots plus application/Tor overhead, and more when
frequently reloading large assets to slow clients.

For public listeners, other fixed limits are 32 request headers, a 16 KiB HTTP/1 connection buffer,
a 4096-byte URI, and 32 directory levels. Only GET and HEAD are accepted.
Public request bodies are rejected; authenticated panel uploads are separate. HTTP connections close after one response;
there are no WebSockets, HTTP/2, multi-range bodies, or streaming uploads.

Range requests support one `bytes` range, including suffix and open-ended
ranges. Invalid/unsatisfiable and multiple ranges get 416. HEAD ignores Range.
ETags support conditional GET/HEAD and exact-ETag If-Range checks.

Files whose path components begin with a dot, end with `~`, space, or dot,
or contain control characters, backslash, colon, percent, question mark, or
hash are excluded. Request paths with those forms are unavailable. Unicode
filenames and spaces inside normal names work. Only UTF-8 filenames are
supported. Symlinks and special files in public content are rejected.

## Larger artwork

For a site containing a 150 MiB video, for example:

```toml
[limits]
max_file_mib = 192
max_site_mib = 512
connection_timeout_secs = 600
```

This keeps video range seeking available, but uses more memory and permits
longer connections. For multi-gigabyte downloads or very large libraries,
use a streaming server behind Tor or an IPFS distribution workflow instead.

## Low Resource and platform behavior

`glowmesh --low-resource app` applies the limits in LOW_RESOURCE.md after reading
your configuration. Existing stricter values remain in force. The mode is a CLI
flag, not a TOML field; the launcher supplies it. On 32-bit builds, validation
also reserves address space for bundle metadata and rejects sizes that overflow
platform arithmetic. Large theoretical configuration maxima are not recommended
for a Pi. A complete site must fit in available process memory.

Windows Tor paths can use TOML literal strings, for example
`tor_binary = 'C:\Users\you\Apps\Tor\tor\tor.exe'`. Use a normal local NTFS
state folder. Mac/Linux use Unix ownership and permission checks. The Windows
Tor backend uses loopback TCP; Mac/Linux use private Unix sockets.
