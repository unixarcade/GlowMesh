# Install Glowmesh 0.3

Extract the complete ZIP. Keep the `bin`, `scripts`, and launcher files together.
**No compiler or administrator installation is needed for normal use.**

## Windows — Intel / AMD 64-bit

1. In Explorer, right-click the ZIP and choose **Extract All**.
2. Open the extracted `glowmesh` folder.
3. Double-click **Start_Glowmesh.cmd**, or **Start_Low_Resource.cmd** for a small site.
4. Your browser opens the panel. Keep the terminal window open; Ctrl-C stops it.

Requires Windows 10/11 x64 and a local NTFS site folder owned by your normal
Windows user. Default: `%LOCALAPPDATA%\Glowmesh\my-site` (or `my-site-lite`).
The state folder ACL grants access to your account and SYSTEM. Do not place
private keys on FAT/exFAT, a shared drive, or in a publicly synced folder.
Run as your regular account, not with Run as administrator.

This is an unsigned executable. Windows may show an unknown-publisher prompt;
verify the source and checksums before approving this specific program. Do not
disable antivirus or SmartScreen globally. If your organization blocks unsigned
programs, use its approval process or build from source. A native ARM64 Windows
executable is not included; x64 emulation was not tested.

The binary at `bin/windows-x86_64/glowmesh.exe` uses Windows system DLLs and
needs no separate Visual C++ runtime installer. It is a console program with a
browser interface. Double-click the launcher, rather than the executable alone.

To choose a site in Command Prompt:

```bat
set "GLOWMESH_SITE=C:\Users\you\my-sites\hello"
Start_Glowmesh.cmd
```

## macOS — Apple silicon and Intel

1. Extract the ZIP and open its `glowmesh` folder.
2. Open **Start_Glowmesh.command** or **Start_Low_Resource.command**.
3. Keep its Terminal window open. The launcher detects your Mac's processor.

The supplied builds target macOS 11.7.1 or newer. They use system libraries only;
Rust and Homebrew are not needed for the server. Default data folder:
`~/Library/Application Support/Glowmesh/my-site` (or `my-site-lite`).

The release is not Developer ID signed or notarized. Apple silicon's executable
has an ad-hoc code signature, which is not a verified publisher identity. If
Gatekeeper blocks the downloaded program, review Apple's per-app approval steps
in System Settings → Privacy & Security:
https://support.apple.com/en-us/102445 . Approve only the copy you chose to trust;
do not turn off Gatekeeper globally. On managed Macs, follow your administrator's
policy. See VERIFICATION.md for the exact scope of testing.

If your extraction tool removed executable permissions, open Terminal in the
extracted folder and run:

```sh
chmod u+x Start_Glowmesh.command Start_Low_Resource.command
sh ./Start_Glowmesh.sh
```

The launcher repairs its bundled binary's execute bit if needed. Your browser
may ask whether to open the local link; the same private link is printed in
Terminal. The launch script includes the standard Homebrew executable locations
so separately installed Tor can be found when starting from Finder.

## Linux and Raspberry Pi

From the extracted `glowmesh` folder:

```sh
sh ./Start_Glowmesh.sh
# Or the smaller profile:
sh ./Start_Low_Resource.sh
```

Included static Linux builds: x86_64, ARM64, and ARMv7 hard-float. They do not
require dynamic glibc, OpenSSL, Node or Rust. Use an up-to-date Linux distribution
with a kernel supported by Rust's target; modern Raspberry Pi OS is suitable. ARMv6-only Pi 1 and original Pi Zero are not covered.
See [the Pi guide](LOW_RESOURCE.md) for OS bitness, headless use and limits.

Default data folder: `${XDG_DATA_HOME:-$HOME/.local/share}/glowmesh/my-site`.
Low Resource uses `my-site-lite`. WSL2 x64 can use the Linux binary; if automatic
browser launch is unavailable, copy the terminal's private link into your browser.

Optional command installation, without sudo:

```sh
sh ./install.sh
export PATH="$HOME/.local/bin:$PATH"
glowmesh --config "$HOME/my-site/glowmesh.toml" app
```

The installer selects your included Mac/Linux/Pi binary and places it under
`${GLOWMESH_PREFIX:-$HOME/.local}/bin`. It does not edit your shell profile, move
data, install packages, or start a daemon. To keep a chosen site on Mac/Linux/Pi:

```sh
GLOWMESH_SITE="$HOME/my-sites/hello" sh ./Start_Glowmesh.sh
```

## Add Tor when you want onion access

Tor is optional and separate from this ZIP. Local editing, publishing and offline
copies work without it. Install Tor from your OS package manager or the Tor Project.

| System | Typical setup |
|---|---|
| Debian / Ubuntu / Raspberry Pi OS | `sudo apt install tor` |
| Fedora | `sudo dnf install tor` |
| Mac with Homebrew | `brew install tor` |
| Windows | Extract the Tor Expert Bundle from the official Tor Project download page |

Official downloads: https://www.torproject.org/download/tor/ . Retain the Windows
bundle's DLLs and supporting files alongside its `tor.exe`. In your site's
`glowmesh.toml`, edit the existing `[onion]` section (do not add a second one):

```toml
[onion]
enabled = false
tor_binary = 'C:\Users\you\Apps\Tor\tor\tor.exe'
startup_timeout_secs = 90
```

Substitute the actual extracted executable path. TOML single-quoted strings keep
Windows backslashes literal. Restart Glowmesh, then choose **Connections → Turn
on Tor**. `enabled` controls legacy CLI mode; app connections start off every launch.
On Mac/Linux, a full `tor_binary` path also works if Tor is absent from PATH.

Glowmesh launches its own Tor process with private state, no SOCKS listener and
no control port. On Mac/Linux its HTTP backend is a private Unix socket. On Windows
it is a dynamically assigned `127.0.0.1` TCP port, with no external interface bind.
A system Tor service can coexist with that publishing process.

Downloading copies from onion sites needs a separate, local SOCKS proxy: often
`127.0.0.1:9050` for a configured system Tor, or `127.0.0.1:9150` while Tor Browser
is open. Set that in **Connections**. Tor Browser alone does not install a system
`tor` executable for publishing. An onion address appearing does not prove it is
already reachable; verify from another device's Tor Browser after bootstrapping.

Yggdrasil is also an optional external program. See NETWORKS.md for its setup.

## Build from source

Use Rust 1.94 or newer and a C toolchain. On Windows, install Rust for MSVC and
Visual Studio C++ Build Tools with the Windows SDK. On Mac, install Xcode Command
Line Tools. On Debian/Ubuntu, install `build-essential ca-certificates`.
TLS uses rustls/ring with bundled WebPKI roots; CMake and a runtime OpenSSL package
are not required. Enterprise/custom CA stores are not automatically imported.

```sh
cargo build --release --locked
./target/release/glowmesh --config my-site/glowmesh.toml app
```

On Windows the result is `target\release\glowmesh.exe`. Mac/Linux can also use
`sh ./install.sh --source`. First compilation needs crates.io; dependencies are
locked but not fully vendored. Development and cross-build details are in
DEVELOPMENT.md. Native Windows/Mac execution still needs testing on those systems.

## Docker (command-line publishing)

The supplied recipe runs `serve --onion`. It does not expose the local control
panel or provide signed-copy synchronization. Use the desktop `app` workflow
for those features; do not publish its management port through Docker.

Docker runs Linux containers, so this route can also work through Docker
Desktop. The recipe builds Glowmesh from source and installs Tor in the
runtime image. A Docker engine is required.

From the extracted project directory, create the content folder using an
installed Glowmesh, or copy the starter assets if no host binary is available:

```sh
mkdir -p my-site/public
cp assets/index.html assets/style.css my-site/public/
docker compose up --build -d
docker compose logs -f
```

Read the address and manage the service:

```sh
docker compose exec glowmesh --config /site/glowmesh.toml address
docker compose exec glowmesh --config /site/glowmesh.toml status
docker compose kill -s HUP glowmesh
docker compose restart
docker compose down
```

The image starts as UID/GID 10001, with a read-only root filesystem,
read-only public content, dropped capabilities, and no published ports.
The named `onion-state` volume preserves keys. Its initial ownership is set
in the image; a pre-existing volume may need its ownership/permissions fixed.
Content on the host must be readable and directories traversable by UID 10001.

**Do not use `docker compose down -v` unless you intend to delete the onion
identity.** Compose prefixes volume names with its project name; keep the same
project name when updating. Rebuilding refreshes the Tor package. Pin base-image
digests yourself if you need a fully controlled image supply chain.

The supplied Docker recipe is source-reviewed; see VERIFICATION.md for whether
a Docker runtime was available during packaging.

## Verify and update

The ZIP includes `SHA256SUMS`. From its extracted `glowmesh` folder:

```sh
sha256sum -c SHA256SUMS          # Linux / Pi
shasum -a 256 -c SHA256SUMS     # Mac
```

On Windows, compare a selected file to its manifest entry in PowerShell:

```powershell
Get-FileHash .\bin\windows-x86_64\glowmesh.exe -Algorithm SHA256
```

Checksums detect corruption relative to this archive, not publisher authenticity.
To update: stop Glowmesh, back up your entire site folder privately, extract the
new release to a different folder, and use its launcher. Site data stays separate.
Version 0.3 reuses 0.2 signing keys, onion keys, saved copies and settings. The
panel's private link changes each launch. Tor/mesh begin off.

A 0.2 site containing newly disallowed Windows device-style filenames must be
renamed and republished before use in 0.3. Ordinary valid `.gmb` snapshots remain
compatible; see PROTOCOL.md. Low Resource requires content to fit its lower limits.
Use the normal launcher to reopen larger sites.

For CLI services, install the new command, validate the existing configuration,
and restart the service. Unix-only `SIGHUP` reload is unavailable on Windows;
restart legacy `serve`, or use the app's Publish button on all platforms.

Glowmesh does not silently update itself. Keep your OS, browser, Tor and
Yggdrasil updated. To uninstall a portable release, stop the app and remove its
release folder. Your site folder remains. Back it up before deliberately removing
that folder; it contains your identities.
