# Run your little corner of the network

## Choose your workflow

`glowmesh app` runs the local UI, signed publishing, independent connections,
and saved copies. Use Publish changes there. It restores the last published
bundle after restart; editing draft files and restarting does not publish them.
It handles SIGINT and SIGTERM but **does not use SIGHUP to reload**.

`glowmesh serve` is the earlier single-listener, read-only mode. The systemd
and Docker recipes below use `serve`; their SIGHUP reload instructions apply
only to it. `app` and `serve` cannot run against the same state concurrently.

## Your site's files

| Path | Purpose |
|---|---|
| `glowmesh.toml` | Settings; relative paths resolve beside this file |
| `public/index.html` | Home page |
| `public/style.css` | Starter stylesheet |
| `public/...` | All intentionally public content |
| `.glowmesh/publisher.key` | Private Ed25519 publishing seed; never share |
| `.glowmesh/published.gmb` | Last published signed snapshot, including its version counter |
| `.glowmesh/copies/<public-key>.gmb` | Verified saved public copies |
| `.glowmesh/panel.json` | Local UI text, routes, pins, automatic-update preferences and last results |
| `.glowmesh/onion/` | Tor hostname and private identity keys |
| `.glowmesh/tor-data/` | Tor client state, including guards |
| `.glowmesh/http.sock` | Private onion web socket, present while running |
| `.glowmesh/torrc` | Generated Tor configuration; regenerated on start |
| `.glowmesh/server.lock` | Persistent lock file; the operating-system lock indicates liveness |
| `.glowmesh/server.pid` | Informational PID; removed on normal stop |

The state directory is private to the current user. Run Glowmesh without root.
Keep its parent directory under your control as well. Keep backups outside
`public/`; a public archive is still public even if it contains private keys.

## Edit and reload (`serve` only)

The server loads a bounded snapshot into memory. Editing files does not alter
what visitors receive until you reload or restart. This prevents a half-written
file being served during ordinary editing.

For the user service:

```sh
glowmesh check
systemctl --user reload glowmesh
```

For foreground mode, either stop with Ctrl-C and start again, or send SIGHUP
to the PID printed at startup from another terminal:

```sh
kill -HUP 12345
```

Replace `12345` with the current PID. Check it before signaling; stale PIDs can
be reused. The systemd command handles the process identity for you.

A successful reload swaps in the new snapshot. A missing index, symlink,
oversized site, unreadable file, or other validation failure keeps the old one.
Existing responses can complete using their old bytes. New connections may
wait briefly while a snapshot is built. **Only public content reloads; restart
to apply configuration changes.** Avoid editing files during the snapshot load
if you need a coordinated multi-file release.

## Start on login or boot (`serve` only)

`scripts/install-service.sh /absolute/path/to/my-site` installs one systemd
user service and starts it in onion mode. Do not run that script with sudo.

```sh
systemctl --user status glowmesh
systemctl --user restart glowmesh
systemctl --user stop glowmesh
journalctl --user -u glowmesh --since today
```

To let your user service run after logout and start at boot, an administrator
can enable lingering:

```sh
sudo loginctl enable-linger "$USER"
```

On systems without a systemd user session, run it in a foreground terminal,
use your existing service manager, or use Docker. The program handles SIGINT
and SIGTERM, stops its Tor child, allows up to five seconds for HTTP workers,
and releases its state lock. Tor also watches its owning process to reduce
orphaned children if Glowmesh is killed abruptly.

## Back up your identity and versions

For `app`, stop its terminal with Ctrl-C, then privately back up the entire site
folder. This preserves both publisher and onion keys, the published sequence,
saved-copy history, routes and draft content. Public `.gmb` exports do not
contain the private keys and cannot restore publishing access.

Keep the current `publisher.key` and `published.gmb` together. Restoring an old
published bundle can reset your sequence below the versions your readers have;
they will reject lower versions. Publish until your sequence exceeds the highest
one they hold, or recover the more recent backup. Never independently publish
from two copies of the same signing key. Use signed public replicas for sharing.

### Tor identity

The Tor identity belongs to the private keys in `.glowmesh/onion/`.
Deleting those keys means a new onion address next time. Copying them lets
someone else impersonate the same address.

For a consistent backup, stop the service, then archive your site and state
with private permissions. Run this from the **parent of your site directory**:

```sh
systemctl --user stop glowmesh
umask 077
tar -czf my-site-private-backup.tar.gz my-site
systemctl --user start glowmesh
```

This archive includes secrets. Keep it on encrypted storage or encrypt it with
your normal backup tool. Do not put it in `public/`, email it casually, or
publish it as part of the project source. For Docker, stop the container and
back up its named state volume as well as public content and configuration.

## Restore or move to another machine

Stop the old instance. Extract the private backup on the new machine as the
user who will run it. Preserve the state directory at mode 700 and key files
at mode 600, and ensure ownership matches the new user. Install Glowmesh and
Tor there, run `glowmesh check --tor`, then launch `app` and enable Tor, or start legacy onion mode. Keep one ordinary
Tor instance per identity; running two copies of the same keys is not the
supported replication mechanism.

## Troubleshooting

| Symptom | What to do |
|---|---|
| `glowmesh: command not found` | Add the installation's `bin` directory to PATH, or use its full path. |
| `Cannot start Tor` | Install the Tor executable; check `tor --version` or set `onion.tor_binary`. |
| Onion address printed but unreachable | Look for Tor bootstrap progress; test in Tor Browser and give publication time. Local address creation alone is not a reachability test. |
| Network blocks Tor | Use your platform's Tor bridge guidance. This small managed mode has no bridge configuration UI; use an externally managed Tor setup if bridges are required. |
| Normal browser cannot open `.onion` | Use Tor Browser. Do not send onion names to public DNS. |
| `Host not allowed` | Use the printed URL. For an intentional alias, add its exact `host:port` to `allowed_hosts`; no wildcards. |
| Port already in use | Change `server.bind` to another loopback port and restart, or stop the earlier process. |
| Private directory permissions error | Confirm ownership; set the named private directory to mode 700. Do not make it world-readable. |
| State path too long | Set `state_dir` to a short private absolute path outside `public/`. Unix socket names are limited. |
| Symlink / file-size error | Use regular files in `public/` and adjust limits deliberately if needed. |
| Styles or scripts blocked | Keep them in same-origin external files, or set deliberate CSP hashes. See CONFIGURATION.md. |
| Edited page still looks old | In app, Publish changes; in serve, reload. Read any validation error. Browser caching revalidates using ETags. |
| `already running` | Check the current instance/service. Do not delete `server.lock` while a process is running. |
| `429` or dropped connections | Traffic exceeded the global budget or connection cap; wait or tune the documented limits. |

`status` tests a local lock, not HTTP health or Tor reachability. It may show a
process as running while it is starting, reloading, or stopping. `address`
prints a saved identity even when stopped. Use Tor Browser from another device
for an end-to-end availability check.

## Windows and Mac in 0.3

Portable launchers are the everyday desktop path; see INSTALL.md. Windows uses
NTFS ACLs rather than Unix modes, and loopback TCP rather than a Unix socket for
the managed Tor backend. Unix signal and systemd instructions in this guide apply
only on the relevant Unix systems. On Windows, Ctrl-C is the normal clean stop;
for legacy `serve` content reload, restart the process. The app Publish button
works on every included platform. Shut down before replacing binaries or copying
private state; Windows force-close/logoff deadlines may interrupt cleanup.
