# Glowmesh 0.3 — little lights, many paths

A small Rust webserver with a friendly local control panel, Tor onion hosting,
Yggdrasil connections, and signed sites you can save, carry offline, and share.

## Start here

**Extract the whole ZIP first. No Rust, Node, account, or administrator install
is needed for the included executables.** Open `START_HERE.html` for a simple guide.

| Your computer | Start normally | Use less memory and background work |
|---|---|---|
| Windows 10/11, Intel or AMD 64-bit | Double-click `Start_Glowmesh.cmd` | Double-click `Start_Low_Resource.cmd` |
| Mac, Apple silicon or Intel | Open `Start_Glowmesh.command` | Open `Start_Low_Resource.command` |
| Linux 64-bit PC | `sh ./Start_Glowmesh.sh` | `sh ./Start_Low_Resource.sh` |
| Raspberry Pi with 64-bit OS or ARMv7 32-bit OS | `sh ./Start_Glowmesh.sh` | `sh ./Start_Low_Resource.sh` (recommended) |

The launcher chooses the executable. A browser opens your private control panel;
if it does not, copy the link from the terminal. Keep that window open. Ctrl-C
stops the app. Downloaded Mac/Windows programs are unsigned: see
[installation](docs/INSTALL.md) for the first-open prompts and supported systems.

1. Write a heading and some words. **Save page draft**, then **Publish changes**.
2. In **Connections**, enable Tor or Yggdrasil when those programs are installed.
3. In **Saved sites**, save a friend's Glowmesh site. Compare the full publisher
   key with them before confirming. Your saved copy works when they go offline.

Local use and offline bundles work immediately. Tor and Yggdrasil are optional,
separate installations. Both connections start off each launch.

## Low Resource mode

The same interface and security checks, with one runtime thread, smaller content
limits, fewer connections, and manual updates. No heavy desktop framework is
bundled; your existing browser displays the controls. Close that tab after setup
if you want to save browser memory; the server keeps running.

| Limit | Standard | Low Resource |
|---|---:|---:|
| One file | 32 MiB | 2 MiB |
| One site | 256 MiB | 8 MiB |
| Files per site | 10,000 | 512 |
| Saved sites | 8 | 2 |
| Saved bundles on disk | 512 MiB | 32 MiB |
| Public connections per listener | 128 | 16 |
| Automatic copy updates | Optional | Manual only |

These are content and concurrency limits, **not a total RAM cap**. Tor, browsers,
and Yggdrasil use additional resources. See [small computers](docs/LOW_RESOURCE.md).

## Where your site lives

| System | Default site folder |
|---|---|
| Windows | `%LOCALAPPDATA%\Glowmesh\my-site` |
| Mac | `~/Library/Application Support/Glowmesh/my-site` |
| Linux / Pi | `${XDG_DATA_HOME:-$HOME/.local/share}/glowmesh/my-site` |

Low Resource uses `my-site-lite` instead. This lets you try it without replacing
your normal site. Set `GLOWMESH_SITE` to use a chosen site folder. Keep the folder
outside the release directory, and stop the app before backing it up. Include
`.glowmesh/`: it holds your signing and onion identities. Never share that private
backup publicly. Public `.gmb` bundles contain no Glowmesh private keys.

## Many routes, one signed identity

- Make a page or upload HTML, images and files; publishing checks a complete snapshot.
- Host through Tor and an existing Yggdrasil mesh connection together.
- Try up to six explicit addresses for one pinned publisher when fetching copies.
- Read saved sites offline; import/export signed `.gmb` bundles over USB or any transfer.
- Share someone else's verified copy while preserving the original signature.
- Manage from a separate, authenticated, loopback-only control panel.

This uses existing networks and signed content. It does not create a global DNS
replacement, discover peers automatically, or provide connectivity during every
network shutdown. Ordinary hostnames use DNS; onion downloads use local Tor
SOCKS; literal mesh addresses need no DNS. You choose routes and publishers.

## For developers and server operators

The full Rust source, locked dependencies, tests, licenses, optional local command
installer, Docker recipe, and Linux user-service recipe are included. Build with
Rust 1.94+ and a C toolchain: `cargo build --release --locked`. The old `init`,
`serve`, `check`, `status`, `address` and `export` commands remain available.
`app` supplies the interface and signed-copy features; `serve` is a separate
single-listener static server. See [development](docs/DEVELOPMENT.md).

- [Install, update and platform requirements](docs/INSTALL.md)
- [Everyday app guide](docs/APP.md)
- [Low Resource and Raspberry Pi](docs/LOW_RESOURCE.md)
- [Network choices](docs/NETWORKS.md)
- [Operations and backups](docs/OPERATIONS.md)
- [Configuration](docs/CONFIGURATION.md)
- [Signed snapshot format](docs/PROTOCOL.md)
- [Security boundaries](SECURITY.md)
- [Actual build/test results](VERIFICATION.md)
- [Dependency notices](THIRD_PARTY_NOTICES.md)

MIT licensed. No telemetry, subscriptions, or remote UI assets. This early release
has not received an independent security audit.
