#!/bin/sh
# Start the bundled native executable. No installer or administrator access needed.
set -eu
project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
. "$project_dir/scripts/select-binary.sh"
select_binary
[ -x "$server_bin" ] || chmod u+x "$server_bin"
profile=${GLOWMESH_PROFILE:-standard}
case "$profile" in
    standard) site_name=my-site ;;
    low) site_name=my-site-lite ;;
    *) echo "Unknown profile: $profile" >&2; exit 2 ;;
esac
if [ "$system" = Darwin ]; then
    data_dir="$HOME/Library/Application Support/Glowmesh"
    PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
    export PATH
else
    data_dir="${XDG_DATA_HOME:-$HOME/.local/share}/glowmesh"
fi
site_dir=${GLOWMESH_SITE:-"$data_dir/$site_name"}
echo "Your site folder: $site_dir"
echo "Keep this window open. Press Ctrl-C here to stop Glowmesh."
if [ "$profile" = low ]; then
    exec "$server_bin" --low-resource --config "$site_dir/glowmesh.toml" app "$@"
else
    exec "$server_bin" --config "$site_dir/glowmesh.toml" app "$@"
fi
